import fs from 'fs/promises';
import { baseurl } from '../../config/path.js';
import { detectText } from '../../services/rekognitionService.js';
import { sendCarListedNotification } from '../../services/notification.service.js';
import { notifyListingEvent, notifyMatchingSearchUsers, notifyFavoritedCarUsers } from '../../services/notificationDispatchers.js';
import {
    findCarByIdAndUser,
    fetchUsersById,
    fetchUserRoleData,
    getUserActivePlans,
    getUserTotalSlots,
    countUserCars,
    insertSellerCars,
    updateSellerCars,
    replaceCarLeasingByCarId,
    clearCarLeasingByCarId,
    replaceCarContactByCarId,
    clearCarContactByCarId,
    addCarImagesByCarId,
    deleteCarImagesByCarId,
    replaceCarFeatures,
    normalizeFeatureIds
} from '../../models/user.model.js';
import { handleError, handleSuccess, getRequestLanguage } from '../../utils/responseHandler.js';
import { getMessage, hasExplicitContent, buildFirstRegistrationDateFromMonthYear } from '../../utils/user_helper.js';
import { variableTypes } from '../../utils/constant.js';

export const listCarweb = async (req, res) => {
    const LISTING_STEP = {
        MAKE_MODEL: 1,
        VEHICLE: 2,
        LEASING: 3,
        CONTACT: 4,
        MEDIA: 5,
        PREVIEW: 6
    };

    try {
        const user_id = req.user.id;
        const lang = getRequestLanguage(req);

        const user = await fetchUsersById(user_id);

        const toNumber = (val) => {
            if (val === undefined || val === null || val === '') return null;
            const num = Number(val);
            return Number.isNaN(num) ? null : num;
        };

        const normalizePowerOutput = (val) => {
            if (val === undefined || val === null) return null;
            const str = String(val).trim();
            return str === '' ? null : str;
        };

        const composePowerOutput = (kwValue, psValue, rawValue = null) => {
            const normalizedRaw = normalizePowerOutput(rawValue);
            if (normalizedRaw) return normalizedRaw;
            const kw = toNumber(kwValue);
            const ps = toNumber(psValue);
            if (kw !== null && ps !== null) return `${kw}(${ps})`;
            if (kw !== null) return String(kw);
            if (ps !== null) return String(ps);
            return null;
        };

        // Safe boolean parser
        const toBool = (val) => {
            const str = String(val ?? "").trim().toLowerCase();
            return Number(val) === true || val === 1 || str === "true" || str === "1" ? 1 : 0;
        };

        const normalizeType = (val) => String(val ?? '').trim().toLowerCase();

        const inputSellerType = normalizeType(
            req.body?.seller_type ||
            req.body?.sellerType ||
            req.body?.account_type ||
            req.query?.seller_type ||
            req.query?.sellerType ||
            req.query?.account_type
        );

        const currentUser = (Array.isArray(user) && user.length > 0) ? user[0] : (req.user || {});
        const userAccountType = normalizeType(currentUser.account_type || req.user?.account_type);

        const roleData = await fetchUserRoleData(user_id);
        const sellerRole = Array.isArray(roleData) ? roleData.find(r => r.role === 'seller') : null;
        const roleSellerType = normalizeType(sellerRole?.seller_type);

        const isExplicitCompany = ['company', 'business', 'dealer'].includes(inputSellerType);
        const isExplicitPrivate = ['private', 'personal', 'individual'].includes(inputSellerType);

        let isPrivateSeller = false;
        if (isExplicitPrivate) {
            isPrivateSeller = true;
        } else if (isExplicitCompany) {
            isPrivateSeller = false;
        } else if (userAccountType === 'company' || userAccountType === 'business' || roleSellerType === 'business') {
            isPrivateSeller = false;
        } else {
            isPrivateSeller = true;
        }

        // Validate active plan and slot limits only for non-private (dealer/company) sellers
        if (!isPrivateSeller) {
            const plans = await getUserActivePlans(user_id);
            console.log(plans, user_id);

            if (!plans || plans.length == 0) {
                return handleError(res, 400, getMessage(lang, 'no active plan'));
            }
            const slotLimit = await getUserTotalSlots(user_id);

            const listedCarCount = await countUserCars(user_id);
            if (listedCarCount >= slotLimit) {
                return handleError(res, 400, getMessage(lang, variableTypes.SLOT_LIMIT_EXCEEDED));
            }
        }

        let carReel = null, carImages = [], document = null, reelThumbnails = null;
        let explicitContent;
        if (req.files) {
            if (req.files.carImages?.length) {
                for (const image of req.files.carImages) {
                    const imageBuffer = await fs.readFile(image.path);
                    explicitContent = await hasExplicitContent(imageBuffer);
                    if (explicitContent) {
                        return handleError(res, 400, getMessage(lang, "Image contains explicit content that violates our policy"));
                    }
                }
            }

            if (req.files.reelThumbnails?.length) {
                const thumbnail = req.files.reelThumbnails[0];
                const thumbnailBuffer = await fs.readFile(thumbnail.path);
                explicitContent = await hasExplicitContent(thumbnailBuffer);
                if (explicitContent) {
                    return handleError(res, 400, getMessage(lang, "Video thumbnail contains explicit content that violates our policy"));
                }
            }

            if (req.body.description) {
                const description = req.body.description;
                const textDetection = await detectText(description);
                if (textDetection.inappropriate) {
                    return handleError(res, 400, getMessage(lang, "Description contains inappropriate content that violates our policy"));
                }
            }

            if (req.files.carReel?.length) {
                carReel = `${baseurl}/profile/${req.files.carReel[0].filename}`;
                reelThumbnails = req.files.reelThumbnails ? `${baseurl}/profile/${req.files.reelThumbnails[0].filename}` : null;
            }

            if (req.files.carImages?.length) {
                carImages = req.files.carImages.map(file => `${baseurl}/profile/${file.filename}`);
            }

            if (req.files.document?.length) {
                document = `${baseurl}/profile/${req.files.document[0].filename}`;
            }
        }

        const {
            car_id,
            listing_step,
            is_final_submit,
            page,
            fuel_type_id,
            transmission_id,
            drive_type_id,
            body_type_id,
            brandName,
            carModel,
            version,
            registration_month,
            registration_year,
            first_registration_date: firstRegistrationDateInput,

            // phase 2 fields
            carCondition,
            carMileage,
            doors,
            seats,
            cylinders,
            consumption,
            emptyWeight,
            totalWeight,
            gears,
            powerOutput,
            power_kw,
            power_ps,
            state_id,
            mfk_status_id,
            mfk_warrenty_id,
            warranty_id,
            warranty_type_id,
            warranty_from,
            warranty_to,
            warranty_number_of_months,
            warranty_kilometer,
            warranty_description,
            quality_seal_id,
            last_mfk_date,
            exterior_color_id,
            interior_color_id,
            exterior_color_custom,
            interior_color_custom,
            is_fresh_from_service,
            is_metallic,
            is_swiss_vehicle,
            is_accident_vehicle,

            // phase 3 
            height_mm,
            width_mm,
            length_mm,
            braked_towing_capacity_kg,
            energy_efficiency,
            type_approval,
            vin_number,
            registration_master_number,

            carFeatures,
            extras,
            additional_title_999,
            description,
            carImages: _carImagesFromBody,
            carReel: _carReelFromBody,
            reelThumbnails: _reelThumbnailsFromBody,
            document: _documentFromBody,

            selling_price,
            new_price,
            isLeasing,
            banking_partner,
            annual_interest_rate,
            residual_value,
            leasing_value,

            first_name,
            last_name,
            street,
            house_number,
            postal_code,
            city,
            po_box,
            country,
            country_code,
            phone_number,
            company_name,
            company_address,
            ...otherData
        } = req.body;

        const rawStep = page ?? listing_step;
        const parsedStep = Number(rawStep);
        const currentStep = Number.isInteger(parsedStep) && parsedStep > 0 ? parsedStep : null;
        const mergedFirstRegistrationDate = buildFirstRegistrationDateFromMonthYear({
            registration_month,
            registration_year,
            first_registration_date: firstRegistrationDateInput
        });

        if (mergedFirstRegistrationDate === null) {
            return handleError(res, 400, "Invalid registration month/year");
        }

        // fixing page 6 issue 
        const resolveOptionalField = (uploadedValue, bodyValue) => {
            if (uploadedValue !== null && uploadedValue !== undefined && uploadedValue !== '') return uploadedValue;
            if (bodyValue !== undefined) return bodyValue; // allows explicit null clear if FE sends null
            return undefined; // skip update => preserve old DB value
        };

        const finalCarReel = resolveOptionalField(carReel, _carReelFromBody);
        const finalDocument = resolveOptionalField(document, _documentFromBody);
        const finalReelThumbnails = resolveOptionalField(reelThumbnails, _reelThumbnailsFromBody);

        const normalizeColorText = (v) => String(v ?? "").trim();
        const resolveColorFields = (colorId, colorCustom) => {
            const customText = normalizeColorText(colorCustom);
            if (customText) {
                return { color_id: null, color_custom: customText };
            }

            const parsedId = colorId === "other" ? null : toNumber(colorId);
            if (parsedId !== null) {
                return { color_id: parsedId, color_custom: null };
            }

            // "other" without text (or missing value) => both null
            return { color_id: null, color_custom: null };
        };

        const parseQualitySealId = (val) => {
            if (val === undefined || val === null || val === "" || val === "null" || val === "undefined") {
                return null;
            }
            if (typeof val === "number" && !isNaN(val)) {
                return val > 0 ? val : null;
            }
            if (typeof val === "string") {
                const trimmed = val.trim();
                if (/^\d+$/.test(trimmed)) {
                    const num = Number(trimmed);
                    return num > 0 ? num : null;
                }
                try {
                    const parsed = JSON.parse(trimmed);
                    return parseQualitySealId(parsed);
                } catch (_) {
                    return null;
                }
            }
            if (Array.isArray(val)) {
                if (val.length === 0) return null;
                return parseQualitySealId(val[0]);
            }
            if (typeof val === "object") {
                return parseQualitySealId(val.id ?? val.quality_seal_id ?? val.value ?? val.qualitySealId);
            }
            return null;
        };

        const exteriorColorResolved = resolveColorFields(exterior_color_id, exterior_color_custom);
        const interiorColorResolved = resolveColorFields(interior_color_id, interior_color_custom);

        const data = {
            // phase 1 fields
            ...otherData,
            ...(currentStep ? { listing_step: currentStep } : {}),
            user_id,
            ...(finalCarReel !== undefined ? { carReel: finalCarReel } : {}),
            ...(finalDocument !== undefined ? { document: finalDocument } : {}),
            ...(finalReelThumbnails !== undefined ? { reelThumbnails: finalReelThumbnails } : {}),
            brandName,
            carModel,
            version,
            ...(mergedFirstRegistrationDate ? { first_registration_date: mergedFirstRegistrationDate } : {}),

            fuel_type_id: toNumber(fuel_type_id),
            transmission_id: toNumber(transmission_id),
            drive_type_id: toNumber(drive_type_id),
            body_type_id: toNumber(body_type_id),

            // Phase-2 fields
            carCondition: toNumber(carCondition),
            carMileage,
            state_id: state_id ? Number(state_id) : null,
            mfk_status_id: toNumber(mfk_status_id),
            doors: toNumber(doors),
            sittingCapacity: toNumber(seats),
            cylinders: toNumber(cylinders),
            consumption: toNumber(consumption),
            empty_weight: toNumber(emptyWeight),
            total_weight: toNumber(totalWeight),
            gears: toNumber(gears),
            power_kw: toNumber(power_kw),
            power_ps: toNumber(power_ps),
            powerOutput: composePowerOutput(power_kw, power_ps, powerOutput),
            ...((mfk_warrenty_id !== undefined || warranty_id !== undefined) ? {
                mfk_warrenty_id: toNumber(mfk_warrenty_id ?? warranty_id)
            } : {}),
            warranty_type_text: toNumber(warranty_type_id),
            quality_seal_id: parseQualitySealId(
                [
                    quality_seal_id,
                    req.body.quality_seal,
                    req.body.qualitySealId,
                    req.body.qualitySeal,
                    req.body.quality_seals,
                    req.body.qualitySeals,
                    req.body.quality_seal_ids,
                    req.body.quality_seal_id_resolved
                ].find(v => v !== undefined)
            ),
            warranty_from,
            warranty_number_of_months: toNumber(warranty_number_of_months),

            warranty_kilometer:
                warranty_kilometer !== undefined &&
                    warranty_kilometer !== null &&
                    String(warranty_kilometer).trim() !== ""
                    ? String(warranty_kilometer).trim()
                    : null,

            warranty_description:
                warranty_description !== undefined &&
                    warranty_description !== null &&
                    String(warranty_description).trim() !== ""
                    ? String(warranty_description).trim()
                    : null,
            warranty_to,
            last_mfk_date,
            exterior_color_id: exteriorColorResolved.color_id,
            interior_color_id: interiorColorResolved.color_id,
            exterior_color_custom: exteriorColorResolved.color_custom,
            interior_color_custom: interiorColorResolved.color_custom,
            is_fresh_from_service: toBool(is_fresh_from_service),
            is_metallic: toBool(is_metallic),
            is_swiss_vehicle: toBool(is_swiss_vehicle),
            is_accident_vehicle: toBool(is_accident_vehicle),
            height_mm: toNumber(height_mm),
            width_mm: toNumber(width_mm),
            length_mm: toNumber(length_mm),
            braked_towing_capacity_kg: toNumber(braked_towing_capacity_kg),
            energy_efficiency,
            type_approval,
            vin_number,
            registration_master_number,
            // details view
            carFeatures: req.body.carFeatures !== undefined
                ? JSON.stringify(normalizeFeatureIds(req.body.carFeatures))
                : (Array.isArray(carFeatures) ? JSON.stringify(normalizeFeatureIds(carFeatures)) : carFeatures),
            extras: Array.isArray(extras) ? JSON.stringify(extras) : extras,
            additional_title_999,
            description,

            selling_price: toNumber(selling_price),
            new_price: toNumber(new_price),

            isLeasing: toBool(isLeasing),
        };

        if (currentStep === LISTING_STEP.PREVIEW && !car_id) {
            return handleError(res, 400, "car_id is required for preview submit");
        }

        const isDealer = req.user?.account_type === 'company';
        let existingCar = null;
        if (car_id) {
            const [fetchedCar] = await findCarByIdAndUser(car_id, user_id);
            existingCar = fetchedCar || null;
        }

        const isFinalSubmit = currentStep === LISTING_STEP.PREVIEW && toBool(is_final_submit) === 1;
        let shouldPublish = false;

        if (isDealer) {
            data.listing_type = 'subscription_slot';
            data.payment_status = 'paid';
            if (isFinalSubmit) {
                shouldPublish = true;
                data.listing_status = "published";
                data.is_active = 1;
            } else {
                data.listing_status = existingCar?.listing_status || "draft";
                data.is_active = existingCar?.is_active ?? 2;
            }
        } else {
            // Private Seller: Pay-per-vehicle model
            data.listing_type = 'per_vehicle';
            const isAlreadyPaid = existingCar && existingCar.payment_status === 'paid' && existingCar.listing_status === 'published';

            if (isAlreadyPaid) {
                data.payment_status = 'paid';
                if (isFinalSubmit) {
                    shouldPublish = true;
                    data.listing_status = "published";
                    data.is_active = 1;
                } else {
                    data.listing_status = "published";
                    data.is_active = 1;
                }
            } else {
                data.payment_status = 'unpaid';
                data.listing_status = 'draft';
                data.is_active = 2;
                shouldPublish = false;
            }
        }

        delete data.seller_type;
        delete data.sellerType;
        delete data.account_type;
        delete data.package_id;

        console.log(data);

        let car_id_final;

        if (!car_id) {
            const result = await insertSellerCars({ ...data, listing_step: currentStep || 1 });
            car_id_final = result.insertId;
        } else {
            const cleanData = Object.fromEntries(
                Object.entries(data).filter(([_, v]) => v !== undefined)
            );
            await updateSellerCars(cleanData, car_id);
            car_id_final = car_id;

            if (existingCar) {
                const oldPrice = Number(existingCar.selling_price ?? existingCar.totalPrice ?? 0);
                const newPrice = (data.selling_price !== undefined && data.selling_price !== null && data.selling_price !== '')
                    ? Number(data.selling_price)
                    : ((data.totalPrice !== undefined && data.totalPrice !== null && data.totalPrice !== '')
                        ? Number(data.totalPrice)
                        : ((req.body.price !== undefined && req.body.price !== null && req.body.price !== '') ? Number(req.body.price) : undefined));
                const carName = [existingCar.selectYear, existingCar.brandName, existingCar.carModel].filter(Boolean).join(' ') || 'Vehicle';
                if (newPrice !== undefined && oldPrice > 0 && newPrice < oldPrice) {
                    notifyFavoritedCarUsers({ carId: car_id, event: 'price_reduced', oldPrice, newPrice, carName, excludeUserId: user_id }).catch(e => console.error('Notify price reduced error in web:', e));
                } else {
                    const specFields = ['brandName', 'carModel', 'selectYear', 'carMileage', 'fuel_type_id', 'transmission_id', 'drive_type_id', 'body_type_id', 'exterior_color_id', 'interior_color_id', 'doors', 'sittingCapacity', 'performance_hp', 'power_kw', 'power_ps', 'cubic_capacity', 'description'];
                    const hasSpecChanges = specFields.some(f => data[f] !== undefined && data[f] !== null && String(data[f]).trim() !== '' && String(data[f]) !== String(existingCar[f]));
                    if (hasSpecChanges) {
                        notifyFavoritedCarUsers({ carId: car_id, event: 'updated', carName, excludeUserId: user_id }).catch(e => console.error('Notify updated error in web:', e));
                    }
                }
            }
        }

        const final_car_id = car_id_final;

        if (req.body.carFeatures !== undefined) {
            await replaceCarFeatures(final_car_id, req.body.carFeatures);
        } else if (req.body.features !== undefined) {
            await replaceCarFeatures(final_car_id, req.body.features);
        }

        // leasing page 3
        if (currentStep === LISTING_STEP.LEASING) {
            if (toBool(isLeasing) === 1) {
                await replaceCarLeasingByCarId(final_car_id, {
                    banking_partner: banking_partner ?? null,
                    interest_rate: annual_interest_rate ?? null,
                    residual_percentage: residual_value ?? null,
                    monthly_price: leasing_value ?? null
                });
            } else {
                await clearCarLeasingByCarId(final_car_id);
            }
        }

        // contact page 4
        if (currentStep === LISTING_STEP.CONTACT) {
            const contactPayload = {
                first_name: first_name ?? null,
                last_name: last_name ?? null,
                street: street ?? null,
                house_number: house_number ?? null,
                postal_code: postal_code ?? null,
                city: city ?? null,
                po_box: po_box ?? null,
                country: country ?? null,
                country_code: country_code ?? null,
                phone_number: phone_number ?? null,
                company_name: company_name ?? null,
                company_address: company_address ?? null
            };

            const hasContactData = Object.values(contactPayload).some(
                (v) => v !== null && String(v).trim() !== ""
            );

            if (hasContactData) {
                await replaceCarContactByCarId(final_car_id, contactPayload);
            } else {
                await clearCarContactByCarId(final_car_id);
            }
        }

        // media page 5
        if (currentStep === LISTING_STEP.MEDIA) {
            if (req.files?.carImages?.length) {
                await deleteCarImagesByCarId(final_car_id);
                await Promise.all(
                    carImages.map((img) => addCarImagesByCarId(img, final_car_id))
                );
            }
        }

        if (shouldPublish) {
            try {
                await sendCarListedNotification({
                    carId: final_car_id,
                    senderId: user_id,
                });
                const [fullCar] = await findCarByIdAndUser(final_car_id, user_id);
                const carRecord = fullCar || { id: final_car_id, ...data };
                const carName = [carRecord.carYear, carRecord.brandName, carRecord.modelName].filter(Boolean).join(' ') || 'Vehicle';
                await notifyListingEvent({
                    sellerId: user_id,
                    carId: final_car_id,
                    event: 'published',
                    carName
                });
                await notifyMatchingSearchUsers(carRecord);
            } catch (notifErr) {
                console.error("Listing publish notification error in listCarweb:", notifErr);
            }
        }

        const requiresPayment = !isDealer && (!existingCar || existingCar.payment_status !== 'paid') && isFinalSubmit;

        return handleSuccess(res, 200, requiresPayment ? "Car saved as draft. Please complete payment to publish." : "Car created successfully", {
            car_id: final_car_id,
            page: currentStep || 1,
            requires_payment: requiresPayment,
            listing_status: shouldPublish ? "published" : "draft",
            is_active: data.is_active ?? 0,
            account_type: isDealer ? 'company' : 'private'
        });

    } catch (err) {
        console.error(err);
        return handleError(res, 500, "Internal Server Error");
    }
};
