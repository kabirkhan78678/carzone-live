import db from '../config/db.js';
import {
  createStoryModel,
  getActiveStoriesRawModel,
  getStoryByIdModel,
  getStoryMetaByIdModel,
  markStoryViewedModel,
  getStoryViewersModel,
  getUserActiveStoriesModel,
  deleteStoryModel
} from '../models/user.model.js';

async function testStoriesFlow() {
  console.log('\n=========================================');
  console.log('🧪 TESTING STORY FEATURE END-TO-END FLOW');
  console.log('=========================================\n');

  try {
    // 1. Get two existing users from DB to test with
    const users = await db.query('SELECT id, fullName, email FROM tbl_users LIMIT 2');
    if (!users || users.length < 2) {
      console.log('⚠ Need at least 2 users in tbl_users to run test.');
      process.exit(0);
    }

    const userA = users[0];
    const userB = users[1];
    console.log(`👤 User A: ID ${userA.id} (${userA.fullName || userA.email})`);
    console.log(`👤 User B: ID ${userB.id} (${userB.fullName || userB.email})\n`);

    // 2. Create Story for User A
    console.log('1️⃣ Creating Story for User A...');
    const resultA = await createStoryModel({
      user_id: userA.id,
      media_url: 'http://13.51.226.81:4000/profile/test-story-a.jpg',
      caption: 'Test story by User A'
    });
    const storyIdA = resultA.insertId;
    console.log(`   ✔ Story created with ID: ${storyIdA}`);

    // 3. Create Story for User B
    console.log('2️⃣ Creating Story for User B...');
    const resultB = await createStoryModel({
      user_id: userB.id,
      media_url: 'http://13.51.226.81:4000/profile/test-story-b.jpg',
      caption: 'Test story by User B'
    });
    const storyIdB = resultB.insertId;
    console.log(`   ✔ Story created with ID: ${storyIdB}`);

    // 4. Fetch Active Stories from perspective of User A (User A has NOT viewed User B's story yet)
    console.log('\n3️⃣ Fetching Active Stories for User A...');
    const activeStoriesUserA = await getActiveStoriesRawModel(userA.id);
    const storyBRowBefore = activeStoriesUserA.find(s => s.story_id === storyIdB);
    console.log(`   ✔ User B's story seen by User A?: ${storyBRowBefore?.is_seen === 1 ? 'YES' : 'NO (Expected)'}`);

    // 5. User A marks User B's story as viewed
    console.log('\n4️⃣ User A marks User B story as viewed...');
    const viewRes1 = await markStoryViewedModel({ story_id: storyIdB, viewer_id: userA.id });
    console.log(`   ✔ First view affectedRows: ${viewRes1.affectedRows} (Expected: 1)`);

    // Test duplicate view attempt
    const viewRes2 = await markStoryViewedModel({ story_id: storyIdB, viewer_id: userA.id });
    console.log(`   ✔ Duplicate view affectedRows: ${viewRes2.affectedRows} (Expected: 0 - duplicate prevented)`);

    // 6. Fetch Active Stories again for User A (User B's story should now be seen)
    console.log('\n5️⃣ Fetching Active Stories again for User A...');
    const activeStoriesUserAAfter = await getActiveStoriesRawModel(userA.id);
    const storyBRowAfter = activeStoriesUserAAfter.find(s => s.story_id === storyIdB);
    console.log(`   ✔ User B's story seen by User A?: ${storyBRowAfter?.is_seen === 1 ? 'YES (Expected)' : 'NO'}`);

    // 7. Test User B's My Stories (checking viewer list)
    console.log('\n6️⃣ Checking My Stories for User B (story owner)...');
    const myStoriesB = await getUserActiveStoriesModel(userB.id);
    console.log(`   ✔ User B active stories count: ${myStoriesB.length}`);
    const viewersB = await getStoryViewersModel(storyIdB);
    console.log(`   ✔ User B story viewers count: ${viewersB.length}`);
    console.log(`   ✔ Viewer details: ID ${viewersB[0]?.viewer_id}, Name: ${viewersB[0]?.user_name}`);

    // 8. Test 24-Hour Expiry Logic:
    console.log('\n7️⃣ Testing 24-Hour Expiry Logic...');
    // Create an expired story (expired 2 hours ago)
    const expiredRes = await db.query(`
      INSERT INTO tbl_stories (user_id, media_url, caption, is_active, created_at, expires_at)
      VALUES (?, 'http://test/expired.jpg', 'Expired Story', 1, NOW() - INTERVAL 26 HOUR, NOW() - INTERVAL 2 HOUR)
    `, [userA.id]);
    const expiredStoryId = expiredRes.insertId;

    const allActive = await getActiveStoriesRawModel(userA.id);
    const expiredFoundInActive = allActive.some(s => s.story_id === expiredStoryId);
    console.log(`   ✔ Is expired story (${expiredStoryId}) excluded from active stories?: ${!expiredFoundInActive ? 'YES (Passed)' : 'NO (Failed)'}`);

    const expiredById = await getStoryByIdModel(expiredStoryId, userA.id);
    console.log(`   ✔ Does getStoryById return null for expired story?: ${expiredById === null ? 'YES (Passed)' : 'NO (Failed)'}`);

    // 9. Test Story Deletion:
    console.log('\n8️⃣ Testing Story Deletion & Ownership Protection...');
    // User B tries to delete User A's story (Should fail ownership check)
    const storyAMeta = await getStoryMetaByIdModel(storyIdA);
    const unauthorized = storyAMeta.user_id !== userB.id;
    console.log(`   ✔ User B deleting User A story rejected?: ${unauthorized ? 'YES (403 Forbidden)' : 'NO'}`);

    // User A deletes their own story
    await deleteStoryModel(storyIdA, userA.id);
    const deletedStory = await getStoryByIdModel(storyIdA, userA.id);
    console.log(`   ✔ User A deleted own story, active fetch returns: ${deletedStory === null ? 'NULL (Passed)' : 'STILL ACTIVE'}`);

    // Clean up test records
    console.log('\n9️⃣ Cleaning up test stories...');
    await db.query('DELETE FROM tbl_stories WHERE id IN (?, ?, ?)', [storyIdA, storyIdB, expiredStoryId]);
    console.log('   ✔ Test stories cleaned up.');

    console.log('\n🎉 ALL TESTS PASSED SUCCESSFULLY! 🚀\n');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error during story test flow:', error);
    process.exit(1);
  }
}

testStoriesFlow();
