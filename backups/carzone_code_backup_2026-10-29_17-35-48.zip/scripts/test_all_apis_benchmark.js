/**
 * Comprehensive Backend API Benchmark & Latency Suite
 * Tests every single API route across user.js, admin.js, eurotax.js, vehicles.js, and index.js.
 * Measures execution time (latency in ms), HTTP status code, and captures response details.
 */

import http from 'http';
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import { performance } from 'perf_hooks';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

import route from '../routes/index.js';
import { stripeWebhook } from '../controllers/user_controller.js';

dotenv.config();

// Global handler to catch buggy controller crashes without aborting benchmark
process.on('uncaughtException', (err) => {
  console.log(`\n  🔥 [UNCAUGHT EXCEPTION IN CONTROLLER] ${err.message}`);
});
process.on('unhandledRejection', (reason) => {
  console.log(`\n  🔥 [UNHANDLED REJECTION IN CONTROLLER] ${reason?.message || reason}`);
});

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create express app matching index.js configuration
const app = express();
app.post("/api/webhook", express.raw({ type: "application/json" }), stripeWebhook);
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static("public"));
app.use('/api', route);

// Fallback error handler middleware
app.use((err, req, res, next) => {
  res.status(500).json({ status: 500, message: err.message, stack: err.stack });
});

// Pre-sign JWT tokens for authentication
const userToken = jwt.sign(
  { data: { id: 58, role: 'user' } },
  process.env.AUTH_SECRETKEY,
  { expiresIn: '2h' }
);

const sellerToken = jwt.sign(
  { data: { id: 270, role: 'seller' } },
  process.env.AUTH_SECRETKEY,
  { expiresIn: '2h' }
);

const adminToken = jwt.sign(
  { id: 1, role: 'admin' },
  process.env.JWT_SECRET || process.env.AUTH_SECRETKEY,
  { expiresIn: '2h' }
);

export async function runApiBenchmarks() {
  console.log('\n' + '='.repeat(85));
  console.log('🚀 MASTER API EXECUTION TIME & FUNCTIONALITY BENCHMARK SUITE');
  console.log('='.repeat(85));

  // Spin up ephemeral test server
  const server = http.createServer(app);
  await new Promise((resolve) => server.listen(0, resolve));
  const port = server.address().port;
  const baseUrl = `http://127.0.0.1:${port}`;
  console.log(`🌐 Ephemeral Benchmark Server running on ${baseUrl}\n`);

  const results = [];
  const discoveredBugs = [];

  // Helper function to execute and benchmark an API call
  async function testApi({
    module,
    name,
    method,
    path: apiPath,
    auth = 'none', // 'user', 'seller', 'admin', 'none'
    body = null,
    headers = {},
    expectedStatus = [200, 201]
  }) {
    const fullUrl = `${baseUrl}${apiPath}`;
    const reqHeaders = {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Accept-Language': 'en',
      ...headers
    };

    if (auth === 'user') reqHeaders['Authorization'] = `Bearer ${userToken}`;
    if (auth === 'seller') reqHeaders['Authorization'] = `Bearer ${sellerToken}`;
    if (auth === 'admin') reqHeaders['Authorization'] = `Bearer ${adminToken}`;

    const requestOptions = {
      method,
      headers: reqHeaders,
      signal: AbortSignal.timeout(6000) // 6 second timeout per API
    };

    if (body && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
      requestOptions.body = typeof body === 'string' ? body : JSON.stringify(body);
    }

    const startTime = performance.now();
    let status = 0;
    let resData = null;
    let errorMsg = null;

    try {
      const response = await fetch(fullUrl, requestOptions);
      status = response.status;
      const contentType = response.headers.get('content-type') || '';

      if (contentType.includes('application/json')) {
        resData = await response.json();
      } else {
        const text = await response.text();
        resData = text.length > 150 ? text.substring(0, 150) + '...' : text;
      }
    } catch (err) {
      errorMsg = err.message;
      status = err.name === 'TimeoutError' ? 408 : 500;
    }

    const duration = parseFloat((performance.now() - startTime).toFixed(2));
    const isSuccess = Array.isArray(expectedStatus)
      ? expectedStatus.includes(status)
      : status === expectedStatus;

    const message = errorMsg || resData?.message || (typeof resData === 'string' ? resData : 'OK');

    const record = {
      module,
      name,
      method,
      endpoint: apiPath,
      auth,
      status,
      latencyMs: duration,
      success: isSuccess,
      message
    };

    results.push(record);

    if (!isSuccess && status >= 500) {
      discoveredBugs.push({
        module,
        endpoint: `${method} ${apiPath}`,
        status,
        latencyMs: duration,
        error: message
      });
    }

    const icon = isSuccess ? '✅' : (status >= 500 ? '🔥' : '⚠️');
    console.log(`  ${icon} [${method.padEnd(6)}] ${apiPath.padEnd(46)} | ${status} | ${duration.toString().padStart(7)}ms | ${message}`);

    return record;
  }

  // =========================================================================
  // 1. VEHICLE CATALOG & PUBLIC DROPDOWNS
  // =========================================================================
  console.log('\n--- 1. VEHICLE CATALOG & PUBLIC DROPDOWNS ---');
  await testApi({ module: 'Catalog', name: 'Get Brands', method: 'GET', path: '/api/user/brand', expectedStatus: [200] });
  await testApi({ module: 'Catalog', name: 'Get Models for Brand 1', method: 'GET', path: '/api/user/getModel/1', expectedStatus: [200] });
  await testApi({ module: 'Catalog', name: 'Get Variants for Brand 1', method: 'GET', path: '/api/user/getVarient/1', expectedStatus: [200] });
  await testApi({ module: 'Catalog', name: 'Get Variants by Fuel', method: 'GET', path: '/api/user/variant/1', expectedStatus: [200] });
  await testApi({ module: 'Catalog', name: 'Get Engine by Make/Model', method: 'GET', path: '/api/user/getEngine/BMW/X5', expectedStatus: [200] });
  await testApi({ module: 'Catalog', name: 'Brands List', method: 'GET', path: '/api/user/brands-list', expectedStatus: [200] });
  await testApi({ module: 'Catalog', name: 'Models List', method: 'GET', path: '/api/user/models-list?brand_id=1', expectedStatus: [200] });
  await testApi({ module: 'Catalog', name: 'Versions List', method: 'GET', path: '/api/user/versions-list?model_id=1', expectedStatus: [200, 400] });
  await testApi({ module: 'Catalog', name: 'Catalog by VIN', method: 'GET', path: '/api/user/vehicle-by-vin?vin=WBA12345678901234', expectedStatus: [200, 400, 404] });
  await testApi({ module: 'Catalog', name: 'Catalog by Type Approval', method: 'GET', path: '/api/user/vehicle-by-type-approval?type_approval=1A1234', expectedStatus: [200, 400, 404] });
  await testApi({ module: 'Catalog', name: 'Version Equipment Details', method: 'GET', path: '/api/user/version-equipment-details?version_id=1', expectedStatus: [200, 400, 404] });

  // =========================================================================
  // 2. DROPDOWNS & FILTER OPTIONS
  // =========================================================================
  console.log('\n--- 2. DROPDOWNS & SYSTEM LOOKUPS ---');
  await testApi({ module: 'Dropdowns', name: 'Fuel Types', method: 'GET', path: '/api/user/fuel', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Transmission Types', method: 'GET', path: '/api/user/transmission', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Drive Types', method: 'GET', path: '/api/user/drive', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Body Types', method: 'GET', path: '/api/user/body-type', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Vehicle State', method: 'GET', path: '/api/user/vichel-state', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Accident Vehicle', method: 'GET', path: '/api/user/accident-vehicle', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'MFK Warranty', method: 'GET', path: '/api/user/mfk-warrenty', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'MFK Warranty Counts', method: 'GET', path: '/api/user/mfk-warranty', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'MFK Status List', method: 'GET', path: '/api/user/getMfkStatusList', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Vehicle Conditions', method: 'GET', path: '/api/user/vehicle-conditions', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Warranty Types', method: 'GET', path: '/api/user/warranty', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Colors', method: 'GET', path: '/api/user/colors', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Exterior Colors', method: 'GET', path: '/api/user/exterior-colors', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Interior Colors', method: 'GET', path: '/api/user/interior-colors', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Warranty Quality', method: 'GET', path: '/api/user/warranty-quality', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Energy Efficiency', method: 'GET', path: '/api/user/energy-efficiency', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Listing Age', method: 'GET', path: '/api/user/listing-age', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Seat Count Range', method: 'GET', path: '/api/user/seat', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Door Count Range', method: 'GET', path: '/api/user/door', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Seller Types', method: 'GET', path: '/api/user/seller-type', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Car Types', method: 'GET', path: '/api/user/car-types', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Car Type (Singular)', method: 'GET', path: '/api/user/car-type', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Quality Seals (User)', method: 'GET', path: '/api/user/quality-seals', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Quality Seal (Singular)', method: 'GET', path: '/api/user/quality-seal', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Sort Data Options', method: 'GET', path: '/api/user/sort-data', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Extras List', method: 'GET', path: '/api/user/extras-data', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Features List', method: 'GET', path: '/api/user/features-data', expectedStatus: [200] });
  await testApi({ module: 'Dropdowns', name: 'Total Cars Filter', method: 'GET', path: '/api/user/total-Cars', expectedStatus: [200] });

  // =========================================================================
  // 3. ANALYTICS & RANGE DISTRIBUTIONS
  // =========================================================================
  console.log('\n--- 3. RANGE ANALYTICS ---');
  await testApi({ module: 'Analytics', name: 'Year Range', method: 'GET', path: '/api/user/year-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'Kilometers Range', method: 'GET', path: '/api/user/kilometers-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'Price Range', method: 'GET', path: '/api/user/price-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'Engine Power', method: 'GET', path: '/api/user/engine-power-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'Leasing Range', method: 'GET', path: '/api/user/leasing-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'Cubic Capacity Range', method: 'GET', path: '/api/user/cubic-capacity-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'Cylinders Range', method: 'GET', path: '/api/user/cylinders-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'Battery Capacity Range', method: 'GET', path: '/api/user/battery-capacity-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'Total Weight Range', method: 'GET', path: '/api/user/total-weight-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'Empty Weight Range', method: 'GET', path: '/api/user/empty-weight-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'Towing Capacity Range', method: 'GET', path: '/api/user/towing-capacity-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'WLTP Range', method: 'GET', path: '/api/user/wltp-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'Consumption Range', method: 'GET', path: '/api/user/consumption-range-analytics', expectedStatus: [200] });
  await testApi({ module: 'Analytics', name: 'CO2 Emission Range', method: 'GET', path: '/api/user/co2-emission-range-analytics', expectedStatus: [200] });

  // =========================================================================
  // 4. AUTHENTICATION & USER PROFILE
  // =========================================================================
  console.log('\n--- 4. AUTHENTICATION & PROFILE ---');
  await testApi({ module: 'Auth', name: 'Sign In (Invalid Creds)', method: 'POST', path: '/api/user/signIn', body: { email: 'invalid@yopmail.com', password: 'WrongPassword123!' }, expectedStatus: [400, 401, 404] });
  await testApi({ module: 'Auth', name: 'Sign Up (Validation Check)', method: 'POST', path: '/api/user/signUp', body: { email: 'bad-email' }, expectedStatus: [400] });
  
  // Bug check in resendOtp: Registered email vs unverified/missing email
  await testApi({ module: 'Auth', name: 'Resend OTP (Registered User)', method: 'POST', path: '/api/user/resendOtp', body: { email: 'jack@yopmail.com' }, expectedStatus: [200, 400] });
  
  await testApi({ module: 'Auth', name: 'OTP Verified (Validation)', method: 'POST', path: '/api/user/otpVerified', body: { email: 'test@yopmail.com', otp: '000000' }, expectedStatus: [400, 404] });
  await testApi({ module: 'Auth', name: 'Forgot Password (Validation)', method: 'POST', path: '/api/user/forgotPassword', body: { email: 'nonexistent@yopmail.com' }, expectedStatus: [400, 404] });
  await testApi({ module: 'Auth', name: 'Reset Password (Validation)', method: 'POST', path: '/api/user/resetPassword', body: { email: 'test@yopmail.com', newPassword: '123' }, expectedStatus: [400, 404] });
  await testApi({ module: 'Auth', name: 'Social Login (Validation)', method: 'POST', path: '/api/user/socialLogin', body: { provider: 'google' }, expectedStatus: [400] });

  await testApi({ module: 'Profile', name: 'Get User Profile', method: 'GET', path: '/api/user/getUserProfile', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Profile', name: 'Web Get User Profile', method: 'GET', path: '/api/user/web/getUserProfile', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Profile', name: 'Mobile Get User Profile', method: 'GET', path: '/api/user/mobile/getUserProfile', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Profile', name: 'Change Language (POST)', method: 'POST', path: '/api/user/changeLanguage', auth: 'user', body: { language: 'en' }, expectedStatus: [200] });
  await testApi({ module: 'Profile', name: 'Change Language (PUT)', method: 'PUT', path: '/api/user/changeLanguage', auth: 'user', body: { language: 'en' }, expectedStatus: [200] });
  await testApi({ module: 'Profile', name: 'Change Language (PATCH)', method: 'PATCH', path: '/api/user/changeLanguage', auth: 'user', body: { language: 'en' }, expectedStatus: [200] });
  await testApi({ module: 'Profile', name: 'Change Mode (Validation)', method: 'POST', path: '/api/user/changeMode', auth: 'user', body: { role: 'buyer' }, expectedStatus: [200, 400] });
  await testApi({ module: 'Profile', name: 'Change Password (Mismatch)', method: 'POST', path: '/api/user/changePassword', auth: 'user', body: { currentPassword: 'fake', newPassword: 'new' }, expectedStatus: [400] });
  await testApi({ module: 'Profile', name: 'Update Buyer To Seller', method: 'POST', path: '/api/user/updateBuyerToSeller', auth: 'user', body: { account_type: 'individual' }, expectedStatus: [200, 400] });
  await testApi({ module: 'Profile', name: 'Notification Settings (GET)', method: 'GET', path: '/api/user/notification-settings', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Profile', name: 'Notification Settings (PUT)', method: 'PUT', path: '/api/user/notification-settings', auth: 'user', body: { chat_notifications: true }, expectedStatus: [200] });
  await testApi({ module: 'Profile', name: 'Update FCM Token', method: 'POST', path: '/api/user/updateFcmToken', auth: 'user', body: { fcm_token: 'dummy_token' }, expectedStatus: [200] });
  await testApi({ module: 'Profile', name: 'Add Lat Long', method: 'POST', path: '/api/user/add-lat-long', auth: 'user', body: { latitude: '47.3769', longitude: '8.5417' }, expectedStatus: [200] });
  await testApi({ module: 'Profile', name: 'Google Rating for Seller', method: 'GET', path: '/api/user/google-rating/270', auth: 'user', expectedStatus: [200, 404] });
  await testApi({ module: 'Profile', name: 'Find Vehicle By VRN (Validation)', method: 'POST', path: '/api/user/find-vehicle-by-vrn', auth: 'user', body: { vrn: 'ZH12345' }, expectedStatus: [200, 400, 404] });

  // =========================================================================
  // 5. CAR SEARCH, INVENTORY & DETAILS
  // =========================================================================
  console.log('\n--- 5. CARS & INVENTORY ---');
  await testApi({ module: 'Cars', name: 'Faceted Filters Search', method: 'POST', path: '/api/user/faceted-filters', body: { brand: 'BMW' }, expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Car Filter (Legacy)', method: 'GET', path: '/api/user/carFilter?brandName=BMW', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Filter on Brand or Model', method: 'GET', path: '/api/user/filterCarOnBrandNameOrCarModel?search=BMW', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Get Car Details (Active Car 97)', method: 'GET', path: '/api/user/getCar/97', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Guest Fetch Seller Cars List', method: 'GET', path: '/api/user/asGuestUserFetchSellerCarsList?page=1&limit=5', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Guest Get Car (ID 97)', method: 'GET', path: '/api/user/asGuestUserGetCar/97', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Fetch Other Seller Cars', method: 'GET', path: '/api/user/fetchOtherSellerCarsList?page=1&limit=5', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Fetch Other Cars by Seller 270', method: 'GET', path: '/api/user/fetchOtherCarListByOtherSellerId?seller_id=270', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Get My Cars (Seller 270)', method: 'GET', path: '/api/user/getMyCar', auth: 'seller', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Latest Draft Car', method: 'GET', path: '/api/user/latest-draft-car', auth: 'seller', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Car MFK Status (Car 97)', method: 'GET', path: '/api/user/car/mfk/97', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Car Warranty Details (Car 97)', method: 'GET', path: '/api/user/cars/warranty/97', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Download Car PDF (Car 2)', method: 'GET', path: '/api/user/cars/2/download-pdf', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Leasing Calculate', method: 'POST', path: '/api/user/leasing-calculate', auth: 'user', body: { carPrice: 35000, durationMonths: 48, annualMileage: 15000, interestRate: 4.9 }, expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Car Inquiry', method: 'POST', path: '/api/user/car-inquiry', auth: 'user', body: { car_id: 97, message: 'Is this car still available for test drive?' }, expectedStatus: [200, 201] });
  await testApi({ module: 'Cars', name: 'Toggle Car Status (Car 97)', method: 'POST', path: '/api/user/car/97/toggle-status', auth: 'seller', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Toggle Car Status (PATCH)', method: 'PATCH', path: '/api/user/car/97/toggle-status', auth: 'seller', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Activate Car Slot (POST)', method: 'POST', path: '/api/user/car/97/activate', auth: 'seller', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Swap Car (Validation)', method: 'POST', path: '/api/user/swap-car', auth: 'seller', body: { active_car_id: 97, inactive_car_id: 2 }, expectedStatus: [200, 400] });
  await testApi({ module: 'Cars', name: 'Swap Active Slot (Validation)', method: 'POST', path: '/api/user/swap-active-slot', auth: 'seller', body: { car_id: 97 }, expectedStatus: [200, 400] });
  await testApi({ module: 'Cars', name: 'Web Filters', method: 'GET', path: '/api/user/web/filters', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Web All Makes', method: 'GET', path: '/api/user/web/all-makes', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Web Models by Make', method: 'GET', path: '/api/user/web/models-by-make/1', expectedStatus: [200] });
  await testApi({ module: 'Cars', name: 'Car Vertical Report (Validation)', method: 'POST', path: '/api/user/carVerticalReport/97', auth: 'user', expectedStatus: [200, 400, 500] });
  await testApi({ module: 'Cars', name: 'Car Vertical (Body Vin)', method: 'POST', path: '/api/user/car-vertical', auth: 'user', body: { vin: 'WBA12345678901234' }, expectedStatus: [200, 400, 500] });

  // =========================================================================
  // 6. REELS & MEDIA
  // =========================================================================
  console.log('\n--- 6. REELS & MEDIA ---');
  await testApi({ module: 'Reels', name: 'Fetch All Car Reels', method: 'GET', path: '/api/user/fetchAllCarReels?page=1&limit=5', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Reels', name: 'Fetch Car Reels', method: 'GET', path: '/api/user/fetchCarReels?page=1&limit=5', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Reels', name: 'Fetch All Car Reel (Alt)', method: 'GET', path: '/api/user/fetchAllCarReel?page=1&limit=5', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Reels', name: 'Guest Fetch All Reels', method: 'GET', path: '/api/user/asGuestUsersfetchAllCarReels?page=1&limit=5', expectedStatus: [200] });
  await testApi({ module: 'Reels', name: 'Fetch Saved Car Reels', method: 'GET', path: '/api/user/fetchedSavedCarReels', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Reels', name: 'Fetch My Reels', method: 'GET', path: '/api/user/fetchMyReels', auth: 'seller', expectedStatus: [200] });
  await testApi({ module: 'Reels', name: 'Fetch Reel by ID (Validation)', method: 'GET', path: '/api/user/fetchReelById?reel_id=1', auth: 'user', expectedStatus: [200, 400, 404] });
  await testApi({ module: 'Reels', name: 'Save Car Reel', method: 'POST', path: '/api/user/saveCarReels', auth: 'user', body: { car_id: 97, carId: 97 }, expectedStatus: [200, 201] });
  await testApi({ module: 'Reels', name: 'Remove Saved Car Reel', method: 'DELETE', path: '/api/user/removeSavedCarsReel', auth: 'user', body: { car_id: 97 }, expectedStatus: [200] });

  // =========================================================================
  // 7. USER INTERACTIONS, WISHLIST, NOTIFICATIONS & VISITS
  // =========================================================================
  console.log('\n--- 7. INTERACTIONS, WISHLIST & VISITS ---');
  await testApi({ module: 'Interactions', name: 'Add to Wishlist', method: 'POST', path: '/api/user/addToWishlist', auth: 'user', body: { car_id: 97 }, expectedStatus: [200, 201, 400] });
  await testApi({ module: 'Interactions', name: 'Fetch User Wishlist', method: 'GET', path: '/api/user/fetchUserWishlist', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Remove from Wishlist', method: 'DELETE', path: '/api/user/removeCarFromWishlist', auth: 'user', body: { car_id: 97 }, expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Add Recently Viewed', method: 'POST', path: '/api/user/addRecentlyViewed', auth: 'user', body: { car_id: 97 }, expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Get Recently Viewed List', method: 'GET', path: '/api/user/getRecentlyViewedlist', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Fetch Buyer Notifications', method: 'GET', path: '/api/user/fetchNotificationByBuyersIds', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Read All Notifications', method: 'POST', path: '/api/user/readAllNotifications', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Read Notification by ID', method: 'POST', path: '/api/user/readNotificationById', auth: 'user', body: { notification_id: 1 }, expectedStatus: [200, 400, 404] });
  await testApi({ module: 'Interactions', name: 'Saved Searches (GET)', method: 'GET', path: '/api/user/saved-searches', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Create Saved Search', method: 'POST', path: '/api/user/saved-searches', auth: 'user', body: { search_name: 'Bench BMW', filter_params: { brand: 'BMW' } }, expectedStatus: [200, 201] });
  await testApi({ module: 'Interactions', name: 'Report Reasons', method: 'GET', path: '/api/user/report-reasons', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Report Car (Validation)', method: 'POST', path: '/api/user/report-cars/97', auth: 'user', body: { reason_id: 1, comment: 'Benchmark report test' }, expectedStatus: [200, 201, 400] });
  await testApi({ module: 'Interactions', name: 'Get Schedule Visit (Buyer)', method: 'GET', path: '/api/user/get-Schedule-visit', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Get Schedule Visits (Seller)', method: 'GET', path: '/api/user/get-Schedule-visits', auth: 'seller', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Schedule Requests (GET)', method: 'GET', path: '/api/user/schedule-requests', auth: 'seller', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Schedule Request by ID', method: 'GET', path: '/api/user/schedule-requests/1', auth: 'seller', expectedStatus: [200, 404] });
  await testApi({ module: 'Interactions', name: 'My Sent Visit Requests', method: 'GET', path: '/api/user/my-sent-visit-requests', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Fetch All Sellers', method: 'GET', path: '/api/user/fetchAllSellers', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Fetch Seller by ID 270', method: 'GET', path: '/api/user/fetchSellerById/270', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Help Support Tickets', method: 'GET', path: '/api/user/help-support/my-tickets', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Submit App Feedback', method: 'POST', path: '/api/user/submit-App-Feedback', auth: 'user', body: { rating: 5, feedback: 'Benchmark test feedback' }, expectedStatus: [200, 201] });
  await testApi({ module: 'Interactions', name: 'Submit Help Request', method: 'POST', path: '/api/user/submitHelpRequest', auth: 'user', body: { subject: 'Bench Support', message: 'Bench testing help desk' }, expectedStatus: [200, 201] });
  await testApi({ module: 'Interactions', name: 'Send Chat Notification API', method: 'POST', path: '/api/user/chat/notification', body: { receiver_id: 270, sender_id: 58, message: 'Benchmark notification' }, expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Purchase Agreement Template', method: 'GET', path: '/api/user/purchase-agreement/template', expectedStatus: [200] });
  await testApi({ module: 'Interactions', name: 'Agreement Warranty Types', method: 'GET', path: '/api/user/purchase-agreement/warranty-types', expectedStatus: [200] });

  // =========================================================================
  // 8. PLANS & SUBSCRIPTION SLOTS
  // =========================================================================
  console.log('\n--- 8. PLANS & SLOTS ---');
  await testApi({ module: 'Plans', name: 'Get All Plans', method: 'GET', path: '/api/user/getAllPlan', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Plans', name: 'Get My Plan', method: 'GET', path: '/api/user/getMyPlan', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Plans', name: 'Choose Listing Plan (GET)', method: 'GET', path: '/api/user/choose-listing-plan', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Plans', name: 'Choose Listing Plan (POST)', method: 'POST', path: '/api/user/choose-listing-plan', auth: 'user', body: { plan_id: 1 }, expectedStatus: [200, 400] });
  await testApi({ module: 'Plans', name: 'Get All Slot Requests', method: 'GET', path: '/api/user/getAllSlotRequests', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Plans', name: 'Get My Approved Slot Requests', method: 'GET', path: '/api/user/getMyApprovedSlotRequests', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Plans', name: 'Renewal Overview', method: 'GET', path: '/api/user/renewal-overview', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Plans', name: 'Upgrade Downgrade Plans', method: 'GET', path: '/api/user/getUpgradeDowngradePlans', auth: 'user', expectedStatus: [200] });
  await testApi({ module: 'Plans', name: 'Renew Summary (Plan 106)', method: 'GET', path: '/api/user/renewSummary/106', auth: 'user', expectedStatus: [200] });

  // =========================================================================
  // 9. ADMIN MODULE
  // =========================================================================
  console.log('\n--- 9. ADMIN MODULE ---');
  await testApi({ module: 'Admin', name: 'Dashboard Counts', method: 'GET', path: '/api/admin/getdashboard', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Admin Profile', method: 'GET', path: '/api/admin/getAdminProfile', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'List All Cars', method: 'GET', path: '/api/admin/listallCar', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Fetch Car by ID 2', method: 'GET', path: '/api/admin/fetchCarById?id=2', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Get All Private Accounts', method: 'GET', path: '/api/admin/getAllPrivateAccounts', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Get All Company Accounts', method: 'GET', path: '/api/admin/getAllCompanyAccounts', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Get Seller and Buyer List', method: 'GET', path: '/api/admin/getSellerAndBuyer', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Fetch User by ID 58', method: 'GET', path: '/api/admin/fetchUserById?id=58', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Get Single Buyer (58)', method: 'GET', path: '/api/admin/getSingleBuyer?id=58', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Get Single Seller (270)', method: 'GET', path: '/api/admin/getSingleSeller?id=270', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Get All Purchases', method: 'GET', path: '/api/admin/getAllPurchases', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Fetch All Plans (Admin)', method: 'GET', path: '/api/admin/fetchAllPlans', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Pending Slot Requests', method: 'GET', path: '/api/admin/getPendingSlotRequests', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'All Slot Requests', method: 'GET', path: '/api/admin/getAllSlotRequests', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Transaction Slot Summary', method: 'GET', path: '/api/admin/getTransaction-slot-summary', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Seller Slot Detail 270', method: 'GET', path: '/api/admin/getSlotDetail/270', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Pending Companies', method: 'GET', path: '/api/admin/pendingCompanies', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Reported Cars', method: 'GET', path: '/api/admin/reported-cars', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'App Feedback', method: 'GET', path: '/api/admin/get-App-Feedback', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Emblems List', method: 'GET', path: '/api/admin/emblems', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Quality Seals (Admin)', method: 'GET', path: '/api/admin/quality-seals', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Help Support List', method: 'GET', path: '/api/admin/help-support', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Get All Plans (Admin userController)', method: 'GET', path: '/api/admin/getAllPlan', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Slots Sold by Package', method: 'GET', path: '/api/admin/slots-sold-by-package', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Schedule Visits (Admin)', method: 'GET', path: '/api/admin/schedule-visits', auth: 'admin', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Admin Login (Invalid Check)', method: 'POST', path: '/api/admin/loginAdmin', body: { email: 'bad@admin.com', password: 'bad' }, expectedStatus: [400, 401, 404] });
  await testApi({ module: 'Admin', name: 'Admin Forgot Password (Check)', method: 'POST', path: '/api/admin/forgot-password', body: { email: 'bad@admin.com' }, expectedStatus: [400, 404] });
  await testApi({ module: 'Admin', name: 'Admin Reset Password View', method: 'GET', path: '/api/admin/reset-password', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Admin Success Reset View', method: 'GET', path: '/api/admin/success-reset', expectedStatus: [200] });
  await testApi({ module: 'Admin', name: 'Admin Change MFK Status', method: 'PUT', path: '/api/admin/changeMfkCarStatus', auth: 'admin', body: { carId: 97, mfkStatus: 'approved' }, expectedStatus: [200, 400] });
  await testApi({ module: 'Admin', name: 'Admin Send System Notification', method: 'POST', path: '/api/admin/system-notification', auth: 'admin', body: { title: 'Benchmark Test', message: 'Test announcement' }, expectedStatus: [200] });

  // =========================================================================
  // 10. CARAPI / VEHICLES EXTERNAL SERVICE
  // =========================================================================
  console.log('\n--- 10. CARAPI & VEHICLES ---');
  await testApi({ module: 'CarAPI', name: 'CarAPI Brands', method: 'GET', path: '/api/carapi/brands', expectedStatus: [200, 400, 500] });
  await testApi({ module: 'CarAPI', name: 'CarAPI Models (BMW)', method: 'GET', path: '/api/carapi/models/BMW', expectedStatus: [200, 400, 500] });
  await testApi({ module: 'CarAPI', name: 'CarAPI Details', method: 'GET', path: '/api/carapi/details/BMW/320/2020', expectedStatus: [200, 400, 500] });
  await testApi({ module: 'CarAPI', name: 'CarAPI Search', method: 'GET', path: '/api/carapi/search?brand=BMW&year=2020', expectedStatus: [200, 400, 500] });

  // =========================================================================
  // 11. EUROTAX & WEBHOOK
  // =========================================================================
  console.log('\n--- 11. EUROTAX & STRIPE WEBHOOK ---');
  await testApi({ module: 'Eurotax', name: 'Eurotax Valuation', method: 'POST', path: '/api/eurotax/valuation', body: { vin: 'WBA12345678901234', mileage: 50000 }, expectedStatus: [200, 400, 500] });
  await testApi({ module: 'Webhook', name: 'Stripe Webhook (Invalid Signature)', method: 'POST', path: '/api/webhook', body: JSON.stringify({ type: 'checkout.session.completed' }), expectedStatus: [400] });

  server.close();

  // Save benchmark results to JSON file
  const outputPath = path.join(__dirname, 'api_benchmark_results.json');
  fs.writeFileSync(outputPath, JSON.stringify({
    timestamp: new Date().toISOString(),
    totalApisTested: results.length,
    passedApis: results.filter(r => r.success).length,
    failedApis: results.filter(r => !r.success).length,
    discoveredBugs,
    results
  }, null, 2));

  // Print Summary Table
  console.log('\n' + '='.repeat(85));
  console.log('📊 MASTER BENCHMARK SUMMARY TABLE:');
  console.log('='.repeat(85));

  const totalTested = results.length;
  const passed = results.filter(r => r.success).length;
  const failed = totalTested - passed;
  const avgLatency = (results.reduce((acc, r) => acc + r.latencyMs, 0) / totalTested).toFixed(2);
  const fastApis = results.filter(r => r.latencyMs < 100).length;
  const moderateApis = results.filter(r => r.latencyMs >= 100 && r.latencyMs <= 500).length;
  const slowApis = results.filter(r => r.latencyMs > 500).length;

  console.log(`\nTotal APIs Benchmarked  : ${totalTested}`);
  console.log(`Successful Calls        : ${passed} / ${totalTested}`);
  console.log(`Failed / Anomalies      : ${failed}`);
  console.log(`Average Execution Time  : ${avgLatency} ms`);
  console.log(`⚡ Fast (<100ms)         : ${fastApis} endpoints`);
  console.log(`⏱ Moderate (100-500ms)  : ${moderateApis} endpoints`);
  console.log(`🐢 Slow (>500ms)        : ${slowApis} endpoints\n`);

  return { results, discoveredBugs };
}

if (process.argv[1].endsWith('test_all_apis_benchmark.js')) {
  runApiBenchmarks()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error('Benchmark Suite Fatal Error:', err);
      process.exit(1);
    });
}
