import db from '../config/db.js';
import {
  createStoryModel,
  getStoryByIdModel,
  markStoryViewedModel,
  getStoryViewersModel,
  getUserActiveStoriesModel,
  deleteStoryModel
} from '../models/user.model.js';
import {
  createStory,
  getActiveStories,
  markStoryViewed,
  getMyStories,
  getStoryById
} from '../controllers/shared/story.controller.js';
import { createMockReqRes } from './test_helper.js';

async function deepTestViewCounts() {
  console.log('\n======================================================');
  console.log('🔬 DEEP ANALYSIS & TEST: STORY VIEW COUNTS & SYNC');
  console.log('======================================================\n');

  let storyId;
  try {
    // 1. Fetch 3 distinct users for the test: Owner (User A), Viewer 1 (User B), Viewer 2 (User C)
    const users = await db.query(
      'SELECT id, fullName, email FROM tbl_users WHERE (is_deleted = 0 OR is_deleted IS NULL) LIMIT 3'
    );
    if (!users || users.length < 3) {
      console.log('⚠ Need at least 3 active users in tbl_users to run test.');
      process.exit(1);
    }

    const owner = users[0];
    const viewer1 = users[1];
    const viewer2 = users[2];

    console.log(`👤 Owner   : ID ${owner.id} (${owner.fullName || owner.email})`);
    console.log(`👤 Viewer 1: ID ${viewer1.id} (${viewer1.fullName || viewer1.email})`);
    console.log(`👤 Viewer 2: ID ${viewer2.id} (${viewer2.fullName || viewer2.email})\n`);

    // --- STEP 1: Fresh Story Creation ---
    console.log('Step 1: Creating fresh story for Owner...');
    const storyRes = await createStoryModel({
      user_id: owner.id,
      media_url: 'http://13.51.226.81:4000/profile/deep-test.jpg',
      caption: 'Deep view count test'
    });
    storyId = storyRes.insertId;
    console.log(`  ✔ Story created with ID: ${storyId}`);

    // Verify initial count in getMyStories
    const { req: reqOwnerMyStories, res: resOwnerMyStories, getResponse: getRespMyStories } = createMockReqRes({
      user: owner
    });
    await getMyStories(reqOwnerMyStories, resOwnerMyStories);
    const myStoriesInitial = getRespMyStories().data.data.find(s => s.id === storyId);
    console.log(`  ✔ Initial views_count in my-stories: ${myStoriesInitial.views_count} (Expected: 0)`);
    console.log(`  ✔ Initial viewers list length: ${myStoriesInitial.viewers.length} (Expected: 0)`);
    if (myStoriesInitial.views_count !== 0 || myStoriesInitial.viewers.length !== 0) {
      throw new Error(`Initial count failure: views_count=${myStoriesInitial.views_count}, viewers=${myStoriesInitial.viewers.length}`);
    }

    // --- STEP 2: Owner Views Own Story ---
    console.log('\nStep 2: Owner views their own story (POST /stories/:id/views)...');
    const { req: reqOwnerView, res: resOwnerView, getResponse: getRespOwnerView } = createMockReqRes({
      user: owner,
      params: { id: storyId }
    });
    await markStoryViewed(reqOwnerView, resOwnerView);
    const ownerViewResp = getRespOwnerView();
    console.log(`  ✔ Owner view response: is_new_view=${ownerViewResp.data.data.is_new_view}, views_count=${ownerViewResp.data.data.views_count}`);
    if (ownerViewResp.data.data.is_new_view !== false || ownerViewResp.data.data.views_count !== 0) {
      throw new Error('Owner view was recorded or count incremented!');
    }

    // --- STEP 3: Viewer 1 Views the Story ---
    console.log('\nStep 3: Viewer 1 (User B) views the story...');
    const { req: reqV1, res: resV1, getResponse: getRespV1 } = createMockReqRes({
      user: viewer1,
      params: { id: storyId }
    });
    await markStoryViewed(reqV1, resV1);
    const v1Resp = getRespV1();
    console.log(`  ✔ Viewer 1 response: is_new_view=${v1Resp.data.data.is_new_view}, views_count=${v1Resp.data.data.views_count} (Expected: 1)`);
    if (v1Resp.data.data.is_new_view !== true || v1Resp.data.data.views_count !== 1) {
      throw new Error(`Viewer 1 view failed: is_new_view=${v1Resp.data.data.is_new_view}, views_count=${v1Resp.data.data.views_count}`);
    }

    // --- STEP 4: Viewer 1 Views AGAIN (Duplicate) ---
    console.log('\nStep 4: Viewer 1 views AGAIN (duplicate open)...');
    await markStoryViewed(reqV1, resV1);
    const v1DupResp = getRespV1();
    console.log(`  ✔ Viewer 1 dup response: is_new_view=${v1DupResp.data.data.is_new_view}, views_count=${v1DupResp.data.data.views_count} (Expected: 1)`);
    if (v1DupResp.data.data.is_new_view !== false || v1DupResp.data.data.views_count !== 1) {
      throw new Error(`Duplicate view inflated count! views_count=${v1DupResp.data.data.views_count}`);
    }

    // --- STEP 5: Viewer 2 Views the Story ---
    console.log('\nStep 5: Viewer 2 (User C) views the story...');
    const { req: reqV2, res: resV2, getResponse: getRespV2 } = createMockReqRes({
      user: viewer2,
      params: { id: storyId }
    });
    await markStoryViewed(reqV2, resV2);
    const v2Resp = getRespV2();
    console.log(`  ✔ Viewer 2 response: is_new_view=${v2Resp.data.data.is_new_view}, views_count=${v2Resp.data.data.views_count} (Expected: 2)`);
    if (v2Resp.data.data.is_new_view !== true || v2Resp.data.data.views_count !== 2) {
      throw new Error(`Viewer 2 view failed: is_new_view=${v2Resp.data.data.is_new_view}, views_count=${v2Resp.data.data.views_count}`);
    }

    // --- STEP 6: Owner Views Own Story 5 More Times ---
    console.log('\nStep 6: Owner views own story 5 more times in a loop...');
    for (let i = 1; i <= 5; i++) {
      await markStoryViewed(reqOwnerView, resOwnerView);
    }
    const finalOwnerView = getRespOwnerView();
    console.log(`  ✔ After 5 owner views: is_new_view=${finalOwnerView.data.data.is_new_view}, views_count=${finalOwnerView.data.data.views_count} (Expected: 2)`);
    if (finalOwnerView.data.data.views_count !== 2) {
      throw new Error(`Owner views changed views_count to ${finalOwnerView.data.data.views_count}`);
    }

    // --- STEP 7: Check Consistency across ALL 3 GET APIs ---
    console.log('\nStep 7: Validating 100% synchronization across all GET APIs:');

    // 7A: GET /api/stories/my-stories
    await getMyStories(reqOwnerMyStories, resOwnerMyStories);
    const myStoryFinal = getRespMyStories().data.data.find(s => s.id === storyId);
    console.log(`  ✔ [GET /my-stories] views_count: ${myStoryFinal.views_count}, viewers.length: ${myStoryFinal.viewers.length}`);
    if (myStoryFinal.views_count !== 2 || myStoryFinal.viewers.length !== 2) {
      throw new Error(`my-stories mismatch: views_count=${myStoryFinal.views_count}, viewers.length=${myStoryFinal.viewers.length}`);
    }

    const viewersIncludeOwner = myStoryFinal.viewers.some(v => v.viewer_id === owner.id);
    if (viewersIncludeOwner) {
      throw new Error('Owner is in my-stories viewers array!');
    }
    console.log(`  ✔ Owner NOT in viewers array: PASSED`);

    // 7B: GET /api/stories/:id as Owner
    const { req: reqSingleStory, res: resSingleStory, getResponse: getRespSingleStory } = createMockReqRes({
      user: owner,
      params: { id: storyId }
    });
    await getStoryById(reqSingleStory, resSingleStory);
    const singleStoryOwner = getRespSingleStory().data.data;
    console.log(`  ✔ [GET /stories/:id (Owner)] views_count: ${singleStoryOwner.views_count}, viewers.length: ${singleStoryOwner.viewers?.length}`);
    if (singleStoryOwner.views_count !== 2 || singleStoryOwner.viewers?.length !== 2) {
      throw new Error(`single story owner mismatch: views_count=${singleStoryOwner.views_count}, viewers=${singleStoryOwner.viewers?.length}`);
    }

    // 7C: GET /api/stories/:id as Viewer 1
    const { req: reqSingleViewer, res: resSingleViewer, getResponse: getRespSingleViewer } = createMockReqRes({
      user: viewer1,
      params: { id: storyId }
    });
    await getStoryById(reqSingleViewer, resSingleViewer);
    const singleStoryViewer = getRespSingleViewer().data.data;
    console.log(`  ✔ [GET /stories/:id (Viewer)] views_count: ${singleStoryViewer.views_count} (viewers hidden for non-owner: ${!singleStoryViewer.viewers})`);
    if (singleStoryViewer.views_count !== 2) {
      throw new Error(`single story viewer views_count mismatch: ${singleStoryViewer.views_count}`);
    }

    // 7D: GET /api/stories from perspective of Viewer 1
    const { req: reqFeed, res: resFeed, getResponse: getRespFeed } = createMockReqRes({
      user: viewer1
    });
    await getActiveStories(reqFeed, resFeed);
    const feedUsers = getRespFeed().data.data;
    const ownerFeed = feedUsers.find(u => u.user_id === owner.id);
    const storyInFeed = ownerFeed?.stories.find(s => s.id === storyId);
    console.log(`  ✔ [GET /stories (Feed)] views_count on story: ${storyInFeed?.views_count} (Expected: 2)`);
    if (storyInFeed?.views_count !== 2) {
      throw new Error(`Feed story views_count mismatch: ${storyInFeed?.views_count}`);
    }

    // Clean up
    await deleteStoryModel(storyId, owner.id);
    await db.query('DELETE FROM tbl_stories WHERE id = ?', [storyId]);
    console.log('\n✔ Test story cleaned up from DB.');

    console.log('\n🎉 ALL 7 DEEP VIEW COUNT INTEGRITY TESTS PASSED 100%! 🚀\n');
    process.exit(0);

  } catch (err) {
    console.error('❌ DEEP TEST FAILED:', err);
    if (storyId) {
      await db.query('DELETE FROM tbl_stories WHERE id = ?', [storyId]).catch(() => {});
    }
    process.exit(1);
  }
}

deepTestViewCounts();
