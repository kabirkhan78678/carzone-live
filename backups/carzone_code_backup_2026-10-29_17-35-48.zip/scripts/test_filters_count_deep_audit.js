/**
 * Comprehensive verification of /api/user/web/filters?lang=en&warranty=1
 * Checks each section, array, and count against exact SQL queries.
 */

import http from 'http';
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import dotenv from 'dotenv';
import route from '../routes/index.js';
import db from '../config/db.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use('/api', route);

async function inspectAllCounts() {
  const server = http.createServer(app);
  await new Promise(r => server.listen(0, r));
  const port = server.address().port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const res = await fetch(`${baseUrl}/api/user/web/filters?lang=en&warranty=1`);
  const json = await res.json();
  const d = json?.data || {};

  console.log('\n' + '='.repeat(80));
  console.log('📋 COMPLETE AUDIT OF /api/user/web/filters?lang=en&warranty=1');
  console.log('='.repeat(80));

  console.log(`\n1. OVERALL TOTAL CARS: ${d.total_cars}`);
  
  // Database check:
  const dbTotal = await db.query(`
    SELECT COUNT(DISTINCT c.id) as cnt
    FROM tbl_cars c
    WHERE c.is_deleted = 0 AND c.is_active = 1 AND c.listing_status = 'published'
      AND EXISTS (
        SELECT 1 FROM tbl_warranty_types wtt 
        WHERE wtt.id = c.mfk_warrenty_id 
          AND wtt.warranty_key IS NOT NULL 
          AND TRIM(wtt.warranty_key) != '' 
          AND wtt.warranty_key != 'no_warranty'
      )
  `);
  console.log(`   Database count for warranty=1: ${dbTotal[0].cnt}`);
  console.log(`   Match: ${d.total_cars === dbTotal[0].cnt ? '✅ MATCH' : '❌ MISMATCH'}`);

  // 2. BRANDS
  console.log(`\n2. BRAND COUNTS:`);
  let brandSum = 0;
  for (const b of d.brand_name || []) {
    brandSum += b.total;
    const dbB = await db.query(`
      SELECT COUNT(DISTINCT c.id) as cnt
      FROM tbl_cars c
      WHERE c.is_deleted = 0 AND c.is_active = 1 AND c.listing_status = 'published'
        AND TRIM(c.brandName) = ?
        AND EXISTS (
          SELECT 1 FROM tbl_warranty_types wtt 
          WHERE wtt.id = c.mfk_warrenty_id 
            AND wtt.warranty_key IS NOT NULL 
            AND TRIM(wtt.warranty_key) != '' 
            AND wtt.warranty_key != 'no_warranty'
        )
    `, [b.brand_name]);
    const match = b.total === dbB[0].cnt;
    console.log(`   - ${b.brand_name.padEnd(20)}: API=${b.total}, DB=${dbB[0].cnt} ${match ? '✅' : '❌'}`);
  }
  console.log(`   Total sum of brand counts: ${brandSum} / ${d.total_cars}`);

  // 3. FUEL TYPES
  console.log(`\n3. FUEL TYPES:`);
  let fuelSum = 0;
  for (const f of d.fuel_type || []) {
    if (f.total > 0) fuelSum += f.total;
    const dbF = await db.query(`
      SELECT COUNT(DISTINCT c.id) as cnt
      FROM tbl_cars c
      WHERE c.is_deleted = 0 AND c.is_active = 1 AND c.listing_status = 'published'
        AND c.fuel_type_id = ?
        AND EXISTS (
          SELECT 1 FROM tbl_warranty_types wtt 
          WHERE wtt.id = c.mfk_warrenty_id 
            AND wtt.warranty_key IS NOT NULL 
            AND TRIM(wtt.warranty_key) != '' 
            AND wtt.warranty_key != 'no_warranty'
        )
    `, [f.id]);
    const match = f.total === dbF[0].cnt;
    if (f.total > 0 || dbF[0].cnt > 0) {
      console.log(`   - ID ${f.id} (${(f.name || '').padEnd(28)}): API=${f.total}, DB=${dbF[0].cnt} ${match ? '✅' : '❌'}`);
    }
  }
  console.log(`   Sum of fuel counts: ${fuelSum} / ${d.total_cars}`);

  // 4. TRANSMISSION
  console.log(`\n4. TRANSMISSION:`);
  let transSum = 0;
  for (const t of d.transmission || []) {
    if (t.total > 0) transSum += t.total;
    const dbT = await db.query(`
      SELECT COUNT(DISTINCT c.id) as cnt
      FROM tbl_cars c
      WHERE c.is_deleted = 0 AND c.is_active = 1 AND c.listing_status = 'published'
        AND c.transmission_id = ?
        AND EXISTS (
          SELECT 1 FROM tbl_warranty_types wtt 
          WHERE wtt.id = c.mfk_warrenty_id 
            AND wtt.warranty_key IS NOT NULL 
            AND TRIM(wtt.warranty_key) != '' 
            AND wtt.warranty_key != 'no_warranty'
        )
    `, [t.id]);
    const match = t.total === dbT[0].cnt;
    if (t.total > 0 || dbT[0].cnt > 0) {
      console.log(`   - ID ${t.id} (${(t.name || '').padEnd(30)}): API=${t.total}, DB=${dbT[0].cnt} ${match ? '✅' : '❌'}`);
    }
  }
  console.log(`   Sum of transmission counts: ${transSum} / ${d.total_cars}`);

  // 5. BODY TYPE
  console.log(`\n5. BODY TYPE:`);
  let bodySum = 0;
  for (const bt of d.body_type || []) {
    if (bt.total > 0) bodySum += bt.total;
    const dbBt = await db.query(`
      SELECT COUNT(DISTINCT c.id) as cnt
      FROM tbl_cars c
      WHERE c.is_deleted = 0 AND c.is_active = 1 AND c.listing_status = 'published'
        AND c.body_type_id = ?
        AND EXISTS (
          SELECT 1 FROM tbl_warranty_types wtt 
          WHERE wtt.id = c.mfk_warrenty_id 
            AND wtt.warranty_key IS NOT NULL 
            AND TRIM(wtt.warranty_key) != '' 
            AND wtt.warranty_key != 'no_warranty'
        )
    `, [bt.id]);
    const match = bt.total === dbBt[0].cnt;
    if (bt.total > 0 || dbBt[0].cnt > 0) {
      console.log(`   - ID ${bt.id} (${(bt.name || '').padEnd(25)}): API=${bt.total}, DB=${dbBt[0].cnt} ${match ? '✅' : '❌'}`);
    }
  }
  console.log(`   Sum of body type counts: ${bodySum} / ${d.total_cars}`);

  // 6. SELLER TYPE
  console.log(`\n6. SELLER TYPE:`);
  for (const st of d.seller_type || []) {
    const actType = st.seller_type === 'business' ? 'company' : 'private';
    const dbSt = await db.query(`
      SELECT COUNT(DISTINCT c.id) as cnt
      FROM tbl_cars c
      JOIN tbl_users u ON u.id = c.user_id
      WHERE c.is_deleted = 0 AND c.is_active = 1 AND c.listing_status = 'published'
        AND u.account_type = ?
        AND EXISTS (
          SELECT 1 FROM tbl_warranty_types wtt 
          WHERE wtt.id = c.mfk_warrenty_id 
            AND wtt.warranty_key IS NOT NULL 
            AND TRIM(wtt.warranty_key) != '' 
            AND wtt.warranty_key != 'no_warranty'
        )
    `, [actType]);
    const match = st.total === dbSt[0].cnt;
    console.log(`   - ${st.seller_type.padEnd(15)}: API=${st.total}, DB=${dbSt[0].cnt} ${match ? '✅' : '❌'}`);
  }

  // 7. VEHICLE CONDITION
  console.log(`\n7. VEHICLE CONDITION:`);
  for (const vc of d.vehicle_condition || []) {
    const dbVc = await db.query(`
      SELECT COUNT(DISTINCT c.id) as cnt
      FROM tbl_cars c
      WHERE c.is_deleted = 0 AND c.is_active = 1 AND c.listing_status = 'published'
        AND c.carCondition = ?
        AND EXISTS (
          SELECT 1 FROM tbl_warranty_types wtt 
          WHERE wtt.id = c.mfk_warrenty_id 
            AND wtt.warranty_key IS NOT NULL 
            AND TRIM(wtt.warranty_key) != '' 
            AND wtt.warranty_key != 'no_warranty'
        )
    `, [vc.id]);
    const match = vc.total === dbVc[0].cnt;
    console.log(`   - ID ${vc.id} (${(vc.name || '').padEnd(35)}): API=${vc.total}, DB=${dbVc[0].cnt} ${match ? '✅' : '❌'}`);
  }

  // 8. ACCIDENT VEHICLE
  console.log(`\n8. ACCIDENT VEHICLE:`);
  for (const av of d.accident_vehicle || []) {
    const dbAv = await db.query(`
      SELECT COUNT(DISTINCT c.id) as cnt
      FROM tbl_cars c
      WHERE c.is_deleted = 0 AND c.is_active = 1 AND c.listing_status = 'published'
        AND c.vehicle_accident_status_id = ?
        AND EXISTS (
          SELECT 1 FROM tbl_warranty_types wtt 
          WHERE wtt.id = c.mfk_warrenty_id 
            AND wtt.warranty_key IS NOT NULL 
            AND TRIM(wtt.warranty_key) != '' 
            AND wtt.warranty_key != 'no_warranty'
        )
    `, [av.id]);
    const match = av.total === dbAv[0].cnt;
    console.log(`   - ID ${av.id} (${(av.name || '').padEnd(30)}): API=${av.total}, DB=${dbAv[0].cnt} ${match ? '✅' : '❌'}`);
  }

  // 9. MFK WARRANTY OBJECT
  console.log(`\n9. MFK & WARRANTY TOTALS IN OBJECT:`, d.mfk_warranty);
  const dbMfk = await db.query(`
    SELECT COUNT(DISTINCT c.id) as cnt
    FROM tbl_cars c
    WHERE c.is_deleted = 0 AND c.is_active = 1 AND c.listing_status = 'published'
      AND c.mfk_status_id IS NOT NULL AND c.mfk_status_id NOT IN (4, 5)
      AND EXISTS (
        SELECT 1 FROM tbl_warranty_types wtt 
        WHERE wtt.id = c.mfk_warrenty_id 
          AND wtt.warranty_key IS NOT NULL 
          AND TRIM(wtt.warranty_key) != '' 
          AND wtt.warranty_key != 'no_warranty'
      )
  `);
  console.log(`   Database count for both mfk AND warranty=1: ${dbMfk[0].cnt} (API returned: ${d.mfk_warranty?.mfk})`);
  console.log(`   Database count for warranty=1: ${dbTotal[0].cnt} (API returned: ${d.mfk_warranty?.warranty})`);

  // 10. EXTRAS
  console.log(`\n10. EXTRAS:`);
  for (const ex of d.extras || []) {
    console.log(`   - Key: ${ex.extra_key.padEnd(25)} | Count: ${ex.count}`);
  }

  server.close();
}

inspectAllCounts().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
