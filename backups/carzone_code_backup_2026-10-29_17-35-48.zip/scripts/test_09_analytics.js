import db from '../config/db.js';
import {
  createMockReqRes,
  logSuite,
  logTest,
  logPass,
  logFail,
  globalBugs
} from './test_helper.js';

import { getPriceRangeAnalytics } from '../controllers/shared/priceAnalytics.controller.js';
import { getKilometersRangeAnalytics } from '../controllers/shared/kmAnalytics.controller.js';
import { getYearRangeAnalytics } from '../controllers/shared/yearAnalytics.controller.js';
import { getEnginePowerAnalytics, getLeasingAnalytics } from '../controllers/shared/leasingEngineAnalytics.controller.js';
import { getCubicCapacityAnalytics, getConsumptionAnalytics, getCo2EmissionAnalytics } from '../controllers/shared/vehicleSpecsAnalytics.controller.js';

export async function runAnalyticsTests() {
  const MODULE = 'Analytics';
  logSuite(MODULE);

  // ----------------------------------------------------
  // Test 1: getPriceRangeAnalytics
  // ----------------------------------------------------
  logTest('getPriceRangeAnalytics: Calculate price distribution');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en', car_price_from: 10000, car_price_to: 80000 }
    });
    await getPriceRangeAnalytics(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass('Price range analytics calculated successfully');
    } else {
      logFail(MODULE, 'getPriceRangeAnalytics failed', new Error(`Status ${resp.statusCode}`), null, 'priceAnalytics.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getPriceRangeAnalytics threw error', err, null, 'priceAnalytics.controller.js');
  }

  // ----------------------------------------------------
  // Test 2: getKilometersRangeAnalytics
  // ----------------------------------------------------
  logTest('getKilometersRangeAnalytics: Calculate mileage distribution');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en', from_km: 0, to_km: 100000 }
    });
    await getKilometersRangeAnalytics(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass('Mileage range analytics calculated successfully');
    } else {
      logFail(MODULE, 'getKilometersRangeAnalytics failed', new Error(`Status ${resp.statusCode}`), null, 'kmAnalytics.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getKilometersRangeAnalytics threw error', err, null, 'kmAnalytics.controller.js');
  }

  // ----------------------------------------------------
  // Test 3: getYearRangeAnalytics
  // ----------------------------------------------------
  logTest('getYearRangeAnalytics: Calculate registration year distribution');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en', from_year: 2018, to_year: 2024 }
    });
    await getYearRangeAnalytics(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass('Year range analytics calculated successfully');
    } else {
      logFail(MODULE, 'getYearRangeAnalytics failed', new Error(`Status ${resp.statusCode}`), null, 'yearAnalytics.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getYearRangeAnalytics threw error', err, null, 'yearAnalytics.controller.js');
  }

  // ----------------------------------------------------
  // Test 4: getEnginePowerAnalytics
  // ----------------------------------------------------
  logTest('getEnginePowerAnalytics: Engine power (PS/kW) analytics');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en' }
    });
    await getEnginePowerAnalytics(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass('Engine power analytics calculated successfully');
    } else {
      logFail(MODULE, 'getEnginePowerAnalytics failed', new Error(`Status ${resp.statusCode}`), null, 'leasingEngineAnalytics.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getEnginePowerAnalytics threw error', err, null, 'leasingEngineAnalytics.controller.js');
  }

  // ----------------------------------------------------
  // Test 5: getCubicCapacityAnalytics
  // ----------------------------------------------------
  logTest('getCubicCapacityAnalytics: Cubic capacity range distribution');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en' }
    });
    await getCubicCapacityAnalytics(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass('Cubic capacity analytics calculated successfully');
    } else {
      logFail(MODULE, 'getCubicCapacityAnalytics failed', new Error(`Status ${resp.statusCode}`), null, 'vehicleSpecsAnalytics.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getCubicCapacityAnalytics threw error', err, null, 'vehicleSpecsAnalytics.controller.js');
  }

  // ----------------------------------------------------
  // Test 6: getConsumptionAnalytics
  // ----------------------------------------------------
  logTest('getConsumptionAnalytics: Fuel consumption distribution');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en' }
    });
    await getConsumptionAnalytics(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass('Fuel consumption analytics calculated successfully');
    } else {
      logFail(MODULE, 'getConsumptionAnalytics failed', new Error(`Status ${resp.statusCode}`), null, 'vehicleSpecsAnalytics.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getConsumptionAnalytics threw error', err, null, 'vehicleSpecsAnalytics.controller.js');
  }

  // ----------------------------------------------------
  // Test 7: getCo2EmissionAnalytics
  // ----------------------------------------------------
  logTest('getCo2EmissionAnalytics: CO2 emission analytics');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en' }
    });
    await getCo2EmissionAnalytics(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass('CO2 emission analytics calculated successfully');
    } else {
      logFail(MODULE, 'getCo2EmissionAnalytics failed', new Error(`Status ${resp.statusCode}`), null, 'vehicleSpecsAnalytics.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getCo2EmissionAnalytics threw error', err, null, 'vehicleSpecsAnalytics.controller.js');
  }
}

if (process.argv[1] && process.argv[1].endsWith('test_09_analytics.js')) {
  runAnalyticsTests().then(() => {
    console.log(`\nTests finished. Bugs found so far: ${globalBugs.bugs.length}`);
    process.exit(0);
  });
}
