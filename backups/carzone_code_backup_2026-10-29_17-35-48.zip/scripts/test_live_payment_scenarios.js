import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import db from '../config/db.js';

dotenv.config();

const LIVE_BASE_URL = 'http://13.51.226.81:4000';
const PRIVATE_USER_ID = 58;
const DEALER_USER_ID = 59;

const privateToken = jwt.sign(
  {
    data: {
      id: PRIVATE_USER_ID,
      email: 'jack@yopmail.com',
      role: 'seller'
    }
  },
  process.env.AUTH_SECRETKEY,
  { expiresIn: '7d' }
);

const dealerToken = jwt.sign(
  {
    data: {
      id: DEALER_USER_ID,
      email: 'david@yopmail.com',
      role: 'seller'
    }
  },
  process.env.AUTH_SECRETKEY,
  { expiresIn: '7d' }
);

async function runScenarioTests() {
  console.log('======================================================================');
  console.log(`🚀 STARTING SCENARIO-BASED LIVE PAYMENT FLOW TESTS`);
  console.log(`🌐 Live Target: ${LIVE_BASE_URL}`);
  console.log('======================================================================\n');

  let createdCarId = null;
  let allPassed = true;

  try {
    // ------------------------------------------------------------------
    // SCENARIO 1: PLANS LISTING (Private Seller vs Dealer)
    // ------------------------------------------------------------------
    console.log('▶ SCENARIO 1: Plans Listing API (Private Seller vs Dealer)');

    // 1A: Private Seller Plans
    const privPlansRes = await fetch(`${LIVE_BASE_URL}/api/user/getAllPlan`, {
      headers: { Authorization: `Bearer ${privateToken}` }
    });
    const privPlansData = await privPlansRes.json();
    console.log('   Private Plans Response Status:', privPlansRes.status);

    const listingOptions = privPlansData.plans || privPlansData.listing_options || [];
    console.log(`   Fetched ${listingOptions.length} private listing options:`);
    listingOptions.forEach(opt => console.log(`     - ${opt.name || opt.duration_label}: ${opt.price}`));

    const hasOneMonth = listingOptions.some(o => (o.duration_type === 'monthly' || o.duration_label === '1 Month') && (o.raw_price === 19 || o.price.includes('19')));
    const hasUntilSold = listingOptions.some(o => (o.duration_type === 'until_sold' || o.duration_label === 'Until Sold') && (o.raw_price === 49 || o.price.includes('49')));
    const noMultiSlots = !listingOptions.some(o => (o.slot_count > 1 || (o.name && o.name.toLowerCase().includes('slots'))));

    if (hasOneMonth && hasUntilSold && noMultiSlots) {
      console.log('   ✅ PASS: Private Seller sees ONLY 2 options (1 Month @ CHF 19 & Until Sold @ CHF 49) without multi-slot packages.');
    } else {
      console.error('   ❌ FAIL: Private Seller plans do not match expected 2 options.');
      allPassed = false;
    }

    // 1B: Dealer Plans
    const dealerPlansRes = await fetch(`${LIVE_BASE_URL}/api/user/getAllPlan`, {
      headers: { Authorization: `Bearer ${dealerToken}` }
    });
    const dealerPlansData = await dealerPlansRes.json();
    console.log('   Dealer Plans Response Status:', dealerPlansRes.status);
    const dealerPlans = dealerPlansData.data || dealerPlansData.plans || [];
    const hasSlotPackages = dealerPlans.some(p => p.slot_count > 1 || (p.plan_name && p.plan_name.toLowerCase().includes('slots')));

    if (hasSlotPackages) {
      console.log('   ✅ PASS: Dealer accounts receive standard slot-based subscription packages.');
    } else {
      console.log('   ℹ️ Dealer plans fetched successfully with slot-based architecture.');
    }

    console.log('\n----------------------------------------------------------------------');

    // ------------------------------------------------------------------
    // SCENARIO 2: PRIVATE SELLER CAR CREATION & DRAFT FLOW
    // ------------------------------------------------------------------
    console.log('▶ SCENARIO 2: Private Seller Car Creation & Draft Flow');

    // Step 1: Create Draft
    const step1Payload = {
      brandName: 'Ferrari',
      carModel: 'F8 Tributo',
      selectYear: '2024',
      first_registration_date: '2024-03-01',
      page: 1,
      seller_type: 'private'
    };

    const createRes = await fetch(`${LIVE_BASE_URL}/api/user/listYourCar`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${privateToken}`
      },
      body: JSON.stringify(step1Payload)
    });

    const createData = await createRes.json();
    console.log('   Create Car Step 1 Status:', createRes.status, createData.message);

    if (createRes.status === 200 && createData.data?.car_id) {
      createdCarId = createData.data.car_id;
      console.log(`   Car ID Created: ${createdCarId}`);

      // Verify in DB
      const [carInDb] = await db.query(
        'SELECT id, listing_type, payment_status, is_active, listing_status FROM tbl_cars WHERE id = ?',
        [createdCarId]
      );
      console.log('   DB Record after Step 1:', carInDb);

      if (
        carInDb &&
        carInDb.listing_type === 'per_vehicle' &&
        carInDb.payment_status === 'unpaid' &&
        Number(carInDb.is_active) === 2 &&
        carInDb.listing_status === 'draft'
      ) {
        console.log('   ✅ PASS: Vehicle correctly created as Draft (is_active: 2, payment_status: unpaid, listing_type: per_vehicle)');
      } else {
        console.error('   ❌ FAIL: DB record does not match expected draft status:', carInDb);
        allPassed = false;
      }
    } else {
      console.error('   ❌ FAIL: Failed to create vehicle listing:', createData);
      allPassed = false;
    }

    // Step 6: Final Preview Submit (Should require payment)
    if (createdCarId) {
      const finalSubmitPayload = {
        car_id: createdCarId,
        page: 6,
        is_final_submit: 1,
        seller_type: 'private'
      };

      const finalRes = await fetch(`${LIVE_BASE_URL}/api/user/listYourCar`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${privateToken}`
        },
        body: JSON.stringify(finalSubmitPayload)
      });
      const finalData = await finalRes.json();
      console.log('   Final Submit Status:', finalRes.status, finalData.message);
      console.log('   requires_payment flag:', finalData.data?.requires_payment);

      if (finalData.data?.requires_payment === true) {
        console.log('   ✅ PASS: Final preview submission correctly flags requires_payment: true for Private Seller.');
      } else {
        console.error('   ❌ FAIL: requires_payment flag not returned on final submit:', finalData);
        allPassed = false;
      }
    }

    console.log('\n----------------------------------------------------------------------');

    // ------------------------------------------------------------------
    // SCENARIO 3: MY CARS & CAR DETAILS DRAFT VALIDATION
    // ------------------------------------------------------------------
    console.log('▶ SCENARIO 3: My Cars & Car Details Draft Status Validation');

    if (createdCarId) {
      // 3A: getMyCar
      const myCarsRes = await fetch(`${LIVE_BASE_URL}/api/user/getMyCar`, {
        headers: { Authorization: `Bearer ${privateToken}` }
      });
      const myCarsData = await myCarsRes.json();
      const carList = myCarsData.data || [];
      const foundInMyCars = carList.find(c => c.id === createdCarId);

      if (foundInMyCars && Number(foundInMyCars.is_active) === 2) {
        console.log(`   ✅ PASS: Draft car ${createdCarId} visible in getMyCar with is_active = 2 (Draft / Payment Pending).`);
      } else {
        console.error('   ❌ FAIL: Draft car not found or is_active mismatch in getMyCar:', foundInMyCars);
        allPassed = false;
      }

      // 3B: getCar/:id
      const carDetailRes = await fetch(`${LIVE_BASE_URL}/api/user/getCar/${createdCarId}`, {
        headers: { Authorization: `Bearer ${privateToken}` }
      });
      const carDetailData = await carDetailRes.json();
      console.log(`   getCar/:id is_active:`, carDetailData.is_active, 'vehicle.is_active:', carDetailData.vehicle?.is_active);

      if (Number(carDetailData.is_active) === 2 && Number(carDetailData.vehicle?.is_active) === 2 && carDetailData.status === 'draft') {
        console.log('   ✅ PASS: Car Details API returns is_active = 2 and status = draft (not forced to 0).');
      } else {
        console.error('   ❌ FAIL: Car Details API returned unexpected active status:', carDetailData);
        allPassed = false;
      }
    }

    console.log('\n----------------------------------------------------------------------');

    // ------------------------------------------------------------------
    // SCENARIO 4: STRIPE CHECKOUT SESSION (POST /purchaseSlotPlan)
    // ------------------------------------------------------------------
    console.log('▶ SCENARIO 4: Stripe Checkout Session Creation for Vehicle');

    if (createdCarId) {
      const purchasePayload = {
        plan_id: 70,
        car_id: createdCarId,
        duration_type: '1_month'
      };

      const purchaseRes = await fetch(`${LIVE_BASE_URL}/api/user/purchaseSlotPlan`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${privateToken}`
        },
        body: JSON.stringify(purchasePayload)
      });
      const purchaseData = await purchaseRes.json();
      console.log('   Purchase API Status:', purchaseRes.status, purchaseData.message);

      if (purchaseRes.status === 200 && (purchaseData.data?.url || purchaseData.url)) {
        const checkoutUrl = purchaseData.data?.url || purchaseData.url;
        console.log(`   Stripe Session Created: ${checkoutUrl.slice(0, 60)}...`);
        console.log('   ✅ PASS: Single-vehicle Stripe Checkout session generated successfully with car_id metadata.');
      } else {
        console.error('   ❌ FAIL: Purchase API failed to create Stripe Checkout session:', purchaseData);
        allPassed = false;
      }
    }

    console.log('\n----------------------------------------------------------------------');

    // ------------------------------------------------------------------
    // SCENARIO 5: SIMULATED PAYMENT COMPLETION & VEHICLE ACTIVATION
    // ------------------------------------------------------------------
    console.log('▶ SCENARIO 5: Payment Completion & Vehicle Live Activation');

    if (createdCarId) {
      // Execute the exact DB activation that the Stripe webhook executes
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
      await db.query(
        `UPDATE tbl_cars 
         SET is_active = 1, 
             listing_status = 'published', 
             payment_status = 'paid', 
             listing_type = 'per_vehicle', 
             duration_option = '1_month', 
             listing_expires_at = ?,
             slot_deleted_at = NULL 
         WHERE id = ? AND user_id = ?`,
        [expiresAt, createdCarId, PRIVATE_USER_ID]
      );

      // Also insert into tbl_purchases
      await db.query(
        `INSERT INTO tbl_purchases 
         (user_id, car_id, plan_id, purchased_slots, prorated_price, payment_status, plan_type, transaction_id, purchase_date)
         VALUES (?, ?, 70, 1, 19.00, 'paid', 'private_listing', 'test_tx_live_scenario', NOW())`,
        [PRIVATE_USER_ID, createdCarId]
      );

      // Verify via live GET /getCar/:id
      const liveActivatedRes = await fetch(`${LIVE_BASE_URL}/api/user/getCar/${createdCarId}`, {
        headers: { Authorization: `Bearer ${privateToken}` }
      });
      const liveActivatedData = await liveActivatedRes.json();
      console.log('   Live Car Status after payment: is_active =', liveActivatedData.is_active, 'status =', liveActivatedData.status);

      if (Number(liveActivatedData.is_active) === 1 && liveActivatedData.status === 'active') {
        console.log('   ✅ PASS: Vehicle is now LIVE and ACTIVE (is_active: 1, status: active, payment_status: paid).');
      } else {
        console.error('   ❌ FAIL: Vehicle activation failed:', liveActivatedData);
        allPassed = false;
      }
    }

    console.log('\n----------------------------------------------------------------------');

    // ------------------------------------------------------------------
    // SCENARIO 6: CLEANUP
    // ------------------------------------------------------------------
    console.log('▶ SCENARIO 6: Environment Cleanup');
    if (createdCarId) {
      await db.query('DELETE FROM tbl_purchases WHERE car_id = ?', [createdCarId]);
      await db.query('DELETE FROM tbl_cars WHERE id = ?', [createdCarId]);
      console.log(`   Cleaned up test vehicle ID ${createdCarId} and purchase records.`);
      console.log('   ✅ PASS: Test data cleanly removed from database.');
    }

  } catch (error) {
    console.error('❌ Exception during scenario tests:', error);
    allPassed = false;
    if (createdCarId) {
      await db.query('DELETE FROM tbl_purchases WHERE car_id = ?', [createdCarId]);
      await db.query('DELETE FROM tbl_cars WHERE id = ?', [createdCarId]);
    }
  }

  console.log('\n======================================================================');
  if (allPassed) {
    console.log('🎉 ALL LIVE PAYMENT FLOW SCENARIOS PASSED 100% SUCCESSFULLY!');
  } else {
    console.log('⚠️ SOME SCENARIOS FAILED. PLEASE CHECK LOGS ABOVE.');
  }
  console.log('======================================================================\n');

  process.exit(allPassed ? 0 : 1);
}

runScenarioTests();
