import http from 'http';
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import route from '../routes/index.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use('/api', route);

async function testUser250Notifications() {
  const server = http.createServer(app);
  await new Promise(r => server.listen(0, r));
  const port = server.address().port;
  const baseUrl = `http://127.0.0.1:${port}`;

  // Sign token for user 250
  const token = jwt.sign(
    { data: { id: 250, role: 'user' } },
    process.env.AUTH_SECRETKEY,
    { expiresIn: '1h' }
  );

  console.log('Testing GET /api/user/fetchNotificationByBuyersIds for User 250...');
  const res = await fetch(`${baseUrl}/api/user/fetchNotificationByBuyersIds`, {
    headers: {
      'Authorization': `Bearer ${token}`,
      'Accept-Language': 'en'
    }
  });

  const json = await res.json();
  console.log('HTTP Status:', res.status);
  console.log('Response Message:', json.message);
  console.log('Total notifications returned:', (json.data?.allNotification || []).length);
  console.log('Unread notifications count:', json.data?.unReadNotifications);
  
  const notifications = json.data?.allNotification || [];
  const chatCount = notifications.filter(n => (n.notificationType || '').toLowerCase() === 'chat').length;
  console.log('Chat notifications in response:', chatCount);

  console.log('\nNotifications List Returned:');
  notifications.forEach((n, idx) => {
    console.log(`[#${idx + 1}] ID: ${n.id} | Type: ${n.notificationType} | Title: "${n.title}" | Body: "${n.body}" | Date: ${n.date}`);
  });

  server.close();
}

testUser250Notifications().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
