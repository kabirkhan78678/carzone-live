import db from '../config/db.js';
import {
  createStoryModel,
  getStoryByIdModel,
  markStoryViewedModel,
  getStoryViewersModel,
  getUserActiveStoriesModel,
  deleteStoryModel
} from '../models/user.model.js';
import {
  createStory,
  markStoryViewed,
  getMyStories,
  getStoryById
} from '../controllers/shared/story.controller.js';
import { createMockReqRes } from './test_helper.js';

async function testOwnerViewExclusion() {
  console.log('\n=============================================');
  console.log('🧪 TESTING OWNER VIEW & COUNT EXCLUSION');
  console.log('=============================================\n');

  try {
    const users = await db.query('SELECT id, fullName, email FROM tbl_users LIMIT 2');
    const userA = users[0];
    const userB = users[1];

    console.log(`User A (Story Owner): ID ${userA.id} (${userA.fullName})`);
    console.log(`User B (External Viewer): ID ${userB.id} (${userB.fullName})\n`);

    // 1. Create a story by User A
    const storyRes = await createStoryModel({
      user_id: userA.id,
      media_url: 'http://13.51.226.81:4000/profile/test-owner-exclusion.jpg',
      caption: 'Owner Exclusion Test Story'
    });
    const storyId = storyRes.insertId;
    console.log(`1. Story created with ID: ${storyId}`);

    // 2. User A attempts to view their OWN story via controller
    console.log('2. User A views their own story (POST /stories/:id/views)...');
    const { req: reqOwnerView, res: resOwnerView, getResponse: getRespOwnerView } = createMockReqRes({
      user: userA,
      params: { id: storyId }
    });
    await markStoryViewed(reqOwnerView, resOwnerView);
    const ownerViewResp = getRespOwnerView();
    console.log(`   Response is_new_view: ${ownerViewResp.data.data?.is_new_view} (Expected: false)`);

    // Also check direct model attempt to insert owner view
    const directModelRes = await markStoryViewedModel({ story_id: storyId, viewer_id: userA.id });
    console.log(`   Direct SQL Model affectedRows: ${directModelRes.affectedRows} (Expected: 0)`);

    // Verify DB tbl_story_views table has 0 rows for this story
    const dbViewsAfterOwner = await db.query('SELECT * FROM tbl_story_views WHERE story_id = ?', [storyId]);
    console.log(`   DB rows in tbl_story_views: ${dbViewsAfterOwner.length} (Expected: 0)`);
    if (dbViewsAfterOwner.length !== 0) {
      throw new Error('Owner view was saved in DB!');
    }

    // 3. Check getStoryById for User A
    const storyDetails = await getStoryByIdModel(storyId, userA.id);
    console.log(`3. Story views_count: ${storyDetails.views_count} (Expected: 0)`);
    if (Number(storyDetails.views_count) !== 0) {
      throw new Error(`views_count expected 0, got ${storyDetails.views_count}`);
    }

    // 4. Check getMyStories for User A
    console.log('4. Checking getMyStories for User A...');
    const { req: reqMyStories, res: resMyStories, getResponse: getRespMyStories } = createMockReqRes({
      user: userA
    });
    await getMyStories(reqMyStories, resMyStories);
    const myStoriesResp = getRespMyStories();
    const myStory = myStoriesResp.data.data.find(s => s.id === storyId);
    console.log(`   My story views_count: ${myStory.views_count} (Expected: 0)`);
    console.log(`   My story viewers list count: ${myStory.viewers.length} (Expected: 0)`);
    if (myStory.viewers.length !== 0 || Number(myStory.views_count) !== 0) {
      throw new Error('Owner is appearing in viewers list or views_count > 0');
    }

    // 5. Now User B views User A's story
    console.log('\n5. External User B views User A story...');
    const { req: reqUserBView, res: resUserBView, getResponse: getRespUserBView } = createMockReqRes({
      user: userB,
      params: { id: storyId }
    });
    await markStoryViewed(reqUserBView, resUserBView);
    const userBViewResp = getRespUserBView();
    console.log(`   User B view response is_new_view: ${userBViewResp.data.data?.is_new_view} (Expected: true)`);

    // 6. User A views their story again
    await markStoryViewed(reqOwnerView, resOwnerView);

    // 7. Check getMyStories again
    console.log('6. Checking getMyStories for User A after User B viewed...');
    await getMyStories(reqMyStories, resMyStories);
    const myStoriesRespAfter = getRespMyStories();
    const myStoryAfter = myStoriesRespAfter.data.data.find(s => s.id === storyId);
    console.log(`   My story views_count: ${myStoryAfter.views_count} (Expected: 1)`);
    console.log(`   My story viewers list count: ${myStoryAfter.viewers.length} (Expected: 1)`);
    console.log(`   Viewer: ${myStoryAfter.viewers[0]?.user_name} (ID: ${myStoryAfter.viewers[0]?.viewer_id})`);

    const ownerInViewers = myStoryAfter.viewers.some(v => v.viewer_id === userA.id);
    if (ownerInViewers) {
      throw new Error('Owner found in viewers list!');
    }
    console.log(`   Owner in viewers list?: NO (Correct!)`);

    // Clean up
    await deleteStoryModel(storyId, userA.id);
    await db.query('DELETE FROM tbl_stories WHERE id = ?', [storyId]);
    console.log('\n✔ Test story cleaned up.');
    console.log('🎉 ALL OWNER VIEW EXCLUSION TESTS PASSED! 🚀\n');
    process.exit(0);

  } catch (err) {
    console.error('❌ Test failed:', err);
    process.exit(1);
  }
}

testOwnerViewExclusion();
