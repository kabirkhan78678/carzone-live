import express from 'express';
import http from 'http';
import axios from 'axios';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import db from '../config/db.js';
import route from '../routes/index.js';
import storyRoutes from '../routes/story.js';
import {
  createStory,
  getActiveStories,
  markStoryViewed,
  getMyStories,
  getStoryById,
  deleteStory
} from '../controllers/shared/story.controller.js';
import { deleteStoryModel } from '../models/user.model.js';
import { createMockReqRes, logSuite, logTest, logPass, logFail, globalBugs } from './test_helper.js';


dotenv.config();

const JWT_SECRET = process.env.AUTH_SECRETKEY;

function generateToken(user) {
  return jwt.sign({ data: { id: user.id, role: user.role || 'user' } }, JWT_SECRET, { expiresIn: '1d' });
}

async function runAllStoriesTests() {
  logSuite('STORY FEATURE - CONTROLLER & HTTP INTEGRATION AUDIT');

  let userA, userB;
  let testStoryIdA, testStoryIdB;

  try {
    // 0. Setup test users from DB
    const users = await db.query('SELECT id, fullName, email, language FROM tbl_users LIMIT 2');
    if (!users || users.length < 2) {
      console.log('⚠ At least 2 users required in tbl_users.');
      process.exit(1);
    }
    userA = users[0];
    userB = users[1];

    console.log(`\nUsing User A: ID ${userA.id} (${userA.fullName})`);
    console.log(`Using User B: ID ${userB.id} (${userB.fullName})`);

    // =========================================================================
    // PART 1: CONTROLLER UNIT TESTS
    // =========================================================================

    // Test 1: Create Story Validation (Missing Image)
    logTest('1. POST /api/stories - Fails if image is missing');
    {
      const { req, res, getResponse } = createMockReqRes({
        user: userA,
        body: { caption: 'No image provided' }
      });
      await createStory(req, res);
      const { statusCode, data } = getResponse();
      if (statusCode === 400 && data.success === false) {
        logPass(`Correctly rejected missing image with 400: "${data.message}"`);
      } else {
        logFail('Stories', 'Create without image', new Error(`Unexpected: ${statusCode}`), data);
      }
    }

    // Test 2: Create Story for User A (With uploaded file simulation)
    logTest('2. POST /api/stories - Creates story with uploaded image for User A');
    {
      const { req, res, getResponse } = createMockReqRes({
        user: userA,
        file: { filename: 'test-story-a.jpg' },
        body: { caption: 'BMW M5 Competition' }
      });
      await createStory(req, res);
      const { statusCode, data } = getResponse();
      if (statusCode === 201 && data.success === true && data.data.id) {
        testStoryIdA = data.data.id;
        logPass(`Story created successfully with ID: ${testStoryIdA}, URL: ${data.data.media_url}`);
      } else {
        logFail('Stories', 'Create story User A', new Error('Failed to create story'), data);
      }
    }

    // Test 3: Create Story for User B (With media_url payload)
    logTest('3. POST /api/stories - Creates story with media_url in body for User B');
    {
      const { req, res, getResponse } = createMockReqRes({
        user: userB,
        body: {
          media_url: 'http://13.51.226.81:4000/profile/test-story-b.png',
          caption: 'Audi RS6 Avant'
        }
      });
      await createStory(req, res);
      const { statusCode, data } = getResponse();
      if (statusCode === 201 && data.success === true && data.data.id) {
        testStoryIdB = data.data.id;
        logPass(`Story created successfully with ID: ${testStoryIdB}`);
      } else {
        logFail('Stories', 'Create story User B', new Error('Failed to create story'), data);
      }
    }

    // Test 4: Get Active Stories from perspective of User A
    logTest('4. GET /api/stories - Grouped by user with seen/unseen status');
    {
      const { req, res, getResponse } = createMockReqRes({
        user: userA
      });
      await getActiveStories(req, res);
      const { statusCode, data } = getResponse();
      if (statusCode === 200 && Array.isArray(data.data)) {
        const myGroup = data.data.find(u => u.user_id === userA.id);
        const otherGroup = data.data.find(u => u.user_id === userB.id);

        if (!myGroup && otherGroup) {
          const userBStory = otherGroup.stories.find(s => s.id === testStoryIdB);
          if (userBStory && userBStory.is_seen === false && otherGroup.all_seen === false) {
            logPass(`Own stories excluded from GET /stories (myGroup is undefined). User B story returned correctly (is_seen=false, all_seen=false).`);
          } else {
            logFail('Stories', 'Seen status check', new Error('User B story should be unseen'), otherGroup);
          }
        } else {
          logFail('Stories', 'Own story exclusion', new Error('Logged-in user own stories should NOT appear in GET /stories'), data.data);
        }

      } else {
        logFail('Stories', 'Get active stories', new Error('Failed to get active stories'), data);
      }
    }

    // Test 5: Mark User B's Story as Viewed by User A
    logTest('5. POST /api/stories/:id/views - Mark story as viewed');
    {
      const { req, res, getResponse } = createMockReqRes({
        user: userA,
        params: { id: testStoryIdB }
      });
      await markStoryViewed(req, res);
      const { statusCode, data } = getResponse();
      if (statusCode === 200 && data.success === true && data.data.is_new_view === true) {
        logPass(`Story ${testStoryIdB} viewed by User A: is_new_view=true`);
      } else {
        logFail('Stories', 'Mark viewed', new Error('Failed marking story viewed'), data);
      }
    }

    // Test 6: Duplicate View Prevention
    logTest('6. POST /api/stories/:id/views - Duplicate view prevents duplicate record');
    {
      const { req, res, getResponse } = createMockReqRes({
        user: userA,
        params: { id: testStoryIdB }
      });
      await markStoryViewed(req, res);
      const { statusCode, data } = getResponse();
      if (statusCode === 200 && data.success === true && data.data.is_new_view === false) {
        logPass(`Duplicate view safely handled: is_new_view=false (no duplicate row)`);
      } else {
        logFail('Stories', 'Duplicate view check', new Error('Duplicate should return is_new_view=false'), data);
      }
    }

    // Test 7: Verify User B's story is now marked as seen for User A
    logTest('7. GET /api/stories - After viewing, User B story status updates to is_seen=true');
    {
      const { req, res, getResponse } = createMockReqRes({
        user: userA
      });
      await getActiveStories(req, res);
      const { statusCode, data } = getResponse();
      const otherGroup = data.data.find(u => u.user_id === userB.id);
      const userBStory = otherGroup?.stories.find(s => s.id === testStoryIdB);
      if (userBStory && userBStory.is_seen === true && otherGroup.all_seen === true) {
        logPass(`Status updated: is_seen=true, all_seen=true`);
      } else {
        logFail('Stories', 'Seen update check', new Error('Story should now be marked seen'), otherGroup);
      }
    }

    // Test 8: My Stories Endpoint for User B (Viewer list verification)
    logTest('8. GET /api/stories/my-stories - Returns active stories with viewer list');
    {
      const { req, res, getResponse } = createMockReqRes({
        user: userB
      });
      await getMyStories(req, res);
      const { statusCode, data } = getResponse();
      const myStory = data.data.find(s => s.id === testStoryIdB);
      if (myStory && myStory.views_count >= 1 && Array.isArray(myStory.viewers)) {
        const viewerA = myStory.viewers.find(v => v.viewer_id === userA.id);
        if (viewerA && viewerA.user_name) {
          logPass(`My Stories returned views_count=${myStory.views_count}, viewer found: ${viewerA.user_name} (ID: ${viewerA.viewer_id})`);
        } else {
          logFail('Stories', 'My Stories viewers list', new Error('Viewer A not found in viewers'), myStory);
        }
      } else {
        logFail('Stories', 'My Stories fetch', new Error('Story or viewers missing'), data);
      }
    }

    // Test 9: Get Story by ID as Owner vs Non-Owner
    logTest('9. GET /api/stories/:id - Story details with owner viewers');
    {
      // As Owner (User B)
      const { req: reqOwner, res: resOwner, getResponse: getRespOwner } = createMockReqRes({
        user: userB,
        params: { id: testStoryIdB }
      });
      await getStoryById(reqOwner, resOwner);
      const ownerResp = getRespOwner();

      // As Non-Owner (User A)
      const { req: reqViewer, res: resViewer, getResponse: getRespViewer } = createMockReqRes({
        user: userA,
        params: { id: testStoryIdB }
      });
      await getStoryById(reqViewer, resViewer);
      const viewerResp = getRespViewer();

      if (ownerResp.data.data.is_my_story === true && Array.isArray(ownerResp.data.data.viewers) &&
          viewerResp.data.data.is_my_story === false && !viewerResp.data.data.viewers) {
        logPass(`Owner gets private viewers list; Non-owner gets standard story detail.`);
      } else {
        logFail('Stories', 'Single story authorization detail', new Error('Owner vs Viewer payload discrepancy'));
      }
    }

    // Test 10: Delete Story Authorization (User A cannot delete User B's story)
    logTest('10. DELETE /api/stories/:id - Rejects unauthorized deletion attempt (403)');
    {
      const { req, res, getResponse } = createMockReqRes({
        user: userA, // User A tries to delete User B's story
        params: { id: testStoryIdB }
      });
      await deleteStory(req, res);
      const { statusCode, data } = getResponse();
      if (statusCode === 403 && data.success === false) {
        logPass(`Unauthorized delete correctly rejected with 403: "${data.message}"`);
      } else {
        logFail('Stories', 'Unauthorized delete', new Error(`Expected 403, got ${statusCode}`), data);
      }
    }

    // Test 11: Delete Story by Owner
    logTest('11. DELETE /api/stories/:id - Owner successfully deletes story');
    {
      const { req, res, getResponse } = createMockReqRes({
        user: userB, // Owner deletes
        params: { id: testStoryIdB }
      });
      await deleteStory(req, res);
      const { statusCode, data } = getResponse();
      if (statusCode === 200 && data.success === true) {
        logPass(`Owner deleted story successfully.`);
      } else {
        logFail('Stories', 'Owner delete', new Error('Failed to delete story'), data);
      }
    }

    // Test 12: Verify Deleted Story Excluded
    logTest('12. GET /api/stories/:id - Deleted story returns 404');
    {
      const { req, res, getResponse } = createMockReqRes({
        user: userA,
        params: { id: testStoryIdB }
      });
      await getStoryById(req, res);
      const { statusCode, data } = getResponse();
      if (statusCode === 404 && data.success === false) {
        logPass(`Deleted story correctly returns 404 Not Found.`);
      } else {
        logFail('Stories', 'Deleted story 404 check', new Error(`Expected 404, got ${statusCode}`), data);
      }
    }

    // Clean up User A's test story
    await deleteStoryModel(testStoryIdA, userA.id);

    // =========================================================================
    // PART 2: REAL HTTP SERVER INTEGRATION TESTS
    // =========================================================================
    logSuite('REAL HTTP REQUESTS (EXPRESS NETWORK STACK)');

    const testApp = express();
    testApp.use(express.json());
    testApp.use('/api', route);
    testApp.use('/stories', storyRoutes);

    const testServer = http.createServer(testApp);
    const TEST_PORT = 4123;

    await new Promise((resolve) => testServer.listen(TEST_PORT, resolve));
    console.log(`🚀 Test HTTP server running on port ${TEST_PORT}`);

    const tokenA = generateToken(userA);
    const tokenB = generateToken(userB);

    // HTTP Test 1: GET /api/stories as Guest (Unauthenticated)
    logTest('HTTP 1. GET /api/stories (Public / Guest)');
    {
      const res = await axios.get(`http://localhost:${TEST_PORT}/api/stories`);
      if (res.status === 200 && res.data.success === true) {
        logPass(`Guest request succeeded (HTTP 200) with message: "${res.data.message}"`);
      } else {
        logFail('Stories HTTP', 'Guest active stories', new Error('Failed guest request'), res.data);
      }
    }

    // HTTP Test 2: POST /api/stories via HTTP with Bearer Token
    logTest('HTTP 2. POST /api/stories with Bearer Token');
    let httpStoryId;
    {
      const res = await axios.post(
        `http://localhost:${TEST_PORT}/api/stories`,
        {
          media_url: 'http://13.51.226.81:4000/profile/http-test-story.jpg',
          caption: 'HTTP Integration Test'
        },
        {
          headers: {
            Authorization: `Bearer ${tokenA}`
          }
        }
      );
      if (res.status === 201 && res.data.success === true && res.data.data.id) {
        httpStoryId = res.data.data.id;
        logPass(`HTTP story created successfully with ID: ${httpStoryId}`);
      } else {
        logFail('Stories HTTP', 'HTTP create story', new Error('Failed HTTP story creation'), res.data);
      }
    }

    // HTTP Test 3: POST /api/stories/:id/views via HTTP as User B
    logTest('HTTP 3. POST /api/stories/:id/views via HTTP');
    {
      const res = await axios.post(
        `http://localhost:${TEST_PORT}/api/stories/${httpStoryId}/views`,
        {},
        {
          headers: {
            Authorization: `Bearer ${tokenB}`
          }
        }
      );
      if (res.status === 200 && res.data.success === true && res.data.data.is_new_view === true) {
        logPass(`Story viewed via HTTP. is_new_view=true`);
      } else {
        logFail('Stories HTTP', 'HTTP mark viewed', new Error('Failed HTTP mark viewed'), res.data);
      }
    }

    // HTTP Test 4: GET /api/stories/my-stories via HTTP as User A
    logTest('HTTP 4. GET /api/stories/my-stories via HTTP');
    {
      const res = await axios.get(
        `http://localhost:${TEST_PORT}/api/stories/my-stories`,
        {
          headers: {
            Authorization: `Bearer ${tokenA}`
          }
        }
      );
      const myStory = res.data.data.find(s => s.id === httpStoryId);
      if (res.status === 200 && myStory && myStory.views_count >= 1) {
        logPass(`My stories fetched via HTTP: Story ID ${myStory.id} has ${myStory.views_count} views`);
      } else {
        logFail('Stories HTTP', 'HTTP my stories', new Error('Failed HTTP my stories'), res.data);
      }
    }

    // HTTP Test 5: DELETE /api/stories/:id via HTTP as User A (Owner)
    logTest('HTTP 5. DELETE /api/stories/:id via HTTP');
    {
      const res = await axios.delete(
        `http://localhost:${TEST_PORT}/api/stories/${httpStoryId}`,
        {
          headers: {
            Authorization: `Bearer ${tokenA}`
          }
        }
      );
      if (res.status === 200 && res.data.success === true) {
        logPass(`Story ${httpStoryId} deleted via HTTP`);
      } else {
        logFail('Stories HTTP', 'HTTP delete story', new Error('Failed HTTP delete'), res.data);
      }
    }

    // Close test server
    await new Promise((resolve) => testServer.close(resolve));
    console.log(`✔ Test HTTP server closed cleanly.\n`);

    // =========================================================================
    // FINAL SUMMARY
    // =========================================================================
    console.log('='.repeat(70));
    console.log(`📊 FINAL TEST SUMMARY:`);
    console.log(`   Total Tests Run : ${globalBugs.stats.total}`);
    console.log(`   Passed          : ${globalBugs.stats.passed}`);
    console.log(`   Failed          : ${globalBugs.stats.failed}`);
    console.log('='.repeat(70));

    if (globalBugs.stats.failed === 0) {
      console.log('\n🌟 100% OF TESTS PASSED! ALL STORY APIS OPERATIONAL & READY FOR PRODUCTION. 🚀\n');
      process.exit(0);
    } else {
      console.log('\n❌ SOME TESTS FAILED. CHECK DETAILS ABOVE.\n');
      process.exit(1);
    }

  } catch (error) {
    console.error('Fatal test error:', error);
    process.exit(1);
  }
}

runAllStoriesTests();
