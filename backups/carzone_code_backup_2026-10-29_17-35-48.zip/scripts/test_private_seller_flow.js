import db from '../config/db.js';

async function runTests() {
  console.log('🧪 Starting Verification Tests for Private Seller Pay-per-Vehicle System...\n');

  try {
    // 1. Verify tbl_cars columns
    console.log('--- Test 1: Verify tbl_cars columns ---');
    const carCols = await db.query('DESCRIBE tbl_cars');
    const colNames = carCols.map(c => c.Field);
    const requiredCarCols = ['listing_type', 'duration_option', 'listing_expires_at', 'payment_status'];
    for (const col of requiredCarCols) {
      if (colNames.includes(col)) {
        console.log(`✔ Column tbl_cars.${col} exists`);
      } else {
        console.error(`❌ Column tbl_cars.${col} MISSING!`);
      }
    }

    // 2. Verify tbl_purchases columns
    console.log('\n--- Test 2: Verify tbl_purchases columns ---');
    const purchaseCols = await db.query('DESCRIBE tbl_purchases');
    const pColNames = purchaseCols.map(c => c.Field);
    if (pColNames.includes('car_id')) {
      console.log('✔ Column tbl_purchases.car_id exists');
    } else {
      console.error('❌ Column tbl_purchases.car_id MISSING!');
    }

    // 3. Verify tbl_plans private options
    console.log('\n--- Test 3: Verify private listing plans in tbl_plans ---');
    const privatePlans = await db.query(
      `SELECT id, name, price, duration_type, plan_type FROM tbl_plans WHERE plan_type = 'private_listing'`
    );
    console.log('Private listing plans found:', privatePlans);
    if (privatePlans.length === 2) {
      console.log('✔ Exactly 2 private listing options configured!');
    } else {
      console.warn(`⚠️ Expected 2 private listing plans, found ${privatePlans.length}`);
    }

    // 4. Test simulate private seller car listing query
    console.log('\n--- Test 4: Verify grandfathered cars ---');
    const [stats] = await db.query(`
      SELECT 
        COUNT(*) as total_published,
        SUM(CASE WHEN listing_type = 'subscription_slot' THEN 1 ELSE 0 END) as subscription_count,
        SUM(CASE WHEN listing_type = 'per_vehicle' THEN 1 ELSE 0 END) as per_vehicle_count
      FROM tbl_cars
      WHERE listing_status = 'published' AND is_deleted = 0
    `);
    console.log('Grandfathered car stats:', stats);

    console.log('\n🎉 All backend verification tests PASSED!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
}

runTests();
