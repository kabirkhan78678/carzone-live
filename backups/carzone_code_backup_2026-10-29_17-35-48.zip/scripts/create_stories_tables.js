import db from '../config/db.js';

async function createStoriesTables() {
  try {
    console.log('--- Creating Stories Tables ---');

    await db.query(`
      CREATE TABLE IF NOT EXISTS tbl_stories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        media_url VARCHAR(1000) NOT NULL,
        caption TEXT DEFAULT NULL,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        expires_at TIMESTAMP DEFAULT (CURRENT_TIMESTAMP + INTERVAL 24 HOUR),
        INDEX idx_stories_active_expiry (is_active, expires_at),
        INDEX idx_stories_user_active (user_id, is_active),
        INDEX idx_stories_created_at (created_at),
        CONSTRAINT fk_story_user FOREIGN KEY (user_id) REFERENCES tbl_users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    console.log('✔ tbl_stories table ensured.');

    await db.query(`
      CREATE TABLE IF NOT EXISTS tbl_story_views (
        id INT AUTO_INCREMENT PRIMARY KEY,
        story_id INT NOT NULL,
        viewer_id INT NOT NULL,
        viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_story_viewer (story_id, viewer_id),
        INDEX idx_story_views_story (story_id),
        INDEX idx_story_views_viewer (viewer_id),
        CONSTRAINT fk_story_views_story FOREIGN KEY (story_id) REFERENCES tbl_stories(id) ON DELETE CASCADE,
        CONSTRAINT fk_story_views_user FOREIGN KEY (viewer_id) REFERENCES tbl_users(id) ON DELETE CASCADE
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `);
    console.log('✔ tbl_story_views table ensured.');

    console.log('All stories tables created successfully!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Error creating stories tables:', error);
    process.exit(1);
  }
}

createStoriesTables();
