import db from '../config/db.js';
import {
  createMockReqRes,
  logSuite,
  logTest,
  logPass,
  logFail,
  globalBugs
} from './test_helper.js';

import { getDashboardCounts, getRevenueAndSlotSales } from '../controllers/admin/dashboard.controller.js';
import { listAllcars, fetchCarById } from '../controllers/admin/carApproval.controller.js';
import { getAllPrivateAccounts, getAllCompanyAccounts } from '../controllers/admin/usersList.controller.js';
import { getQualitySeals, createQualitySeal } from '../controllers/admin/qualitySeal.controller.js';

export async function runAdminTests() {
  const MODULE = 'Admin Management';
  logSuite(MODULE);

  // ----------------------------------------------------
  // Test 1: getDashboardCounts
  // ----------------------------------------------------
  logTest('getDashboardCounts: Admin metrics and counts overview');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: 1, role: 'admin' }
    });
    await getDashboardCounts(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass('Dashboard summary counts fetched successfully');
    } else {
      logFail(MODULE, 'getDashboardCounts returned error', new Error(`Status ${resp.statusCode}`), null, 'dashboard.controller.js:6');
    }
  } catch (err) {
    logFail(MODULE, 'getDashboardCounts threw error', err, null, 'dashboard.controller.js');
  }

  // ----------------------------------------------------
  // Test 2: listAllcars - Inventory Listing
  // ----------------------------------------------------
  logTest('listAllcars: Admin inventory overview with image mapping');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { search: '' }
    });
    await listAllcars(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && Array.isArray(resp.data?.data)) {
      logPass(`Admin car list fetched (${resp.data.data.length} cars found)`);
    } else {
      logFail(MODULE, 'listAllcars failed', new Error(`Status ${resp.statusCode}`), null, 'carApproval.controller.js:8');
    }
  } catch (err) {
    logFail(MODULE, 'listAllcars threw error', err, null, 'carApproval.controller.js');
  }

  // ----------------------------------------------------
  // Test 3: fetchCarById
  // ----------------------------------------------------
  logTest('fetchCarById: Fetch complete detail for vehicle ID 2');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { id: 2 }
    });
    await fetchCarById(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass(`Admin car details fetched for ID 2`);
    } else {
      logFail(MODULE, 'fetchCarById returned error', new Error(`Status ${resp.statusCode}`), null, 'carApproval.controller.js:32');
    }
  } catch (err) {
    logFail(MODULE, 'fetchCarById threw error', err, null, 'carApproval.controller.js');
  }

  // ----------------------------------------------------
  // Test 4: getAllPrivateAccounts
  // ----------------------------------------------------
  logTest('getAllPrivateAccounts: Fetch private accounts list');
  try {
    const { req, res, getResponse } = createMockReqRes({ query: {} });
    await getAllPrivateAccounts(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && Array.isArray(resp.data?.data)) {
      logPass(`Private accounts fetched (${resp.data.data.length} accounts found)`);
    } else {
      logFail(MODULE, 'getAllPrivateAccounts failed', new Error(`Status ${resp.statusCode}`), null, 'usersList.controller.js:31');
    }
  } catch (err) {
    logFail(MODULE, 'getAllPrivateAccounts threw error', err, null, 'usersList.controller.js');
  }

  // ----------------------------------------------------
  // Test 5: getAllCompanyAccounts
  // ----------------------------------------------------
  logTest('getAllCompanyAccounts: Fetch dealer/company accounts list');
  try {
    const { req, res, getResponse } = createMockReqRes({ query: {} });
    await getAllCompanyAccounts(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && Array.isArray(resp.data?.data)) {
      logPass(`Company accounts fetched (${resp.data.data.length} accounts found)`);
    } else {
      logFail(MODULE, 'getAllCompanyAccounts failed', new Error(`Status ${resp.statusCode}`), null, 'usersList.controller.js:51');
    }
  } catch (err) {
    logFail(MODULE, 'getAllCompanyAccounts threw error', err, null, 'usersList.controller.js');
  }

  // ----------------------------------------------------
  // Test 6: getQualitySeals
  // ----------------------------------------------------
  logTest('getQualitySeals: Fetch quality seals list');
  try {
    const { req, res, getResponse } = createMockReqRes({ query: { page: 1, limit: 10 } });
    await getQualitySeals(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200) {
      logPass('Quality seals fetched successfully');
    } else {
      logFail(MODULE, 'getQualitySeals failed', new Error(`Status ${resp.statusCode}`), null, 'qualitySeal.controller.js:54');
    }
  } catch (err) {
    logFail(MODULE, 'getQualitySeals threw error', err, null, 'qualitySeal.controller.js');
  }

  // ----------------------------------------------------
  // Test 7: createQualitySeal - Missing Name Validation & Creation
  // ----------------------------------------------------
  logTest('createQualitySeal: Name validation and creation cycle');
  let testSealId = null;
  try {
    const { req: reqEmpty, res: resEmpty, getResponse: getRespEmpty } = createMockReqRes({ body: {} });
    await createQualitySeal(reqEmpty, resEmpty);
    const respEmpty = getRespEmpty();

    const { req: reqGood, res: resGood, getResponse: getRespGood } = createMockReqRes({
      body: { name: 'Test Inspection Seal', description: 'Testing seal' }
    });
    await createQualitySeal(reqGood, resGood);
    const respGood = getRespGood();

    if (respEmpty.statusCode === 400 && respGood.statusCode === 201) {
      testSealId = respGood.data?.data?.id;
      logPass('Correctly rejected empty name (400) and created new seal (201)');
    } else {
      logFail(MODULE, 'createQualitySeal validation/creation failed', new Error(`Empty: ${respEmpty.statusCode}, Good: ${respGood.statusCode}`), null, 'qualitySeal.controller.js:12');
    }

    if (testSealId) {
      await db.query('DELETE FROM tbl_quality_seals WHERE id = ?', [testSealId]);
    }
  } catch (err) {
    logFail(MODULE, 'createQualitySeal threw error', err, null, 'qualitySeal.controller.js');
  }

  // ----------------------------------------------------
  // Test 8: getRevenueAndSlotSales
  // ----------------------------------------------------
  logTest('getRevenueAndSlotSales: Annual revenue metrics');
  try {
    const { req, res, getResponse } = createMockReqRes({ query: { year: 2026 } });
    await getRevenueAndSlotSales(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200) {
      logPass('Revenue and slot sales breakdown fetched');
    } else {
      logFail(MODULE, 'getRevenueAndSlotSales failed', new Error(`Status ${resp.statusCode}`), null, 'dashboard.controller.js:40');
    }
  } catch (err) {
    logFail(MODULE, 'getRevenueAndSlotSales threw error', err, null, 'dashboard.controller.js');
  }
}

if (process.argv[1] && process.argv[1].endsWith('test_10_admin.js')) {
  runAdminTests().then(() => {
    console.log(`\nTests finished. Bugs found so far: ${globalBugs.bugs.length}`);
    process.exit(0);
  });
}
