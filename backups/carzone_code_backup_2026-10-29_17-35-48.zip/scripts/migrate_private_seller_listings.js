import db from '../config/db.js';

async function runMigration() {
  console.log('🚀 Starting Private Seller Listing Migration...');

  try {
    // 1. Check existing columns in tbl_cars
    const columns = await db.query('DESCRIBE tbl_cars');
    const existingColNames = columns.map(c => c.Field);

    const alterStatements = [];

    if (!existingColNames.includes('listing_type')) {
      alterStatements.push(`ADD COLUMN listing_type ENUM('per_vehicle', 'subscription_slot') DEFAULT 'per_vehicle' AFTER listing_status`);
    }

    if (!existingColNames.includes('duration_option')) {
      alterStatements.push(`ADD COLUMN duration_option ENUM('1_month', 'until_sold') DEFAULT NULL AFTER listing_type`);
    }

    if (!existingColNames.includes('listing_expires_at')) {
      alterStatements.push(`ADD COLUMN listing_expires_at DATETIME NULL DEFAULT NULL AFTER duration_option`);
    }

    if (!existingColNames.includes('payment_status')) {
      alterStatements.push(`ADD COLUMN payment_status ENUM('unpaid', 'paid', 'expired') DEFAULT 'unpaid' AFTER listing_expires_at`);
    }

    if (alterStatements.length > 0) {
      console.log('Applying ALTER TABLE tbl_cars...');
      const alterSql = `ALTER TABLE tbl_cars ${alterStatements.join(', ')}`;
      await db.query(alterSql);
      console.log('✅ Columns added successfully to tbl_cars!');
    } else {
      console.log('ℹ️ All required columns already exist in tbl_cars.');
    }

    // 2. Expand listing_status enum if needed to include 'expired' and set is_active default to 2
    console.log("Updating listing_status and is_active...");
    await db.query(`ALTER TABLE tbl_cars MODIFY COLUMN listing_status ENUM('draft', 'published', 'expired') DEFAULT 'draft'`);
    await db.query(`ALTER TABLE tbl_cars MODIFY COLUMN is_active TINYINT(1) DEFAULT 2`);
    await db.query(`UPDATE tbl_cars SET is_active = 2 WHERE listing_status = 'draft' AND is_deleted = 0`);
    console.log("✅ listing_status and is_active updated!");

    // 3. Update tbl_plans column types to support private_listing and until_sold
    console.log("Updating tbl_plans enum definitions...");
    await db.query(`ALTER TABLE tbl_plans MODIFY COLUMN plan_type ENUM('basic', 'additional', 'custom', 'bulk', 'private_listing') NOT NULL DEFAULT 'basic'`);
    await db.query(`ALTER TABLE tbl_plans MODIFY COLUMN duration_type ENUM('monthly', 'yearly', 'weekly', 'until_sold') NOT NULL DEFAULT 'monthly'`);

    const existingPrivatePlans = await db.query(
      `SELECT id, name, duration_type, price FROM tbl_plans WHERE plan_type = 'private_listing'`
    );

    if (existingPrivatePlans.length === 0) {
      console.log('Inserting default Private Listing pricing in tbl_plans...');
      await db.query(`
        INSERT INTO tbl_plans (name, price, slot_count, plan_type, duration_type, is_public)
        VALUES 
        ('Private Listing (1 Month)', 19.00, 1, 'private_listing', 'monthly', 0),
        ('Private Listing (Until Sold)', 49.00, 1, 'private_listing', 'until_sold', 0)
      `);
      console.log('✅ Private listing plans inserted into tbl_plans!');
    } else {
      console.log('ℹ️ Private listing plans already exist in tbl_plans:', existingPrivatePlans);
    }

    // 4. Update tbl_purchases to support vehicle purchases
    console.log("Updating tbl_purchases schema...");
    const purchaseCols = await db.query('DESCRIBE tbl_purchases');
    const existingPurchaseCols = purchaseCols.map(c => c.Field);
    await db.query(`ALTER TABLE tbl_purchases MODIFY COLUMN user_plan_id INT NULL DEFAULT NULL`);
    await db.query(`ALTER TABLE tbl_purchases MODIFY COLUMN plan_type ENUM('main', 'additional', 'private_listing') DEFAULT 'main'`);
    if (!existingPurchaseCols.includes('car_id')) {
      await db.query(`ALTER TABLE tbl_purchases ADD COLUMN car_id INT NULL DEFAULT NULL AFTER user_plan_id`);
      console.log('✅ Added car_id column to tbl_purchases');
    }

    // 5. Update existing cars to mark them as 'subscription_slot' and 'paid' so they don't break
    console.log('Ensuring existing active cars are grandfathered as subscription_slot...');
    await db.query(`
      UPDATE tbl_cars 
      SET listing_type = 'subscription_slot', payment_status = 'paid' 
      WHERE listing_status = 'published' AND (listing_type IS NULL OR listing_type = 'per_vehicle')
    `);
    console.log('✅ Existing published cars successfully grandfathered!');

    console.log('\n🎉 Migration completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  }
}

runMigration();
