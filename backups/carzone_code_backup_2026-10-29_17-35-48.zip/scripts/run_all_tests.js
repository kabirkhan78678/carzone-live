import { globalBugs } from './test_helper.js';

import { runAuthProfileTests } from './test_01_auth_profile.js';
import { runCarsInventoryTests } from './test_02_cars_inventory.js';
import { runReelsMediaTests } from './test_03_reels_media.js';
import { runSearchFiltersTests } from './test_04_search_filters.js';
import { runPurchaseAgreementsTests } from './test_05_purchase_agreements.js';
import { runVisitsSchedulingTests } from './test_06_visits_scheduling.js';
import { runUserInteractionsTests } from './test_07_user_interactions.js';
import { runPlansSlotsTests } from './test_08_plans_slots.js';
import { runAnalyticsTests } from './test_09_analytics.js';
import { runAdminTests } from './test_10_admin.js';
import { runSocketTests } from './test_socket_realtime.js';
import { runApiBenchmarks } from './test_all_apis_benchmark.js';

async function main() {
  const startTime = Date.now();
  console.log('\n' + '#'.repeat(80));
  console.log('🚀 MASTER BACKEND TEST RUNNER - COMPREHENSIVE END-TO-END AUDIT');
  console.log('#'.repeat(80));

  try {
    // 1. Run all 10 Module Business Logic & Controller Suites
    await runAuthProfileTests();
    await runCarsInventoryTests();
    await runReelsMediaTests();
    await runSearchFiltersTests();
    await runPurchaseAgreementsTests();
    await runVisitsSchedulingTests();
    await runUserInteractionsTests();
    await runPlansSlotsTests();
    await runAnalyticsTests();
    await runAdminTests();

    // 2. Run Real-time Socket.IO Tests & Latency Benchmark
    await runSocketTests();

    // 3. Run Master HTTP API Benchmark & Latency Suite
    await runApiBenchmarks();
  } catch (err) {
    console.error('Fatal error during test suite execution:', err);
  }

  const durationSec = ((Date.now() - startTime) / 1000).toFixed(2);
  const { total, passed, failed } = globalBugs.stats;

  console.log('\n' + '='.repeat(80));
  console.log('📊 MASTER TEST EXECUTION SUMMARY');
  console.log('='.repeat(80));
  console.log(`⏱ Total Execution Time: ${durationSec}s`);
  console.log(`🧪 Module Unit Tests Run: ${total} (Passed: ${passed}, Failed: ${failed})`);

  if (globalBugs.bugs.length > 0) {
    console.log('\n' + '!'.repeat(80));
    console.log('🚨 DISCOVERED BACKEND ISSUES & BUGS');
    console.log('!'.repeat(80));
    globalBugs.bugs.forEach((bug, index) => {
      console.log(`\n[#${index + 1}] [${bug.severity}] ${bug.module}: ${bug.title}`);
      console.log(`    Location: ${bug.location}`);
      console.log(`    Details : ${bug.details}`);
      if (bug.payload) {
        console.log(`    Payload : ${JSON.stringify(bug.payload)}`);
      }
    });
  }

  console.log('\n' + '='.repeat(80) + '\n');
  process.exit(0);
}

main();
