import db from '../config/db.js';

async function analyzeNotificationFlood() {
    try {
        console.log("=================================================================");
        console.log("           FORENSIC ANALYSIS OF TBL_NOTIFICATION FLOOD           ");
        console.log("=================================================================");

        // 1. Total count
        const [totalCount] = await db.query("SELECT COUNT(*) AS total FROM tbl_notification");
        console.log(`\n1. TOTAL NOTIFICATIONS IN TABLE: ${totalCount.total}`);

        // 2. Breakdown by notificationType
        const breakdown = await db.query(`
            SELECT notificationType, COUNT(*) AS count, 
                   MIN(createdAt) AS oldest_record, 
                   MAX(createdAt) AS newest_record
            FROM tbl_notification
            GROUP BY notificationType
            ORDER BY count DESC
        `);
        console.log("\n2. BREAKDOWN BY TYPE:");
        console.table(breakdown);

        // 3. User Plans with is_active = 1 but already expired
        const expiredActivePlans = await db.query(`
            SELECT id, user_id, start_date, end_date, is_active, reminder_sent, expiry_notification_sent, DATEDIFF(CURDATE(), end_date) AS days_overdue
            FROM tbl_user_plans
            WHERE is_active = 1 AND end_date < CURDATE()
            ORDER BY days_overdue DESC
        `);
        console.log(`\n3. ACTIVE PLANS IN DB THAT ARE EXPIRED (Causing Loop): ${expiredActivePlans.length} plans`);
        console.table(expiredActivePlans);

        // 4. Rate of Insertion for plan_expired (e.g. today or last hour)
        const recentInserts = await db.query(`
            SELECT DATE_FORMAT(createdAt, '%Y-%m-%d %H:00:00') AS hour_slot, COUNT(*) as inserts_per_hour
            FROM tbl_notification
            WHERE notificationType = 'plan_expired'
            GROUP BY hour_slot
            ORDER BY hour_slot DESC
            LIMIT 10
        `);
        console.log("\n4. INSERTS PER HOUR FOR 'plan_expired' (Recent Hours):");
        console.table(recentInserts);

        // 5. Top 10 spammed users
        const topUsers = await db.query(`
            SELECT sendTo AS user_id, u.fullName, u.email, COUNT(*) as notifications_count
            FROM tbl_notification n
            LEFT JOIN tbl_users u ON n.sendTo = u.id
            WHERE n.notificationType = 'plan_expired'
            GROUP BY sendTo, u.fullName, u.email
            ORDER BY notifications_count DESC
            LIMIT 10
        `);
        console.log("\n5. TOP 10 USERS AFFECTED BY FLOOD:");
        console.table(topUsers);

        process.exit(0);
    } catch (e) {
        console.error("Forensic analysis error:", e);
        process.exit(1);
    }
}

analyzeNotificationFlood();
