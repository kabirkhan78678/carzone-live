import db from '../config/db.js';
import {
  createMockReqRes,
  logSuite,
  logTest,
  logPass,
  logFail,
  globalBugs
} from './test_helper.js';

import { getAllPlan, getMyPlan } from '../controllers/shared/plansList.controller.js';
import { requestSlot, getAllSlotRequests } from '../controllers/shared/slots.controller.js';
import { getUpgradeDowngradePlans, renewPlan } from '../controllers/shared/planRenewal.controller.js';
import { stripeWebhook } from '../controllers/shared/stripeWebhook.controller.js';

export async function runPlansSlotsTests() {
  const MODULE = 'Plans & Slots';
  logSuite(MODULE);

  const testUserId = 58;

  // ----------------------------------------------------
  // Test 1: getAllPlan - Listing Plans
  // ----------------------------------------------------
  logTest('getAllPlan: Fetch all subscription listing plans');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' }
    });
    await getAllPlan(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && Array.isArray(resp.data?.plans)) {
      logPass(`All plans fetched successfully (${resp.data.plans.length} tiers available)`);
    } else {
      logFail(MODULE, 'getAllPlan failed', new Error(`Status ${resp.statusCode}`), null, 'plansList.controller.js:9');
    }
  } catch (err) {
    logFail(MODULE, 'getAllPlan threw error', err, null, 'plansList.controller.js');
  }

  // ----------------------------------------------------
  // Test 2: getMyPlan - Current User Plan
  // ----------------------------------------------------
  logTest('getMyPlan: Fetch current subscription plan for user');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' }
    });
    await getMyPlan(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 || resp.statusCode === 404) {
      logPass('getMyPlan executed successfully');
    } else {
      logFail(MODULE, 'getMyPlan returned status ' + resp.statusCode, new Error(JSON.stringify(resp.data)), null, 'plansList.controller.js:55');
    }
  } catch (err) {
    logFail(MODULE, 'getMyPlan threw error', err, null, 'plansList.controller.js');
  }

  // ----------------------------------------------------
  // Test 3: requestSlot - Validation on Slots and Preference
  // ----------------------------------------------------
  logTest('requestSlot: Invalid requested slots (0 slots)');
  try {
    const { req: reqZero, res: resZero, getResponse: getRespZero } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { requested_slots: 0, subscription_preference: 'MONTHLY' }
    });
    await requestSlot(reqZero, resZero);
    const respZero = getRespZero();

    const { req: reqPref, res: resPref, getResponse: getRespPref } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { requested_slots: 5 } // missing subscription_preference
    });
    await requestSlot(reqPref, resPref);
    const respPref = getRespPref();

    if (respZero.statusCode === 400 && respPref.statusCode === 400) {
      logPass('Correctly rejected invalid slots count and missing subscription preference');
    } else {
      logFail(MODULE, 'requestSlot validation failed', new Error(`Zero: ${respZero.statusCode}, Pref: ${respPref.statusCode}`), null, 'slots.controller.js:16');
    }
  } catch (err) {
    logFail(MODULE, 'requestSlot threw error on validation', err, null, 'slots.controller.js');
  }

  // ----------------------------------------------------
  // Test 4: requestSlot - Valid Slot Request & Fetch
  // ----------------------------------------------------
  logTest('requestSlot: Submit valid request and fetch user slot requests');
  let createdSlotRequestId = null;
  try {
    const { req: reqGood, res: resGood, getResponse: getRespGood } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: {
        requested_slots: 3,
        subscription_preference: 'MONTHLY',
        message: 'Need additional slots for new inventory.'
      }
    });
    await requestSlot(reqGood, resGood);
    const respGood = getRespGood();

    const { req: reqList, res: resList, getResponse: getRespList } = createMockReqRes({
      user: { id: testUserId, language: 'en' }
    });
    await getAllSlotRequests(reqList, resList);
    const respList = getRespList();

    if (respGood.statusCode === 200 && respList.statusCode === 200) {
      createdSlotRequestId = respGood.data?.data?.requestId;
      logPass(`Slot request submitted and fetched in list (Request ID: ${createdSlotRequestId})`);
    } else {
      logFail(MODULE, 'requestSlot / getAllSlotRequests failed', new Error(`Create: ${respGood.statusCode}, List: ${respList.statusCode}`), null, 'slots.controller.js');
    }

    if (createdSlotRequestId) {
      await db.query('DELETE FROM slot_requests WHERE id = ?', [createdSlotRequestId]);
    }
  } catch (err) {
    logFail(MODULE, 'requestSlot lifecycle threw error', err, null, 'slots.controller.js');
  }

  // ----------------------------------------------------
  // Test 5: getUpgradeDowngradePlans
  // ----------------------------------------------------
  logTest('getUpgradeDowngradePlans: Fetch eligible upgrade/downgrade plans');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' }
    });
    await getUpgradeDowngradePlans(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass('Eligible upgrade and downgrade options fetched successfully');
    } else {
      logFail(MODULE, 'getUpgradeDowngradePlans returned status ' + resp.statusCode, new Error(JSON.stringify(resp.data)), null, 'planRenewal.controller.js:10');
    }
  } catch (err) {
    logFail(MODULE, 'getUpgradeDowngradePlans threw error', err, null, 'planRenewal.controller.js');
  }

  // ----------------------------------------------------
  // Test 6: renewPlan - Downgrade below active cars threshold check
  // ----------------------------------------------------
  logTest('renewPlan: Downgrade below active cars count');
  try {
    // If user has 0 plan, it returns 400 "No plan found to renew"
    const { req, res, getResponse } = createMockReqRes({
      user: { id: 999999, language: 'en' },
      body: { action: 'downgrade', chosen_total_slots: 1 }
    });
    await renewPlan(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400) {
      logPass('Correctly handled plan renewal constraint check (400)');
    } else {
      logFail(MODULE, 'renewPlan failed constraint check', new Error(`Status ${resp.statusCode}`), null, 'planRenewal.controller.js:41');
    }
  } catch (err) {
    logFail(MODULE, 'renewPlan threw error', err, null, 'planRenewal.controller.js');
  }

  // ----------------------------------------------------
  // Test 7: stripeWebhook - Signature Security Check
  // ----------------------------------------------------
  logTest('stripeWebhook: Missing or forged signature rejection (Security)');
  try {
    const { req, res, getResponse } = createMockReqRes({
      headers: { 'stripe-signature': 'forged_fake_signature' },
      body: { type: 'checkout.session.completed' }
    });
    await stripeWebhook(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400) {
      logPass('Correctly rejected invalid webhook signature with 400 Bad Request');
    } else {
      logFail(MODULE, 'CRITICAL SECURITY: stripeWebhook allowed forged signature!', new Error(`Status ${resp.statusCode}`), null, 'stripeWebhook.controller.js:20', 'CRITICAL');
    }
  } catch (err) {
    logFail(MODULE, 'stripeWebhook signature security test threw error', err, null, 'stripeWebhook.controller.js');
  }
}

if (process.argv[1] && process.argv[1].endsWith('test_08_plans_slots.js')) {
  runPlansSlotsTests().then(() => {
    console.log(`\nTests finished. Bugs found so far: ${globalBugs.bugs.length}`);
    process.exit(0);
  });
}
