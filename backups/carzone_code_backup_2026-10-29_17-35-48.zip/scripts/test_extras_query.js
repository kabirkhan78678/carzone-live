import http from 'http';
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import dotenv from 'dotenv';
import route from '../routes/index.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use('/api', route);

async function verifyAllFiltersEndpoints() {
  const server = http.createServer(app);
  await new Promise(r => server.listen(0, r));
  const port = server.address().port;
  const baseUrl = `http://127.0.0.1:${port}`;

  const urls = [
    '/api/user/web/filters?lang=en&seller_type=personal',
    '/api/user/web/filters?lang=en&seller_type=business',
    '/api/user/web/filters?lang=en&warranty=1',
    '/api/user/web/filters?lang=en&seller_type=personal&warranty=1'
  ];

  console.log('\n--- VERIFYING WEB FILTERS WITH FIX ---');
  for (const u of urls) {
    const res = await fetch(`${baseUrl}${u}`);
    const json = await res.json();
    console.log(`URL: ${u}`);
    console.log(`   Status: ${res.status} | Success: ${json.success} | total_cars: ${json.data?.total_cars} | extras: ${(json.data?.extras || []).length}`);
    if (res.status !== 200) {
      console.error('   ERROR DETAILS:', json);
    }
  }

  server.close();
}

verifyAllFiltersEndpoints().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
