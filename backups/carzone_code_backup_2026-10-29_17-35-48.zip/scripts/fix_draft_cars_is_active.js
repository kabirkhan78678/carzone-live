import db from '../config/db.js';

async function fixIsActive() {
  try {
    console.log('1. Altering tbl_cars.is_active default to 0...');
    await db.query('ALTER TABLE tbl_cars MODIFY COLUMN is_active TINYINT(1) DEFAULT 0');
    console.log('✔ Column default set to 0');

    console.log('2. Updating unpaid/draft private cars to is_active = 0, listing_status = draft...');
    const result = await db.query(`
      UPDATE tbl_cars 
      SET is_active = 0, listing_status = 'draft' 
      WHERE listing_type = 'per_vehicle' 
        AND (payment_status != 'paid' OR payment_status IS NULL)
        AND is_deleted = 0
    `);
    console.log(`✔ Updated ${result.affectedRows} cars to is_active = 0 and listing_status = 'draft'`);

    const updatedCars = await db.query(`
      SELECT id, user_id, brandName, carModel, listing_status, is_active, listing_type, payment_status 
      FROM tbl_cars 
      ORDER BY id DESC 
      LIMIT 6
    `);
    console.log('Current status of latest cars:', updatedCars);
    process.exit(0);
  } catch (err) {
    console.error('Error:', err);
    process.exit(1);
  }
}

fixIsActive();
