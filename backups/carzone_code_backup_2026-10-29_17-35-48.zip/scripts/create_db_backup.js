import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

const dbHost = process.env.DB_HOST || '13.51.226.81';
const dbUser = process.env.DB_USER || 'car_zone';
const dbPass = process.env.DB_PASSWORD || 'wAX25Pj0pQ20';
const dbPort = process.env.DB_PORT || '3306';
const dbName = process.env.DB_DATABASE || 'carzone';

const backupDir = path.resolve('backups');
if (!fs.existsSync(backupDir)) {
  fs.mkdirSync(backupDir, { recursive: true });
}

const now = new Date();
const timestamp = now.toISOString().replace(/[:.]/g, '-').slice(0, 19);
const fileName = `carzone_backup_${timestamp}.sql`;
const filePath = path.join(backupDir, fileName);

console.log(`Starting backup of database '${dbName}' from ${dbHost}...`);
console.log(`Target file: ${filePath}`);

const dumpBinary = 'C:\\xampp\\mysql\\bin\\mysqldump.exe';

const args = [
  `-h${dbHost}`,
  `-P${dbPort}`,
  `-u${dbUser}`,
  `--password=${dbPass}`,
  '--routines',
  '--triggers',
  '--single-transaction',
  '--quick',
  dbName
];

const writeStream = fs.createWriteStream(filePath);
const proc = spawn(dumpBinary, args);

proc.stdout.pipe(writeStream);

let stderr = '';
proc.stderr.on('data', (data) => {
  stderr += data.toString();
});

proc.on('close', (code) => {
  if (code === 0) {
    const stats = fs.statSync(filePath);
    const sizeInMB = (stats.size / (1024 * 1024)).toFixed(2);
    console.log(`✅ Backup completed successfully!`);
    console.log(`File: ${filePath}`);
    console.log(`Size: ${sizeInMB} MB (${stats.size} bytes)`);
  } else {
    console.error(`❌ Backup failed with exit code ${code}`);
    console.error(`Stderr:`, stderr);
  }
});

