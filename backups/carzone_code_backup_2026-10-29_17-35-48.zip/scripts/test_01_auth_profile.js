import db from '../config/db.js';
import {
  createMockReqRes,
  logSuite,
  logTest,
  logPass,
  logFail,
  globalBugs
} from './test_helper.js';

import { socialLogin, userSignIn } from '../controllers/shared/userLogin.controller.js';
import { getUserProfile } from '../controllers/shared/userProfileGet.controller.js';
import { editProfile, updateFcmTokenController } from '../controllers/shared/userProfileEdit.controller.js';
import { changeMode, changeLanguage, changeNotificationStatus } from '../controllers/shared/userProfileSettings.controller.js';

export async function runAuthProfileTests() {
  const MODULE = 'Authentication & Profile';
  logSuite(MODULE);

  const testUserId = 58; // Jack (existing test user in DB)

  // ----------------------------------------------------
  // Test 1: socialLogin - Missing required fields
  // ----------------------------------------------------
  logTest('socialLogin: Missing body parameters');
  try {
    const { req, res, getResponse } = createMockReqRes({ body: {} });
    await socialLogin(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400) {
      logPass('Correctly returned 400 when required fields missing');
    } else {
      logFail(MODULE, 'socialLogin should reject empty body with 400', new Error(`Got status ${resp.statusCode}`), req.body, 'userLogin.controller.js:11');
    }
  } catch (err) {
    logFail(MODULE, 'socialLogin threw uncaught exception on empty body', err, {}, 'userLogin.controller.js:11');
  }

  // ----------------------------------------------------
  // Test 2: socialLogin - Valid Social Login Flow
  // ----------------------------------------------------
  logTest('socialLogin: Valid Google login for existing user');
  try {
    const { req, res, getResponse } = createMockReqRes({
      body: {
        email: 'jack@yopmail.com',
        fullName: 'Jack Test',
        isSeller: 0
      }
    });
    await socialLogin(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.token) {
      logPass('Successfully authenticated user and returned JWT token');
    } else {
      logFail(MODULE, 'socialLogin failed to return token for existing user', new Error(JSON.stringify(resp.data)), req.body, 'userLogin.controller.js:77');
    }
  } catch (err) {
    logFail(MODULE, 'socialLogin threw exception during valid login', err, {}, 'userLogin.controller.js:77');
  }

  // ----------------------------------------------------
  // Test 3: userSignIn - Non-existent user
  // ----------------------------------------------------
  logTest('userSignIn: Non-existent email account');
  try {
    const { req, res, getResponse } = createMockReqRes({
      body: { email: 'nonexistent_user_99999@test.com', password: 'Password123!' }
    });
    await userSignIn(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400) {
      logPass('Correctly returned 400 ACCOUNT_NOT_FOUND');
    } else {
      logFail(MODULE, 'userSignIn allowed or mishandled non-existent email', new Error(`Status ${resp.statusCode}`), req.body, 'userLogin.controller.js:107');
    }
  } catch (err) {
    logFail(MODULE, 'userSignIn threw error on non-existent account', err, {}, 'userLogin.controller.js:107');
  }

  // ----------------------------------------------------
  // Test 4: getUserProfile - Valid User
  // ----------------------------------------------------
  logTest('getUserProfile: Existing user ID 58');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' }
    });
    await getUserProfile(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data?.id === testUserId) {
      const data = resp.data.data;
      if (typeof data.slotAvailable !== 'undefined' && Array.isArray(data.openingTimes)) {
        logPass(`Profile fetched successfully with slots, roleData, openingTimes`);
      } else {
        logFail(MODULE, 'Profile missing expected attributes (slotAvailable/openingTimes)', new Error('Invalid schema in profile'), null, 'userProfileGet.controller.js:62');
      }
    } else {
      logFail(MODULE, 'getUserProfile failed for valid user 58', new Error(`Status ${resp.statusCode}`), { id: testUserId }, 'userProfileGet.controller.js:107');
    }
  } catch (err) {
    logFail(MODULE, 'getUserProfile threw exception on valid user', err, { id: testUserId }, 'userProfileGet.controller.js:107');
  }

  // ----------------------------------------------------
  // Test 5: getUserProfile - Non-existent user ID
  // ----------------------------------------------------
  logTest('getUserProfile: Non-existent user ID (9999999)');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: 9999999, language: 'en' }
    });
    await getUserProfile(req, res);
    const resp = getResponse();
    if (resp.statusCode === 404) {
      logPass('Correctly returned 404 USER_NOT_FOUND');
    } else {
      logFail(MODULE, 'getUserProfile should return 404 for invalid user ID', new Error(`Got status ${resp.statusCode}`), { id: 9999999 }, 'userProfileGet.controller.js:15');
    }
  } catch (err) {
    logFail(MODULE, 'getUserProfile crashed on non-existent user ID', err, { id: 9999999 }, 'userProfileGet.controller.js:15');
  }

  // ----------------------------------------------------
  // Test 6: changeLanguage
  // ----------------------------------------------------
  logTest('changeLanguage: Switch language to "de" and then "en"');
  try {
    const { req: reqDe, res: resDe, getResponse: getRespDe } = createMockReqRes({
      user: { id: testUserId },
      body: { language: 'de' }
    });
    await changeLanguage(reqDe, resDe);
    const respDe = getRespDe();

    // Verify DB
    const [userRow] = await db.query('SELECT language FROM tbl_users WHERE id = ?', [testUserId]);
    if (respDe.statusCode === 200 && userRow?.language === 'de') {
      logPass('Language successfully updated to "de" in database');
    } else {
      logFail(MODULE, 'changeLanguage failed to update user language', new Error(`Status ${respDe.statusCode}`), { lang: 'de' }, 'userProfileSettings.controller.js:56');
    }

    // Revert to 'en'
    const { req: reqEn, res: resEn } = createMockReqRes({
      user: { id: testUserId },
      body: { language: 'en' }
    });
    await changeLanguage(reqEn, resEn);
  } catch (err) {
    logFail(MODULE, 'changeLanguage threw exception', err, {}, 'userProfileSettings.controller.js:56');
  }

  // ----------------------------------------------------
  // Test 7: changeMode (Buyer / Seller toggle)
  // ----------------------------------------------------
  logTest('changeMode: Toggle buyer / seller mode');
  try {
    const { req: reqSeller, res: resSeller, getResponse: getRespSeller } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { isSeller: 1 }
    });
    await changeMode(reqSeller, resSeller);
    const respSeller = getRespSeller();

    const { req: reqBuyer, res: resBuyer, getResponse: getRespBuyer } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { isSeller: 0 }
    });
    await changeMode(reqBuyer, resBuyer);
    const respBuyer = getRespBuyer();

    if (respSeller.statusCode === 200 && respBuyer.statusCode === 200) {
      logPass('Successfully toggled user between seller and buyer mode');
    } else {
      logFail(MODULE, 'changeMode failed toggle', new Error(`Seller: ${respSeller.statusCode}, Buyer: ${respBuyer.statusCode}`), null, 'userProfileSettings.controller.js:6');
    }
  } catch (err) {
    logFail(MODULE, 'changeMode threw exception', err, {}, 'userProfileSettings.controller.js:6');
  }

  // ----------------------------------------------------
  // Test 8: changeNotificationStatus - Invalid & Valid values
  // ----------------------------------------------------
  logTest('changeNotificationStatus: Validate input range (0 or 1)');
  try {
    const { req: reqBad, res: resBad, getResponse: getRespBad } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { isNotification: 5 } // Invalid!
    });
    await changeNotificationStatus(reqBad, resBad);
    const respBad = getRespBad();

    const { req: reqGood, res: resGood, getResponse: getRespGood } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { isNotification: 1 }
    });
    await changeNotificationStatus(reqGood, resGood);
    const respGood = getRespGood();

    if (respBad.statusCode === 400 && respGood.statusCode === 200) {
      logPass('Correctly rejected invalid status (400) and accepted 1 (200)');
    } else {
      logFail(MODULE, 'changeNotificationStatus allowed invalid value', new Error(`Invalid status returned ${respBad.statusCode}`), { isNotification: 5 }, 'userProfileSettings.controller.js:45');
    }
  } catch (err) {
    logFail(MODULE, 'changeNotificationStatus threw exception', err, {}, 'userProfileSettings.controller.js:40');
  }

  // ----------------------------------------------------
  // Test 9: updateFcmTokenController
  // ----------------------------------------------------
  logTest('updateFcmTokenController: Empty & Valid token handling');
  try {
    const { req: reqEmpty, res: resEmpty, getResponse: getRespEmpty } = createMockReqRes({
      user: { id: testUserId },
      body: { fcmToken: '' }
    });
    await updateFcmTokenController(reqEmpty, resEmpty);
    const respEmpty = getRespEmpty();

    const testToken = `test-token-${Date.now()}`;
    const { req: reqValid, res: resValid, getResponse: getRespValid } = createMockReqRes({
      user: { id: testUserId },
      body: { fcmToken: testToken }
    });
    await updateFcmTokenController(reqValid, resValid);
    const respValid = getRespValid();

    const [userRow] = await db.query('SELECT fcmToken FROM tbl_users WHERE id = ?', [testUserId]);
    if (respEmpty.statusCode === 400 && respValid.statusCode === 200 && userRow?.fcmToken === testToken) {
      logPass('FCM token validation and DB update verified');
    } else {
      logFail(MODULE, 'updateFcmTokenController failed validation or update', new Error(`Empty: ${respEmpty.statusCode}, Valid: ${respValid.statusCode}`), null, 'userProfileEdit.controller.js:274');
    }
  } catch (err) {
    logFail(MODULE, 'updateFcmTokenController threw exception', err, {}, 'userProfileEdit.controller.js:274');
  }

  // ----------------------------------------------------
  // Test 10: Code Audit Bug Check - Missing Try/Catch in editProfile
  // ----------------------------------------------------
  logTest('AUDIT: Checking try-catch safety in editProfile');
  try {
    // If a request crashes inside editProfile (e.g. database error or undefined object), does it crash the process?
    const { req: reqCorrupt, res: resCorrupt, getResponse: getRespCorrupt } = createMockReqRes({
      user: { id: 'corrupt_id_causing_sql_error' },
      body: { fullName: 'Corrupt' }
    });
    // This will uncover if missing try/catch causes unhandled rejection
    let caughtError = null;
    try {
      await editProfile(reqCorrupt, resCorrupt);
    } catch (e) {
      caughtError = e;
    }

    if (caughtError) {
      logFail(
        MODULE,
        'CRITICAL: editProfile lacks try-catch block! Unhandled error crashes server/request.',
        caughtError,
        null,
        'controllers/shared/userProfileEdit.controller.js:16',
        'CRITICAL'
      );
    } else {
      logPass('editProfile handled abnormal input gracefully');
    }
  } catch (err) {
    logFail(MODULE, 'Audit check for editProfile failed', err, null, 'userProfileEdit.controller.js');
  }
}

if (process.argv[1] && process.argv[1].endsWith('test_01_auth_profile.js')) {
  runAuthProfileTests().then(() => {
    console.log(`\nTests finished. Bugs found so far: ${globalBugs.bugs.length}`);
    process.exit(0);
  });
}
