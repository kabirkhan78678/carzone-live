import db from '../config/db.js';

async function setDraftIsActiveToTwo() {
  try {
    console.log('1. Setting tbl_cars.is_active default to 2 for drafts...');
    await db.query('ALTER TABLE tbl_cars MODIFY COLUMN is_active TINYINT(1) DEFAULT 2');
    console.log('✔ Column default set to 2');

    console.log('2. Updating all draft cars to is_active = 2...');
    const result = await db.query(`
      UPDATE tbl_cars 
      SET is_active = 2 
      WHERE listing_status = 'draft' 
        AND is_deleted = 0
    `);
    console.log(`✔ Updated ${result.affectedRows} draft cars to is_active = 2`);

    const counts = await db.query(`
      SELECT is_active, listing_status, payment_status, COUNT(*) as count 
      FROM tbl_cars 
      WHERE is_deleted = 0 
      GROUP BY is_active, listing_status, payment_status
    `);
    console.log('Current counts in tbl_cars:', counts);

    process.exit(0);
  } catch (err) {
    console.error('Error:', err);
    process.exit(1);
  }
}

setDraftIsActiveToTwo();
