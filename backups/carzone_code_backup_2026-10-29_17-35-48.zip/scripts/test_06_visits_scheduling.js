import db from '../config/db.js';
import {
  createMockReqRes,
  logSuite,
  logTest,
  logPass,
  logFail,
  globalBugs
} from './test_helper.js';

import { ScheduleVisit, getScheduleVisit, getScheduleRequestDetail } from '../controllers/shared/visitSchedule.controller.js';
import { sellerPhysicalVisitAction, getMySentPhysicalVisits } from '../controllers/shared/visitSellerAction.controller.js';

export async function runVisitsSchedulingTests() {
  const MODULE = 'Visits & Scheduling';
  logSuite(MODULE);

  const buyerUserId = 58;
  const sellerUserId = 270; // Owner of active car 97
  const targetCarId = 97;
  let createdVisitId = null;

  // ----------------------------------------------------
  // Test 1: ScheduleVisit - Missing parameters
  // ----------------------------------------------------
  logTest('ScheduleVisit: Missing visit_date and visit_time');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: buyerUserId, language: 'en' },
      body: { car_id: targetCarId }
    });
    await ScheduleVisit(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400) {
      logPass('Correctly rejected incomplete scheduling payload (400)');
    } else {
      logFail(MODULE, 'ScheduleVisit allowed missing dates', new Error(`Status ${resp.statusCode}`), null, 'visitSchedule.controller.js:38');
    }
  } catch (err) {
    logFail(MODULE, 'ScheduleVisit threw error', err, null, 'visitSchedule.controller.js');
  }

  // ----------------------------------------------------
  // Test 2: ScheduleVisit - Seller scheduling own car
  // ----------------------------------------------------
  logTest('ScheduleVisit: Seller attempting to schedule visit for their own car');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: sellerUserId, fullName: 'Tom Seller', email: 'tom@yopmail.com', language: 'en' },
      body: {
        car_id: targetCarId,
        visit_date: '2026-10-15',
        visit_time: '14:00',
        phone_number: '+41791112233'
      }
    });
    await ScheduleVisit(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400 && String(resp.data?.message).includes('own listing')) {
      logPass('Correctly rejected seller scheduling visit for own car');
    } else {
      logFail(MODULE, 'ScheduleVisit allowed self-scheduling of visit', new Error(`Status ${resp.statusCode}`), null, 'visitSchedule.controller.js:55');
    }
  } catch (err) {
    logFail(MODULE, 'ScheduleVisit threw error during self-scheduling check', err, null, 'visitSchedule.controller.js');
  }

  // ----------------------------------------------------
  // Test 3: ScheduleVisit - Valid Buyer Visit Creation
  // ----------------------------------------------------
  logTest('ScheduleVisit: Valid scheduling from buyer');
  try {
    await db.query('DELETE FROM tbl_physical_visits WHERE user_id = ? AND car_id = ?', [buyerUserId, targetCarId]);
    const { req, res, getResponse } = createMockReqRes({
      user: { id: buyerUserId, fullName: 'Jack Buyer', email: 'jack@yopmail.com', language: 'en' },
      body: {
        car_id: targetCarId,
        visit_date: '2026-10-20',
        visit_time: '11:00 AM',
        phone_number: '+41799887766',
        message: 'Looking forward to testing the BMW Z4.'
      }
    });
    await ScheduleVisit(req, res);
    const resp = getResponse();

    const [visitRow] = await db.query(
      'SELECT id, status, car_id, user_id FROM tbl_physical_visits WHERE user_id = ? AND car_id = ? ORDER BY id DESC LIMIT 1',
      [buyerUserId, targetCarId]
    );

    if ((resp.statusCode === 200 || resp.statusCode === 201) && visitRow) {
      createdVisitId = visitRow.id;
      logPass(`Visit successfully scheduled (ID: ${createdVisitId}, Status: ${visitRow.status})`);
    } else {
      logFail(MODULE, 'ScheduleVisit failed to create record', new Error(JSON.stringify(resp.data)), null, 'visitSchedule.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'ScheduleVisit threw error', err, null, 'visitSchedule.controller.js');
  }

  // ----------------------------------------------------
  // Test 4: getScheduleRequestDetail - Detail view
  // ----------------------------------------------------
  logTest(`getScheduleRequestDetail: Fetch detail for visit ID ${createdVisitId || 1}`);
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: sellerUserId, language: 'en' },
      params: { id: createdVisitId || 1 }
    });
    await getScheduleRequestDetail(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 || resp.statusCode === 404) {
      logPass('Detail view returned response without crash');
    } else {
      logFail(MODULE, 'getScheduleRequestDetail returned status ' + resp.statusCode, new Error(JSON.stringify(resp.data)), null, 'visitSellerAction.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getScheduleRequestDetail threw error', err, null, 'visitSellerAction.controller.js');
  }

  // ----------------------------------------------------
  // Test 5: sellerPhysicalVisitAction - Unauthorized user attempt
  // ----------------------------------------------------
  logTest('sellerPhysicalVisitAction: Unauthorized user attempting to confirm visit');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: 999999, language: 'en' }, // Random unauthorized user
      params: { id: createdVisitId },
      body: { action: 'confirm' }
    });
    await sellerPhysicalVisitAction(req, res);
    const resp = getResponse();
    if (resp.statusCode === 403) {
      logPass('Correctly returned 403 Unauthorized access');
    } else {
      logFail(MODULE, 'sellerPhysicalVisitAction allowed unauthorized user to alter visit!', new Error(`Status ${resp.statusCode}`), null, 'visitSellerAction.controller.js:41', 'CRITICAL');
    }
  } catch (err) {
    logFail(MODULE, 'sellerPhysicalVisitAction threw error', err, null, 'visitSellerAction.controller.js');
  }

  // ----------------------------------------------------
  // Test 6: sellerPhysicalVisitAction - Invalid Action
  // ----------------------------------------------------
  logTest('sellerPhysicalVisitAction: Invalid action type ("destroy")');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: sellerUserId, language: 'en' },
      params: { id: createdVisitId },
      body: { action: 'destroy' }
    });
    await sellerPhysicalVisitAction(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400) {
      logPass('Correctly rejected invalid action with 400 "Invalid action"');
    } else {
      logFail(MODULE, 'sellerPhysicalVisitAction accepted invalid action', new Error(`Status ${resp.statusCode}`), null, 'visitSellerAction.controller.js:36');
    }
  } catch (err) {
    logFail(MODULE, 'sellerPhysicalVisitAction threw error on invalid action', err, null, 'visitSellerAction.controller.js');
  }

  // ----------------------------------------------------
  // Test 7: sellerPhysicalVisitAction - Seller Confirms Visit
  // ----------------------------------------------------
  if (createdVisitId) {
    logTest('sellerPhysicalVisitAction: Seller confirms scheduled visit');
    try {
      const { req, res, getResponse } = createMockReqRes({
        user: { id: sellerUserId, language: 'en' },
        params: { id: createdVisitId },
        body: { action: 'confirm' }
      });
      await sellerPhysicalVisitAction(req, res);
      const resp = getResponse();

      const [updated] = await db.query('SELECT status FROM tbl_physical_visits WHERE id = ?', [createdVisitId]);
      if (resp.statusCode === 200 && updated?.status === 'confirmed') {
        logPass('Visit successfully confirmed and status updated to "confirmed"');
      } else {
        logFail(MODULE, 'sellerPhysicalVisitAction failed to confirm visit', new Error(`Status ${resp.statusCode}`), null, 'visitSellerAction.controller.js:52');
      }
    } catch (err) {
      logFail(MODULE, 'sellerPhysicalVisitAction threw error during confirmation', err, null, 'visitSellerAction.controller.js');
    }

    // Clean up
    await db.query('DELETE FROM tbl_physical_visits WHERE id = ?', [createdVisitId]);
  }
}

if (process.argv[1] && process.argv[1].endsWith('test_06_visits_scheduling.js')) {
  runVisitsSchedulingTests().then(() => {
    console.log(`\nTests finished. Bugs found so far: ${globalBugs.bugs.length}`);
    process.exit(0);
  });
}
