import db from '../config/db.js';
import {
  createMockReqRes,
  logSuite,
  logTest,
  logPass,
  logFail,
  globalBugs
} from './test_helper.js';

import { getFacetedFilters } from '../controllers/shared/facetedFilters.controller.js';
import { getFuelTypes, getTransmissionTypes, getDriveTypes, getBodyTypes, getVehicleStates } from '../controllers/shared/filterBasicDropdowns.controller.js';
import { getBrandsList, getModelsList } from '../controllers/shared/brandsList.controller.js';
import { getExtrasList, getFeaturesList, getSortList } from '../controllers/shared/filterOptionsList.controller.js';

export async function runSearchFiltersTests() {
  const MODULE = 'Search & Filters';
  logSuite(MODULE);

  // ----------------------------------------------------
  // Test 1: getFacetedFilters - Query with brand filter
  // ----------------------------------------------------
  logTest('getFacetedFilters: Search with brandName="BMW"');
  try {
    const { req, res, getResponse } = createMockReqRes({
      body: { brandName: 'BMW' },
      query: { lang: 'en' }
    });
    await getFacetedFilters(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass(`Faceted search successful (returned data payload)`);
    } else {
      logFail(MODULE, 'getFacetedFilters returned error', new Error(`Status ${resp.statusCode}`), null, 'facetedFilters.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getFacetedFilters threw error', err, null, 'facetedFilters.controller.js');
  }

  // ----------------------------------------------------
  // Test 2: getFuelTypes Dropdown
  // ----------------------------------------------------
  logTest('getFuelTypes: Fetch fuel types with language="en"');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en' }
    });
    await getFuelTypes(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && resp.data?.data) {
      logPass('Fuel types fetched with categories and counts');
    } else {
      logFail(MODULE, 'getFuelTypes returned non-200', new Error(`Status ${resp.statusCode}`), null, 'filterBasicDropdowns.controller.js:6');
    }
  } catch (err) {
    logFail(MODULE, 'getFuelTypes threw error', err, null, 'filterBasicDropdowns.controller.js');
  }

  // ----------------------------------------------------
  // Test 3: getTransmissionTypes Dropdown
  // ----------------------------------------------------
  logTest('getTransmissionTypes: Fetch transmission types');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en' }
    });
    await getTransmissionTypes(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200) {
      logPass('Transmission types fetched successfully');
    } else {
      logFail(MODULE, 'getTransmissionTypes failed', new Error(`Status ${resp.statusCode}`), null, 'filterBasicDropdowns.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getTransmissionTypes threw error', err, null, 'filterBasicDropdowns.controller.js');
  }

  // ----------------------------------------------------
  // Test 4: getBodyTypes Dropdown
  // ----------------------------------------------------
  logTest('getBodyTypes: Fetch body types (Coupe, Sedan, SUV)');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en' }
    });
    await getBodyTypes(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200) {
      logPass('Body types fetched successfully');
    } else {
      logFail(MODULE, 'getBodyTypes failed', new Error(`Status ${resp.statusCode}`), null, 'filterBasicDropdowns.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getBodyTypes threw error', err, null, 'filterBasicDropdowns.controller.js');
  }

  // ----------------------------------------------------
  // Test 5: getBrandsList Dropdown
  // ----------------------------------------------------
  logTest('getBrandsList: Fetch vehicle brands list');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: {}
    });
    await getBrandsList(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && Array.isArray(resp.data?.data)) {
      logPass(`Brands list fetched (${resp.data.data.length} brands found)`);
    } else {
      logFail(MODULE, 'getBrandsList failed', new Error(`Status ${resp.statusCode}`), null, 'brandsList.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getBrandsList threw error', err, null, 'brandsList.controller.js');
  }

  // ----------------------------------------------------
  // Test 6: getModelsList Dropdown - Missing & Valid brand_id
  // ----------------------------------------------------
  logTest('getModelsList: Validation for missing brand_id');
  try {
    const { req: reqEmpty, res: resEmpty, getResponse: getRespEmpty } = createMockReqRes({ query: {} });
    await getModelsList(reqEmpty, resEmpty);
    const respEmpty = getRespEmpty();

    const { req: reqValid, res: resValid, getResponse: getRespValid } = createMockReqRes({
      query: { brand_id: 1 }
    });
    await getModelsList(reqValid, resValid);
    const respValid = getRespValid();

    if (respEmpty.statusCode === 400 && respValid.statusCode === 200) {
      logPass('Correctly rejected empty brand_id (400) and returned models for brand 1 (200)');
    } else {
      logFail(MODULE, 'getModelsList validation failed', new Error(`Empty: ${respEmpty.statusCode}, Valid: ${respValid.statusCode}`), null, 'brandsList.controller.js:38');
    }
  } catch (err) {
    logFail(MODULE, 'getModelsList threw error', err, null, 'brandsList.controller.js');
  }

  // ----------------------------------------------------
  // Test 7: getExtrasList
  // ----------------------------------------------------
  logTest('getExtrasList: Fetch extra options');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en' }
    });
    await getExtrasList(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200) {
      logPass('Extras options list fetched successfully');
    } else {
      logFail(MODULE, 'getExtrasList returned status ' + resp.statusCode, new Error(JSON.stringify(resp.data)), null, 'filterOptionsList.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getExtrasList threw error', err, null, 'filterOptionsList.controller.js');
  }

  // ----------------------------------------------------
  // Test 8: getFeaturesList
  // ----------------------------------------------------
  logTest('getFeaturesList: Fetch vehicle equipment features');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en' }
    });
    await getFeaturesList(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200) {
      logPass('Features equipment list fetched successfully');
    } else {
      logFail(MODULE, 'getFeaturesList returned status ' + resp.statusCode, new Error(JSON.stringify(resp.data)), null, 'filterOptionsList.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getFeaturesList threw error', err, null, 'filterOptionsList.controller.js');
  }

  // ----------------------------------------------------
  // Test 9: getSortList
  // ----------------------------------------------------
  logTest('getSortList: Fetch sort options (Price, Date, Mileage)');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { lang: 'en' }
    });
    await getSortList(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200) {
      logPass('Sort options fetched successfully');
    } else {
      logFail(MODULE, 'getSortList returned status ' + resp.statusCode, new Error(JSON.stringify(resp.data)), null, 'filterOptionsList.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getSortList threw error', err, null, 'filterOptionsList.controller.js');
  }
}

if (process.argv[1] && process.argv[1].endsWith('test_04_search_filters.js')) {
  runSearchFiltersTests().then(() => {
    console.log(`\nTests finished. Bugs found so far: ${globalBugs.bugs.length}`);
    process.exit(0);
  });
}
