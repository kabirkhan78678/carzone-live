import db from '../config/db.js';
import {
  createMockReqRes,
  logSuite,
  logTest,
  logPass,
  logFail,
  globalBugs
} from './test_helper.js';

import { viewCarDetailByCarId } from '../controllers/shared/carDetails.controller.js';
import { asGuestUserGetCar } from '../controllers/shared/guestCarDetails.controller.js';
import { getMyCar, toggleCarActiveStatus } from '../controllers/shared/myCars.controller.js';
import { listCar } from '../controllers/shared/listCar.controller.js';
import { deleteCar, deleteCarImageByUrl } from '../controllers/shared/carDelete.controller.js';

export async function runCarsInventoryTests() {
  const MODULE = 'Cars & Inventory';
  logSuite(MODULE);

  const existingCarId = 2; // BMW Z4 Z85 Coupé, user_id: 251

  // ----------------------------------------------------
  // Test 1: viewCarDetailByCarId - Valid Car
  // ----------------------------------------------------
  logTest('viewCarDetailByCarId: Valid car ID 2 with authenticated user');
  try {
    const { req, res, getResponse } = createMockReqRes({
      params: { id: existingCarId },
      user: { id: 58, language: 'en' }
    });
    await viewCarDetailByCarId(req, res);
    const resp = getResponse();
    const car = resp.data?.carDetails || resp.data?.data?.carDetails || resp.data?.data;
    if (resp.statusCode === 200 && car) {
      if (car.brandName && car.carModel) {
        logPass(`Car details fetched: ${car.brandName} ${car.carModel}`);
      } else {
        logFail(MODULE, 'viewCarDetailByCarId missing brandName or carModel', new Error('Missing core car fields'), null, 'carDetails.controller.js');
      }
    } else {
      logFail(MODULE, `viewCarDetailByCarId returned status ${resp.statusCode}`, new Error(JSON.stringify(resp.data)), { carId: existingCarId }, 'carDetails.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'viewCarDetailByCarId threw exception', err, { carId: existingCarId }, 'carDetails.controller.js');
  }

  // ----------------------------------------------------
  // Test 2: viewCarDetailByCarId - Non-existent Car
  // ----------------------------------------------------
  logTest('viewCarDetailByCarId: Non-existent car ID (999999)');
  try {
    const { req, res, getResponse } = createMockReqRes({
      params: { id: 999999 },
      user: { id: 58, language: 'en' }
    });
    await viewCarDetailByCarId(req, res);
    const resp = getResponse();
    if (resp.statusCode === 404) {
      logPass('Correctly returned 404 CAR_NOT_FOUND');
    } else {
      logFail(MODULE, 'viewCarDetailByCarId should return 404 for invalid car', new Error(`Status ${resp.statusCode}`), null, 'carDetails.controller.js:16');
    }
  } catch (err) {
    logFail(MODULE, 'viewCarDetailByCarId crashed on invalid car ID', err, null, 'carDetails.controller.js');
  }

  // ----------------------------------------------------
  // Test 3: asGuestUserGetCar - Unauthenticated Guest
  // ----------------------------------------------------
  logTest('asGuestUserGetCar: Public endpoint for car ID 2');
  try {
    const { req, res, getResponse } = createMockReqRes({
      params: { id: existingCarId }
    });
    await asGuestUserGetCar(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200) {
      logPass('Successfully fetched car details as guest');
    } else {
      logFail(MODULE, `asGuestUserGetCar returned status ${resp.statusCode}`, new Error(JSON.stringify(resp.data)), null, 'guestCarDetails.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'asGuestUserGetCar threw exception', err, null, 'guestCarDetails.controller.js');
  }

  // ----------------------------------------------------
  // Test 4: getMyCar - Seller inventory
  // ----------------------------------------------------
  logTest('getMyCar: Fetch seller listing inventory for user 251');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: 251, language: 'en' }
    });
    await getMyCar(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && Array.isArray(resp.data?.data)) {
      logPass(`Successfully fetched seller inventory (${resp.data.data.length} published cars)`);
    } else {
      logFail(MODULE, `getMyCar returned status ${resp.statusCode}`, new Error(JSON.stringify(resp.data)), null, 'myCars.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getMyCar threw exception', err, null, 'myCars.controller.js');
  }

  // ----------------------------------------------------
  // Test 5: listCar - Validation & Slot/Plan check
  // ----------------------------------------------------
  logTest('listCar: User without active subscription plan');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: 999999, language: 'en' },
      body: {
        brandName: 'Audi',
        carModel: 'A6',
        selectYear: 2022,
        totalPrice: 45000
      }
    });
    await listCar(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400) {
      logPass('Correctly rejected car listing when user has no active plan');
    } else {
      logFail(MODULE, 'listCar allowed car listing without active plan', new Error(`Status ${resp.statusCode}`), null, 'listCar.controller.js:72');
    }
  } catch (err) {
    logFail(MODULE, 'listCar threw exception on missing plan check', err, null, 'listCar.controller.js');
  }

  // ----------------------------------------------------
  // Test 6: toggleCarActiveStatus - Unauthorized user attempt
  // ----------------------------------------------------
  logTest('toggleCarActiveStatus: Attempting to toggle car belonging to another user');
  try {
    // Car 2 belongs to user 251. We try from user 58.
    const { req, res, getResponse } = createMockReqRes({
      params: { carId: 2 },
      user: { id: 58, language: 'en' }
    });
    await toggleCarActiveStatus(req, res);
    const resp = getResponse();
    if (resp.statusCode === 404 || resp.statusCode === 403 || resp.statusCode === 400) {
      logPass(`Correctly prevented unauthorized toggle (Status ${resp.statusCode})`);
    } else {
      logFail(MODULE, 'toggleCarActiveStatus allowed unauthorized user to alter another user car!', new Error(`Status ${resp.statusCode}`), null, 'carUpdate.controller.js', 'CRITICAL');
    }
  } catch (err) {
    logFail(MODULE, 'toggleCarActiveStatus threw error during unauthorized check', err, null, 'carUpdate.controller.js');
  }

  // ----------------------------------------------------
  // Test 7: deleteCar - Unauthorized user deletion attempt
  // ----------------------------------------------------
  logTest('deleteCar: Attempting to delete car belonging to another user');
  try {
    const { req, res, getResponse } = createMockReqRes({
      params: { carId: 2 },
      user: { id: 58, language: 'en' }
    });
    await deleteCar(req, res);
    const resp = getResponse();
    if (resp.statusCode === 404) {
      logPass('Correctly rejected unauthorized deletion with 404 CAR_NOT_FOUND_OR_UNAUTHORIZED');
    } else {
      logFail(MODULE, 'deleteCar security flaw: returned non-404 on unauthorized deletion', new Error(`Status ${resp.statusCode}`), null, 'carDelete.controller.js:14', 'CRITICAL');
    }
  } catch (err) {
    logFail(MODULE, 'deleteCar threw error during unauthorized delete check', err, null, 'carDelete.controller.js');
  }

  // ----------------------------------------------------
  // Test 8: deleteCarImageByUrl - Empty payload validation
  // ----------------------------------------------------
  logTest('deleteCarImageByUrl: Missing image URL');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: 58, language: 'en' },
      body: {}
    });
    await deleteCarImageByUrl(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400) {
      logPass('Correctly rejected request with 400 IMAGE_URL_REQUIRED');
    } else {
      logFail(MODULE, 'deleteCarImageByUrl accepted empty payload', new Error(`Status ${resp.statusCode}`), null, 'carDelete.controller.js:45');
    }
  } catch (err) {
    logFail(MODULE, 'deleteCarImageByUrl threw error', err, null, 'carDelete.controller.js');
  }
}

if (process.argv[1] && process.argv[1].endsWith('test_02_cars_inventory.js')) {
  runCarsInventoryTests().then(() => {
    console.log(`\nTests finished. Bugs found so far: ${globalBugs.bugs.length}`);
    process.exit(0);
  });
}
