import db from '../config/db.js';

async function auditSchemas() {
    try {
        const tables = [
            'purchase_agreements',
            'tbl_cars',
            'tbl_car_wishlist',
            'chat_attachments',
            'tbl_chat_attachments',
            'tbl_notification',
            'tbl_recently_viewed',
            'tbl_physical_visits',
            'tbl_saved_searches',
            'tbl_saved_car_reels',
            'users_reels',
            'tbl_support',
            'tbl_help_support',
            'tbl_app_feedback',
            'tbl_user_plans',
            'tbl_purchases',
            'slot_requests',
            'seller_opening_times',
            'seller_advantages',
            'seller_services',
            'seller_team_members',
            'seller_images',
            'seller_videos',
            'tbl_car_leasing',
            'tbl_report_car'
        ];

        for (const t of tables) {
            console.log(`\n================= TABLE: ${t} =================`);
            const cols = await db.query(`DESCRIBE ${t}`);
            console.log(cols.map(c => `${c.Field} (${c.Type})`).join(', '));
            const count = await db.query(`SELECT COUNT(*) as c FROM ${t}`);
            console.log(`Row count: ${count[0].c}`);
            const sample = await db.query(`SELECT * FROM ${t} LIMIT 1`);
            if (sample.length > 0) {
                console.log(`Sample row keys:`, Object.keys(sample[0]));
            }
        }

        process.exit(0);
    } catch (err) {
        console.error("Audit error:", err);
        process.exit(1);
    }
}

auditSchemas();
