import db from '../config/db.js';

async function purgeDuplicateNotifications() {
    try {
        console.log("=================================================================");
        console.log("       STARTING PURGE OF DUPLICATE NOTIFICATION SPAM ROWS        ");
        console.log("=================================================================");

        const [initialCount] = await db.query("SELECT COUNT(*) AS total FROM tbl_notification");
        console.log(`Initial total notifications: ${initialCount.total}`);

        // 1. Identify the latest ID to keep for each user for 'plan_expired'
        console.log("\n[Step 1] Finding latest 'plan_expired' notification ID for each user to preserve...");
        const keepRows = await db.query(`
            SELECT sendTo, MAX(id) AS keep_id, COUNT(*) AS total_for_user
            FROM tbl_notification
            WHERE notificationType = 'plan_expired'
            GROUP BY sendTo
        `);
        console.log(`Found ${keepRows.length} users with 'plan_expired' records.`);
        const keepIds = keepRows.map(r => r.keep_id).filter(Boolean);
        console.log(`IDs to preserve (1 latest per user):`, keepIds);

        if (keepIds.length === 0) {
            console.log("No plan_expired notifications found to purge.");
            process.exit(0);
        }

        const keepPlaceholders = keepIds.map(() => '?').join(',');

        // 2. Count total rows to delete
        const [toDeleteCount] = await db.query(`
            SELECT COUNT(*) AS total
            FROM tbl_notification
            WHERE notificationType = 'plan_expired'
              AND id NOT IN (${keepPlaceholders})
        `, keepIds);
        console.log(`\n[Step 2] Total redundant 'plan_expired' rows to delete: ${toDeleteCount.total}`);

        if (toDeleteCount.total === 0) {
            console.log("No duplicate rows to delete.");
        } else {
            // 3. Delete in batches of 50,000 to keep DB responsive
            console.log("\n[Step 3] Deleting spam rows in batches of 50,000...");
            let deletedTotal = 0;
            const batchSize = 50000;

            while (true) {
                const result = await db.query(`
                    DELETE FROM tbl_notification
                    WHERE notificationType = 'plan_expired'
                      AND id NOT IN (${keepPlaceholders})
                    LIMIT ?
                `, [...keepIds, batchSize]);

                const affected = result.affectedRows || 0;
                deletedTotal += affected;
                console.log(`Deleted batch: ${affected.toLocaleString()} rows (Total purged so far: ${deletedTotal.toLocaleString()} / ${toDeleteCount.total.toLocaleString()})`);

                if (affected === 0) {
                    break;
                }
            }
            console.log(`✔ Successfully purged ${deletedTotal.toLocaleString()} duplicate spam rows!`);
        }

        // 4. Create Indexes for High Performance
        console.log("\n[Step 4] Optimizing table indexes...");
        const existingIndexes = await db.query("SHOW INDEX FROM tbl_notification");
        const indexNames = new Set(existingIndexes.map(i => i.Key_name));

        if (!indexNames.has('idx_notif_sendTo_isRead')) {
            console.log("Creating index: idx_notif_sendTo_isRead...");
            await db.query("CREATE INDEX idx_notif_sendTo_isRead ON tbl_notification (sendTo, isRead)");
            console.log("✔ Created idx_notif_sendTo_isRead");
        } else {
            console.log("✔ idx_notif_sendTo_isRead already exists.");
        }

        if (!indexNames.has('idx_notif_sendTo_type')) {
            console.log("Creating index: idx_notif_sendTo_type...");
            await db.query("CREATE INDEX idx_notif_sendTo_type ON tbl_notification (sendTo, notificationType)");
            console.log("✔ Created idx_notif_sendTo_type");
        } else {
            console.log("✔ idx_notif_sendTo_type already exists.");
        }

        if (!indexNames.has('idx_notif_sendFrom')) {
            console.log("Creating index: idx_notif_sendFrom...");
            await db.query("CREATE INDEX idx_notif_sendFrom ON tbl_notification (sendFrom)");
            console.log("✔ Created idx_notif_sendFrom");
        } else {
            console.log("✔ idx_notif_sendFrom already exists.");
        }

        // 5. Final verification & statistics
        console.log("\n[Step 5] Final verification of clean table state...");
        const [finalCount] = await db.query("SELECT COUNT(*) AS total FROM tbl_notification");
        const breakdown = await db.query(`
            SELECT notificationType, COUNT(*) AS count
            FROM tbl_notification
            GROUP BY notificationType
            ORDER BY count DESC
        `);

        console.log(`\n=================================================================`);
        console.log(`FINAL CLEAN NOTIFICATIONS COUNT: ${finalCount.total}`);
        console.log(`=================================================================`);
        console.table(breakdown);

        process.exit(0);
    } catch (e) {
        console.error("Purge error:", e);
        process.exit(1);
    }
}

purgeDuplicateNotifications();
