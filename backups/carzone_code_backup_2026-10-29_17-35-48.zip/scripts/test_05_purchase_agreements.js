import db from '../config/db.js';
import {
  createMockReqRes,
  logSuite,
  logTest,
  logPass,
  logFail,
  globalBugs
} from './test_helper.js';

import { getPurchaseAgreementWarrantyTypes } from '../controllers/shared/purchaseAgreementWarrantyTypes.controller.js';
import { createPurchaseAgreementController } from '../controllers/shared/purchaseAgreementCreate.controller.js';
import { getPurchaseAgreementThroughId } from '../controllers/shared/agreementDetails.controller.js';
import { downloadBlankPurchaseAgreementTemplate } from '../controllers/shared/purchaseAgreementPdf.controller.js';
import { downloadCarPdf } from '../controllers/shared/carPdf.controller.js';

export async function runPurchaseAgreementsTests() {
  const MODULE = 'Purchase Agreements & PDF';
  logSuite(MODULE);

  // ----------------------------------------------------
  // Test 1: getPurchaseAgreementWarrantyTypes
  // ----------------------------------------------------
  logTest('getPurchaseAgreementWarrantyTypes: Fetch legal warranty options');
  try {
    const { req, res, getResponse } = createMockReqRes({ query: { lang: 'en' } });
    await getPurchaseAgreementWarrantyTypes(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && Array.isArray(resp.data?.data)) {
      logPass(`Warranty types fetched (${resp.data.data.length} types)`);
    } else {
      logFail(MODULE, 'getPurchaseAgreementWarrantyTypes returned error', new Error(`Status ${resp.statusCode}`), null, 'purchaseAgreementWarrantyTypes.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getPurchaseAgreementWarrantyTypes threw error', err, null, 'purchaseAgreementWarrantyTypes.controller.js');
  }

  // ----------------------------------------------------
  // Test 2: createPurchaseAgreement - Authorization check for private account
  // ----------------------------------------------------
  logTest('createPurchaseAgreement: Private user attempt (should be 403 Forbidden)');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: 58, account_type: 'private', language: 'en' },
      params: { vehicleId: 2 }
    });
    await createPurchaseAgreementController(req, res);
    const resp = getResponse();
    if (resp.statusCode === 403) {
      logPass('Correctly blocked non-dealer/private account with 403 Forbidden');
    } else {
      logFail(MODULE, 'createPurchaseAgreement allowed non-dealer account!', new Error(`Status ${resp.statusCode}`), null, 'purchaseAgreementCreate.controller.js:28', 'HIGH');
    }
  } catch (err) {
    logFail(MODULE, 'createPurchaseAgreement threw error on private account check', err, null, 'purchaseAgreementCreate.controller.js');
  }

  // ----------------------------------------------------
  // Test 3: createPurchaseAgreement - Vehicle not found or not owned by company
  // ----------------------------------------------------
  logTest('createPurchaseAgreement: Company attempting to create agreement on unowned car');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: 59, account_type: 'company', language: 'en' }, // CarZone Motors (User 59)
      params: { vehicleId: 999999 } // unowned car
    });
    await createPurchaseAgreementController(req, res);
    const resp = getResponse();
    if (resp.statusCode === 404) {
      logPass('Correctly returned 404 for unowned/missing vehicle');
    } else {
      logFail(MODULE, 'createPurchaseAgreement failed to return 404 for missing vehicle', new Error(`Status ${resp.statusCode}`), null, 'purchaseAgreementCreate.controller.js:51');
    }
  } catch (err) {
    logFail(MODULE, 'createPurchaseAgreement threw error on unowned vehicle', err, null, 'purchaseAgreementCreate.controller.js');
  }

  // ----------------------------------------------------
  // Test 4: getPurchaseAgreementThroughId - Access Control & Validation
  // ----------------------------------------------------
  logTest('getPurchaseAgreementThroughId: Invalid non-numeric ID');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: 59, account_type: 'company', language: 'en' },
      params: { id: 'abc_not_a_number' }
    });
    await getPurchaseAgreementThroughId(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400) {
      logPass('Correctly rejected non-numeric agreement ID with 400');
    } else {
      logFail(MODULE, 'getPurchaseAgreementThroughId allowed non-numeric ID', new Error(`Status ${resp.statusCode}`), null, 'agreementDetails.controller.js:33');
    }
  } catch (err) {
    logFail(MODULE, 'getPurchaseAgreementThroughId threw error', err, null, 'agreementDetails.controller.js');
  }

  // ----------------------------------------------------
  // Test 5: downloadBlankPurchaseAgreementTemplate
  // ----------------------------------------------------
  logTest('downloadBlankPurchaseAgreementTemplate: Generate blank PDF template');
  try {
    const { req, res, getResponse } = createMockReqRes({ query: { lang: 'en' } });
    await downloadBlankPurchaseAgreementTemplate(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200) {
      logPass('Blank purchase agreement PDF generated successfully');
    } else {
      logFail(MODULE, 'downloadBlankPurchaseAgreementTemplate failed', new Error(`Status ${resp.statusCode}`), null, 'purchaseAgreementPdf.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'downloadBlankPurchaseAgreementTemplate threw error', err, null, 'purchaseAgreementPdf.controller.js');
  }

  // ----------------------------------------------------
  // Test 6: downloadCarPdf - Vehicle Spec Sheet PDF
  // ----------------------------------------------------
  logTest('downloadCarPdf: Generate Car PDF for vehicle ID 2');
  try {
    const { req, res, getResponse } = createMockReqRes({
      params: { id: 2 }
    });
    await downloadCarPdf(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200) {
      logPass('Vehicle PDF spec sheet generated successfully');
    } else {
      logFail(MODULE, 'downloadCarPdf failed', new Error(`Status ${resp.statusCode}`), null, 'carPdf.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'downloadCarPdf threw error', err, null, 'carPdf.controller.js');
  }
}

if (process.argv[1] && process.argv[1].endsWith('test_05_purchase_agreements.js')) {
  runPurchaseAgreementsTests().then(() => {
    console.log(`\nTests finished. Bugs found so far: ${globalBugs.bugs.length}`);
    process.exit(0);
  });
}
