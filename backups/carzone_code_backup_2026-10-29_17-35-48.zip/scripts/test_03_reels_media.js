import db from '../config/db.js';
import {
  createMockReqRes,
  logSuite,
  logTest,
  logPass,
  logFail,
  globalBugs
} from './test_helper.js';

import { fetchAllCarReels } from '../controllers/shared/allCarReels.controller.js';
import { asGuestUsersfetchAllCarReels } from '../controllers/shared/guestCarReels.controller.js';
import { fetchCarReels } from '../controllers/shared/userCarReels.controller.js';
import { saveCarReels, fetchedSavedCarReels, removeSavedCarsReel } from '../controllers/shared/carReelsSave.controller.js';
import { fetchMyReels, fetchReelById } from '../controllers/shared/profileReelsFetchDelete.controller.js';

export async function runReelsMediaTests() {
  const MODULE = 'Reels & Media';
  logSuite(MODULE);

  const testUserId = 58;

  // ----------------------------------------------------
  // Test 1: fetchAllCarReels - Basic Feed
  // ----------------------------------------------------
  logTest('fetchAllCarReels: Fetch paginated reels feed (Page 1)');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      query: { page: 1 }
    });
    await fetchAllCarReels(req, res);
    const resp = getResponse();
    const reelsList = resp.data?.data?.data || resp.data?.data;
    if (resp.statusCode === 200 && Array.isArray(reelsList)) {
      logPass(`Reels feed returned ${reelsList.length} items`);
    } else {
      logFail(MODULE, 'fetchAllCarReels failed to return list', new Error(`Status ${resp.statusCode}`), null, 'allCarReels.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'fetchAllCarReels threw error', err, null, 'allCarReels.controller.js');
  }

  // ----------------------------------------------------
  // Test 2: fetchAllCarReels - Filter by Specific car_id
  // ----------------------------------------------------
  logTest('fetchAllCarReels: Filter by car_id=97 (Active reel car)');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      query: { car_id: 97 }
    });
    await fetchAllCarReels(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200) {
      logPass('Successfully filtered reels by specific car_id=97');
    } else {
      logFail(MODULE, 'fetchAllCarReels with car_id returned error', new Error(`Status ${resp.statusCode}`), { car_id: 97 }, 'allCarReels.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'fetchAllCarReels with car_id threw error', err, { car_id: 97 }, 'allCarReels.controller.js');
  }

  // ----------------------------------------------------
  // Test 3: asGuestUsersfetchAllCarReels - Unauthenticated
  // ----------------------------------------------------
  logTest('asGuestUsersfetchAllCarReels: Public reel feed');
  try {
    const { req, res, getResponse } = createMockReqRes({
      query: { page: 1 }
    });
    await asGuestUsersfetchAllCarReels(req, res);
    const resp = getResponse();
    const guestReels = resp.data?.data?.data || resp.data?.data;
    if (resp.statusCode === 200 && Array.isArray(guestReels)) {
      logPass(`Guest reels feed returned ${guestReels.length} items`);
    } else {
      logFail(MODULE, 'asGuestUsersfetchAllCarReels failed', new Error(`Status ${resp.statusCode}`), null, 'guestCarReels.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'asGuestUsersfetchAllCarReels threw error', err, null, 'guestCarReels.controller.js');
  }

  // ----------------------------------------------------
  // Test 4: saveCarReels - Parameter Naming Discrepancy Bug Check
  // ----------------------------------------------------
  logTest('saveCarReels: BUG CHECK - Sending snake_case car_id (as declared in validation)');
  try {
    // Validation allows car_id, but controller does: let { carId, reelType } = req.body
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { car_id: 2, reelType: 'car' } // snake_case car_id!
    });
    await saveCarReels(req, res);
    const resp = getResponse();

    // Check what was inserted in tbl_saved_car_reels
    const [inserted] = await db.query(
      'SELECT * FROM tbl_saved_car_reels WHERE userId = ? ORDER BY id DESC LIMIT 1',
      [testUserId]
    );

    if (inserted && inserted.carId === null) {
      logFail(
        MODULE,
        'CRITICAL BUG in saveCarReels: When frontend sends car_id (as validated), controller only reads carId, inserting NULL into tbl_saved_car_reels.carId!',
        new Error('Inserted carId is null because of camelCase/snake_case mismatch'),
        { sent: { car_id: 2 }, insertedInDb: inserted },
        'controllers/shared/carReelsSave.controller.js:9',
        'CRITICAL'
      );
      // Clean up
      await db.query('DELETE FROM tbl_saved_car_reels WHERE id = ?', [inserted.id]);
    } else if (resp.statusCode === 200) {
      logPass('saveCarReels correctly handled parameter');
      if (inserted) await db.query('DELETE FROM tbl_saved_car_reels WHERE id = ?', [inserted.id]);
    } else {
      logFail(MODULE, 'saveCarReels failed with status ' + resp.statusCode, new Error(JSON.stringify(resp.data)), null, 'carReelsSave.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'saveCarReels threw exception', err, null, 'carReelsSave.controller.js');
  }

  // ----------------------------------------------------
  // Test 5: saveCarReels & fetchedSavedCarReels - With camelCase carId
  // ----------------------------------------------------
  logTest('saveCarReels & fetchedSavedCarReels: Valid save and fetch cycle');
  try {
    const { req: reqSave, res: resSave } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { carId: 2, reelType: 'car' }
    });
    await saveCarReels(reqSave, resSave);

    const { req: reqFetch, res: resFetch, getResponse: getRespFetch } = createMockReqRes({
      user: { id: testUserId, language: 'en' }
    });
    await fetchedSavedCarReels(reqFetch, resFetch);
    const respFetch = getRespFetch();

    if (respFetch.statusCode === 200 && Array.isArray(respFetch.data?.data)) {
      logPass(`Saved reels fetched successfully (${respFetch.data.data.length} saved)`);
    } else {
      logFail(MODULE, 'fetchedSavedCarReels failed to return saved items', new Error(`Status ${respFetch.statusCode}`), null, 'carReelsSave.controller.js:34');
    }

    // Clean up
    await db.query('DELETE FROM tbl_saved_car_reels WHERE userId = ? AND carId = 2', [testUserId]);
  } catch (err) {
    logFail(MODULE, 'saveCarReels / fetchedSavedCarReels cycle failed', err, null, 'carReelsSave.controller.js');
  }

  // ----------------------------------------------------
  // Test 6: fetchReelById - Parameter Validation Check
  // ----------------------------------------------------
  logTest('fetchReelById: Missing required parameters (reel_id and reelType)');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      query: {}
    });
    await fetchReelById(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400) {
      logPass('Correctly returned 400 when reel_id or reelType is missing');
    } else {
      logFail(MODULE, 'fetchReelById allowed missing query parameters', new Error(`Status ${resp.statusCode}`), null, 'profileReelsFetchDelete.controller.js:41');
    }
  } catch (err) {
    logFail(MODULE, 'fetchReelById threw exception', err, null, 'profileReelsFetchDelete.controller.js');
  }

  // ----------------------------------------------------
  // Test 7: fetchMyReels
  // ----------------------------------------------------
  logTest('fetchMyReels: Fetch profile reels for user');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' }
    });
    await fetchMyReels(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && Array.isArray(resp.data?.data)) {
      logPass(`fetchMyReels returned ${resp.data.data.length} profile reels`);
    } else {
      logFail(MODULE, 'fetchMyReels failed', new Error(`Status ${resp.statusCode}`), null, 'profileReelsFetchDelete.controller.js:6');
    }
  } catch (err) {
    logFail(MODULE, 'fetchMyReels threw error', err, null, 'profileReelsFetchDelete.controller.js');
  }
}

if (process.argv[1] && process.argv[1].endsWith('test_03_reels_media.js')) {
  runReelsMediaTests().then(() => {
    console.log(`\nTests finished. Bugs found so far: ${globalBugs.bugs.length}`);
    process.exit(0);
  });
}
