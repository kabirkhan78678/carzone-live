import db from '../config/db.js';
import {
  createMockReqRes,
  logSuite,
  logTest,
  logPass,
  logFail,
  globalBugs
} from './test_helper.js';

import { addToWishlist, fetchUserWishlist, removeCarFromWishlist } from '../controllers/shared/wishlist.controller.js';
import { addRecentlyViewed, getRecentlyViewed } from '../controllers/shared/recentlyViewedInquiry.controller.js';
import { createSavedSearchController, getSavedSearchesController, deleteSavedSearchController } from '../controllers/shared/savedSearch.controller.js';
import { getReportReasons } from '../controllers/shared/carReportReasons.controller.js';
import { reportCar } from '../controllers/shared/carReportSubmit.controller.js';

export async function runUserInteractionsTests() {
  const MODULE = 'User Interactions & Wishlist';
  logSuite(MODULE);

  const testUserId = 58;
  const targetCarId = 97; // Active published car

  // Pre-cleanup wishlist for this car
  await db.query('DELETE FROM tbl_car_wishlist WHERE user_id = ? AND carId = ?', [testUserId, targetCarId]);

  // ----------------------------------------------------
  // Test 1: addToWishlist - Missing carId
  // ----------------------------------------------------
  logTest('addToWishlist: Missing carId');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: {}
    });
    await addToWishlist(req, res);
    const resp = getResponse();
    if (resp.statusCode === 400) {
      logPass('Correctly rejected missing carId with 400');
    } else {
      logFail(MODULE, 'addToWishlist allowed empty carId', new Error(`Status ${resp.statusCode}`), null, 'wishlist.controller.js:12');
    }
  } catch (err) {
    logFail(MODULE, 'addToWishlist threw error', err, null, 'wishlist.controller.js');
  }

  // ----------------------------------------------------
  // Test 2: addToWishlist - Valid addition & Duplicate check
  // ----------------------------------------------------
  logTest('addToWishlist: Valid addition and duplicate detection');
  try {
    const { req: reqAdd, res: resAdd, getResponse: getRespAdd } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { carId: targetCarId }
    });
    await addToWishlist(reqAdd, resAdd);
    const respAdd = getRespAdd();

    // Attempt duplicate
    const { req: reqDup, res: resDup, getResponse: getRespDup } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { carId: targetCarId }
    });
    await addToWishlist(reqDup, resDup);
    const respDup = getRespDup();

    if (respAdd.statusCode === 200 && respDup.statusCode === 400) {
      logPass('Car added to wishlist, and duplicate attempt correctly returned 400');
    } else {
      logFail(MODULE, 'addToWishlist duplicate handling failed', new Error(`Add: ${respAdd.statusCode}, Dup: ${respDup.statusCode}`), null, 'wishlist.controller.js:16');
    }
  } catch (err) {
    logFail(MODULE, 'addToWishlist threw error on duplicate check', err, null, 'wishlist.controller.js');
  }

  // ----------------------------------------------------
  // Test 3: fetchUserWishlist
  // ----------------------------------------------------
  logTest('fetchUserWishlist: Fetch user wishlist');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      query: { page: 1, limit: 10 }
    });
    await fetchUserWishlist(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && Array.isArray(resp.data?.data)) {
      logPass(`Wishlist fetched successfully (${resp.data.data.length} cars found)`);
    } else {
      logFail(MODULE, 'fetchUserWishlist returned non-200', new Error(`Status ${resp.statusCode}`), null, 'wishlist.controller.js:30');
    }
  } catch (err) {
    logFail(MODULE, 'fetchUserWishlist threw error', err, null, 'wishlist.controller.js');
  }

  // ----------------------------------------------------
  // Test 4: removeCarFromWishlist
  // ----------------------------------------------------
  logTest('removeCarFromWishlist: Remove car from wishlist');
  try {
    const { req, res, getResponse } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { carId: targetCarId }
    });
    await removeCarFromWishlist(req, res);
    const resp = getResponse();

    const [exists] = await db.query('SELECT * FROM tbl_car_wishlist WHERE user_id = ? AND carId = ?', [testUserId, targetCarId]);
    if (resp.statusCode === 200 && !exists) {
      logPass('Car successfully removed from wishlist');
    } else {
      logFail(MODULE, 'removeCarFromWishlist failed', new Error(`Status ${resp.statusCode}`), null, 'wishlist.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'removeCarFromWishlist threw error', err, null, 'wishlist.controller.js');
  }

  // ----------------------------------------------------
  // Test 5: addRecentlyViewed & getRecentlyViewed
  // ----------------------------------------------------
  logTest('addRecentlyViewed & getRecentlyViewed: Add and fetch viewing history');
  try {
    const { req: reqAdd, res: resAdd } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: { car_id: targetCarId }
    });
    await addRecentlyViewed(reqAdd, resAdd);

    const { req: reqGet, res: resGet, getResponse: getRespGet } = createMockReqRes({
      user: { id: testUserId, language: 'en' }
    });
    await getRecentlyViewed(reqGet, resGet);
    const respGet = getRespGet();

    if (respGet.statusCode === 200 && Array.isArray(respGet.data?.data)) {
      logPass(`Recently viewed cars fetched (${respGet.data.data.length} items)`);
    } else {
      logFail(MODULE, 'getRecentlyViewed returned error', new Error(`Status ${respGet.statusCode}`), null, 'recentlyViewedInquiry.controller.js:33');
    }
  } catch (err) {
    logFail(MODULE, 'Recently viewed cycle threw error', err, null, 'recentlyViewedInquiry.controller.js');
  }

  // ----------------------------------------------------
  // Test 6: createSavedSearchController & getSavedSearchesController
  // ----------------------------------------------------
  logTest('Saved Searches: Create, Fetch, and Delete cycle');
  let savedSearchId = null;
  try {
    const { req: reqCreate, res: resCreate, getResponse: getRespCreate } = createMockReqRes({
      user: { id: testUserId, language: 'en' },
      body: {
        search_name: 'BMW Diesel SUVs',
        filters: { brandName: 'BMW', fuel_type_id: 2 }
      }
    });
    await createSavedSearchController(reqCreate, resCreate);
    const respCreate = getRespCreate();

    if (respCreate.statusCode === 201 && respCreate.data?.data?.id) {
      savedSearchId = respCreate.data.data.id;
      logPass(`Saved search created successfully (ID: ${savedSearchId})`);
    } else {
      logFail(MODULE, 'createSavedSearchController returned status ' + respCreate.statusCode, new Error(JSON.stringify(respCreate.data)), null, 'savedSearch.controller.js:6');
    }

    if (savedSearchId) {
      const { req: reqDelete, res: resDelete, getResponse: getRespDelete } = createMockReqRes({
        user: { id: testUserId, language: 'en' },
        params: { id: savedSearchId }
      });
      await deleteSavedSearchController(reqDelete, resDelete);
      const respDelete = getRespDelete();
      if (respDelete.statusCode === 200) {
        logPass('Saved search deleted successfully');
      } else {
        logFail(MODULE, 'deleteSavedSearchController failed', new Error(`Status ${respDelete.statusCode}`), null, 'savedSearch.controller.js:51');
      }
    }
  } catch (err) {
    logFail(MODULE, 'Saved searches lifecycle threw error', err, null, 'savedSearch.controller.js');
  }

  // ----------------------------------------------------
  // Test 7: getReportReasons & reportCar
  // ----------------------------------------------------
  logTest('Car Reporting: Fetch report reasons');
  try {
    const { req, res, getResponse } = createMockReqRes({ query: { lang: 'en' } });
    await getReportReasons(req, res);
    const resp = getResponse();
    if (resp.statusCode === 200 && Array.isArray(resp.data?.data)) {
      logPass(`Report reasons fetched (${resp.data.data.length} options available)`);
    } else {
      logFail(MODULE, 'getReportReasons failed', new Error(`Status ${resp.statusCode}`), null, 'carReportReasons.controller.js');
    }
  } catch (err) {
    logFail(MODULE, 'getReportReasons threw error', err, null, 'carReportReasons.controller.js');
  }
}

if (process.argv[1] && process.argv[1].endsWith('test_07_user_interactions.js')) {
  runUserInteractionsTests().then(() => {
    console.log(`\nTests finished. Bugs found so far: ${globalBugs.bugs.length}`);
    process.exit(0);
  });
}
