/**
 * Test Helper Utility for Backend Module Testing
 * Provides mock request/response, assertion helpers, and bug aggregation.
 */

export class BugCollector {
  constructor() {
    this.bugs = [];
    this.stats = { total: 0, passed: 0, failed: 0 };
  }

  recordBug({ module, title, severity = 'HIGH', location, details, error, payload }) {
    this.bugs.push({
      id: `BUG-${this.bugs.length + 1}`,
      module,
      title,
      severity,
      location,
      details,
      error: error ? (error.message || String(error)) : null,
      stack: error ? error.stack : null,
      payload
    });
  }

  incrementPass() {
    this.stats.total++;
    this.stats.passed++;
  }

  incrementFail() {
    this.stats.total++;
    this.stats.failed++;
  }
}

export const globalBugs = new BugCollector();

export function createMockReqRes({
  body = {},
  query = {},
  params = {},
  user = { id: 58, email: 'jack@yopmail.com', role: 'user', language: 'en' },
  headers = { 'accept-language': 'en' },
  files = {},
  file = null
} = {}) {
  let statusCode = 200;
  let responseData = null;
  let headersSent = false;

  const req = {
    body,
    query,
    params,
    user,
    headers,
    files,
    file,
    get: (name) => headers[name.toLowerCase()] || ''
  };

  const res = {
    status(code) {
      statusCode = code;
      return this;
    },
    json(data) {
      responseData = data;
      headersSent = true;
      return this;
    },
    send(data) {
      responseData = data;
      headersSent = true;
      return this;
    },
    end(data) {
      responseData = data;
      headersSent = true;
      return this;
    },
    setHeader() { return this; },
    contentType() { return this; },
    type() { return this; },
    attachment() { return this; },
    get headersSent() { return headersSent; }
  };

  return {
    req,
    res,
    getResponse: () => ({ statusCode, data: responseData })
  };
}

export function logSuite(title) {
  console.log('\n' + '='.repeat(70));
  console.log(`📦 MODULE: ${title}`);
  console.log('='.repeat(70));
}

export function logTest(title) {
  console.log(`\n  ▶ ${title}`);
}

export function logPass(msg) {
  globalBugs.incrementPass();
  console.log(`    ✅ PASS: ${msg}`);
}

export function logFail(module, title, err, payload, location, severity = 'HIGH') {
  globalBugs.incrementFail();
  globalBugs.recordBug({
    module,
    title,
    severity,
    location,
    details: err?.message || String(err),
    error: err,
    payload
  });
  console.log(`    ❌ FAIL: ${title}`);
  if (err?.message) console.log(`       Error: ${err.message}`);
}
